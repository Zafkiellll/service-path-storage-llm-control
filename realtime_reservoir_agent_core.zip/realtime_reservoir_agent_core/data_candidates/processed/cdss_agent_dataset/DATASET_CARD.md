# Dataset Card

## Identity

- Source: CDSS Upper Colorado/Shoshone StateMod daily model, 2024 update.
- Temporal resolution: daily.
- Forcing period: 1987-10-01 to 2013-09-30 (9,497 records).
- Closed-loop decision transitions: 9,496.
- Network: 885 nodes and 884 directed edges.
- Reservoir records: 36 total, 34 active before experiment-specific exclusions.

## Runtime files

- `nodes.csv`: river-network nodes and node types.
- `edges.csv`: directed downstream topology.
- `reservoirs.csv`: capacity, release limit, initial storage, and activity metadata.
- `daily_forcing.csv`: daily flow, diversion-demand, and instream-demand forcing.
- `daily_reservoir_targets_wide.csv`: daily minimum and maximum target storage used by the environment.

## Supporting files

- `reservoir_accounts.csv`: reservoir ownership accounts.
- `reservoir_capacity_area.csv`: storage-area-seepage curves.
- `forcing_mapping.csv`: forcing-column to StateMod-node mapping.
- `daily_reservoir_targets.csv`: long-form target-storage data.
- `dataset_manifest.json`: machine-readable inventory.
- `hydrologic_admissibility_policy/`: frozen policy and rule tables used by the main configuration.

## Interpretation boundary

Native daily observed operating labels are unavailable. Daily targets are expanded from monthly StateMod targets, and the simulations are model-based causal replays. The files must not be described as observed daily operator release, storage, or shortage trajectories.
