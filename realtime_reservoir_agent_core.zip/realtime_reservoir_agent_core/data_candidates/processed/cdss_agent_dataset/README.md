# CDSS Agent Dataset

Agent-ready daily reservoir-group scheduling dataset derived from the CDSS Upper Colorado / Shoshone StateMod daily model.

## Contents

- `nodes.csv`: StateMod river-network nodes with corrected `_DIV/_RES/_ISF/_FLO/_OTH` type parsing.
- `edges.csv`: directed downstream topology edges.
- `reservoirs.csv`: reservoir capacities, release limits, initial storage and active flags.
- `reservoir_accounts.csv`: StateMod reservoir ownership accounts.
- `reservoir_capacity_area.csv`: storage-area-seepage curves.
- `daily_forcing.csv`: complete daily stream-flow, diversion-demand and instream-demand forcing.
- `forcing_mapping.csv`: forcing column to StateMod node mapping.
- `daily_reservoir_targets.csv`: daily min/max target storage expanded from monthly StateMod targets.
- `daily_reservoir_targets_wide.csv`: wide-form daily targets for fast environment loading.

## Inventory

- Period: 1987-10-01 to 2013-09-30 (9497 days).
- Nodes: 885; edges: 884.
- Reservoirs: 36 total; 34 active.
- Forcing columns: 12.

## Known Gap

Daily reservoir storage/release/shortage labels require a StateMod build compatible with the 2024 Shoshone operating-right file.
