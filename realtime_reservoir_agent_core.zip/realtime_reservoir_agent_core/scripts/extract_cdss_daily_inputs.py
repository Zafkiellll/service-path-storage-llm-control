from __future__ import annotations

import argparse
import calendar
import csv
import re
from collections import defaultdict
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CDSS_ROOT = ROOT / "data_candidates" / "extracted" / "cdss"
DEFAULT_OUT = ROOT / "data_candidates" / "processed" / "cdss_daily"


@dataclass(frozen=True)
class DailySeriesSpec:
    filename: str
    variable: str
    units: str
    description: str


DAILY_SERIES = (
    DailySeriesSpec(
        filename="Shoshone.rid",
        variable="stream_base_flow",
        units="cfs",
        description="Daily stream base flow input.",
    ),
    DailySeriesSpec(
        filename="Shoshone_B.ddd",
        variable="diversion_demand",
        units="cfs",
        description="Daily diversion demand input.",
    ),
    DailySeriesSpec(
        filename="Shoshone.ifd",
        variable="instream_flow_demand",
        units="cfs",
        description="Daily instream-flow demand input.",
    ),
)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Extract CDSS StateMod daily input time series to agent-ready CSV files."
    )
    parser.add_argument("--cdss-root", type=Path, default=DEFAULT_CDSS_ROOT)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()

    cdss_root = args.cdss_root
    out_dir = args.out
    out_dir.mkdir(parents=True, exist_ok=True)

    all_rows: list[dict[str, str]] = []
    summary_rows: list[dict[str, str]] = []
    for spec in DAILY_SERIES:
        path = cdss_root / spec.filename
        rows = parse_statemod_daily_file(path, spec)
        all_rows.extend(rows)
        write_long_csv(out_dir / f"{spec.variable}.csv", rows)
        write_wide_csv(out_dir / f"{spec.variable}_wide.csv", rows)
        summary_rows.append(summarize_rows(spec, rows))

    delay_rows = parse_delay_tables(cdss_root / "Shoshone.dld")
    write_csv(out_dir / "daily_delay_table.csv", delay_rows)
    summary_rows.append(
        {
            "variable": "return_flow_delay_table",
            "source_file": "Shoshone.dld",
            "units": "percent",
            "row_count": str(len(delay_rows)),
            "site_count": str(len({row["delay_table_id"] for row in delay_rows})),
            "first_date": "",
            "last_date": "",
            "description": "Daily return-flow delay distributions; day_index is relative delay day.",
        }
    )

    write_long_csv(out_dir / "cdss_daily_inputs_long.csv", all_rows)
    write_wide_all(out_dir / "cdss_daily_inputs_wide.csv", all_rows)
    complete_rows = write_complete_overlap(out_dir / "cdss_daily_forcing_complete.csv", all_rows)
    write_csv(out_dir / "daily_input_summary.csv", summary_rows)
    write_readme(out_dir, summary_rows, complete_rows)

    print(f"Wrote CDSS daily inputs to {out_dir}")
    for row in summary_rows:
        print(
            f"{row['variable']}: rows={row['row_count']} sites={row['site_count']} "
            f"period={row['first_date'] or '-'}..{row['last_date'] or '-'}"
        )
    if complete_rows:
        print(
            f"cdss_daily_forcing_complete: rows={len(complete_rows)} "
            f"period={complete_rows[0]['date']}..{complete_rows[-1]['date']}"
        )


def parse_statemod_daily_file(path: Path, spec: DailySeriesSpec) -> list[dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(path)

    rows: list[dict[str, str]] = []
    in_data = False
    record_re = re.compile(r"^\s*(\d{4})\s+(\d{1,2})\s+(\S+)\s+(.+)$")
    for line in read_lines(path):
        stripped = line.strip()
        if stripped.startswith("#>EndHeader"):
            in_data = True
            continue
        if not in_data or not stripped or stripped.startswith("#"):
            continue
        match = record_re.match(line)
        if not match:
            continue
        year = int(match.group(1))
        month = int(match.group(2))
        station_id = match.group(3)
        values = parse_numbers(match.group(4))
        if len(values) < 31:
            continue
        days_in_month = calendar.monthrange(year, month)[1]
        for day in range(1, days_in_month + 1):
            rows.append(
                {
                    "date": date(year, month, day).isoformat(),
                    "station_id": station_id,
                    "variable": spec.variable,
                    "value": format_float(values[day - 1]),
                    "units": spec.units,
                    "source_file": path.name,
                }
            )
    return rows


def parse_delay_tables(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []

    rows: list[dict[str, str]] = []
    current_id = ""
    expected_count = 0
    values: list[float] = []

    def flush() -> None:
        nonlocal current_id, expected_count, values
        if not current_id:
            return
        for idx, value in enumerate(values[:expected_count], start=1):
            rows.append(
                {
                    "delay_table_id": current_id,
                    "day_index": str(idx),
                    "return_percent": format_float(value),
                    "source_file": path.name,
                }
            )
        current_id = ""
        expected_count = 0
        values = []

    first_line_re = re.compile(r"^\s*(\d+)\s+(\d+)\s+(.+)$")
    for line in read_lines(path):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        first_match = first_line_re.match(line)
        if first_match and len(line) - len(line.lstrip()) > 0:
            maybe_id = first_match.group(1)
            maybe_count = int(first_match.group(2))
            numeric_tail = parse_numbers(first_match.group(3))
            if maybe_count > 0 and numeric_tail:
                flush()
                current_id = maybe_id
                expected_count = maybe_count
                values.extend(numeric_tail)
                if len(values) >= expected_count:
                    flush()
                continue
        if current_id:
            values.extend(parse_numbers(stripped))
            if len(values) >= expected_count:
                flush()
    flush()
    return rows


def summarize_rows(spec: DailySeriesSpec, rows: list[dict[str, str]]) -> dict[str, str]:
    dates = [row["date"] for row in rows]
    sites = {row["station_id"] for row in rows}
    return {
        "variable": spec.variable,
        "source_file": spec.filename,
        "units": spec.units,
        "row_count": str(len(rows)),
        "site_count": str(len(sites)),
        "first_date": min(dates) if dates else "",
        "last_date": max(dates) if dates else "",
        "description": spec.description,
    }


def write_long_csv(path: Path, rows: list[dict[str, str]]) -> None:
    write_csv(path, rows, fieldnames=["date", "station_id", "variable", "value", "units", "source_file"])


def write_wide_csv(path: Path, rows: list[dict[str, str]]) -> None:
    by_date: dict[str, dict[str, str]] = defaultdict(dict)
    station_ids: list[str] = []
    seen = set()
    for row in rows:
        station_id = row["station_id"]
        if station_id not in seen:
            station_ids.append(station_id)
            seen.add(station_id)
        by_date[row["date"]][station_id] = row["value"]
    wide_rows = []
    for day in sorted(by_date):
        wide_rows.append({"date": day, **{station: by_date[day].get(station, "") for station in station_ids}})
    write_csv(path, wide_rows, fieldnames=["date", *station_ids])


def write_wide_all(path: Path, rows: list[dict[str, str]]) -> None:
    by_date: dict[str, dict[str, str]] = defaultdict(dict)
    columns: list[str] = []
    seen = set()
    for row in rows:
        column = f"{row['variable']}__{row['station_id']}"
        if column not in seen:
            columns.append(column)
            seen.add(column)
        by_date[row["date"]][column] = row["value"]
    wide_rows = []
    for day in sorted(by_date):
        wide_rows.append({"date": day, **{column: by_date[day].get(column, "") for column in columns}})
    write_csv(path, wide_rows, fieldnames=["date", *columns])


def write_complete_overlap(path: Path, rows: list[dict[str, str]]) -> list[dict[str, str]]:
    by_date: dict[str, dict[str, str]] = defaultdict(dict)
    columns: list[str] = []
    seen = set()
    for row in rows:
        column = f"{row['variable']}__{row['station_id']}"
        if column not in seen:
            columns.append(column)
            seen.add(column)
        by_date[row["date"]][column] = row["value"]
    complete_rows: list[dict[str, str]] = []
    for day in sorted(by_date):
        values = by_date[day]
        if all(column in values for column in columns):
            complete_rows.append({"date": day, **{column: values[column] for column in columns}})
    write_csv(path, complete_rows, fieldnames=["date", *columns])
    return complete_rows


def write_readme(out_dir: Path, summary_rows: list[dict[str, str]], complete_rows: list[dict[str, str]]) -> None:
    lines = [
        "# CDSS Daily Inputs",
        "",
        "Extracted from CDSS Upper Colorado StateMod Daily files.",
        "",
        "These files are confirmed daily inputs, not simulated operation outputs. Reservoir daily storage/release/shortage still requires running StateMod with output requests enabled.",
        "",
        "## Files",
        "",
        "- `stream_base_flow.csv` / `_wide.csv`: daily stream-base flow inputs.",
        "- `diversion_demand.csv` / `_wide.csv`: daily diversion-demand inputs.",
        "- `instream_flow_demand.csv` / `_wide.csv`: daily instream-flow demand inputs.",
        "- `daily_delay_table.csv`: daily return-flow delay distributions.",
        "- `cdss_daily_inputs_long.csv`: all daily input series in long form.",
        "- `cdss_daily_inputs_wide.csv`: all daily input series in wide form.",
        "- `cdss_daily_forcing_complete.csv`: complete date intersection across stream flow, diversion demand, and instream-flow demand.",
        "- `daily_input_summary.csv`: extraction inventory.",
        "",
        "## Summary",
        "",
    ]
    for row in summary_rows:
        lines.append(
            f"- {row['variable']}: {row['row_count']} rows, {row['site_count']} sites, "
            f"{row['first_date'] or '-'} to {row['last_date'] or '-'}."
        )
    if complete_rows:
        lines.extend(
            [
                "",
                "## Complete Daily Forcing Table",
                "",
                f"`cdss_daily_forcing_complete.csv` has {len(complete_rows)} complete daily rows from {complete_rows[0]['date']} to {complete_rows[-1]['date']}.",
            ]
        )
    (out_dir / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_csv(path: Path, rows: list[dict[str, str]], fieldnames: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = []
        for row in rows:
            for key in row:
                if key not in fieldnames:
                    fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def parse_numbers(text: str) -> list[float]:
    values = []
    for token in text.split():
        try:
            values.append(float(token))
        except ValueError:
            continue
    return values


def format_float(value: float) -> str:
    return f"{value:.6g}"


def read_lines(path: Path) -> Iterable[str]:
    for encoding in ("utf-8", "latin-1", "cp1252"):
        try:
            yield from path.read_text(encoding=encoding, errors="ignore").splitlines()
            return
        except Exception:
            continue


if __name__ == "__main__":
    main()
