from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from realtime_reservoir_agent import DailyReservoirEnvironment

DATASET = ROOT / "data_candidates" / "processed" / "cdss_agent_dataset"


def main() -> None:
    env = DailyReservoirEnvironment(DATASET, forecast_horizon_days=7)
    obs = env.reset("1987-10-01")
    intent = env.form_intent()
    action = env.action_from_intent(intent)
    result = env.step(action)

    print("dataset", DATASET)
    print("date", obs["date"])
    print("reservoir_count", len(obs["reservoir_ids"]))
    print("primary_intent", intent["primary_intent"])
    print("storage_ratio", round(float(intent["storage_ratio"]), 4))
    print("demand_pressure", round(float(intent["demand_pressure"]), 4))
    print("forecast_wetness_ratio", round(float(intent["forecast_wetness_ratio"]), 4))
    print("total_requested_release_cfs", round(result.metrics["total_requested_release_cfs"], 4))
    print("total_applied_release_cfs", round(result.metrics["total_applied_release_cfs"], 4))
    print("total_inflow_proxy_cfs", round(result.metrics["total_inflow_proxy_cfs"], 4))
    print("shortage_before_cfs", round(result.metrics["total_shortage_before_release_cfs"], 4))
    print("shortage_after_cfs", round(result.metrics["total_shortage_after_release_cfs"], 4))
    print("next_date", result.next_date)


if __name__ == "__main__":
    main()
