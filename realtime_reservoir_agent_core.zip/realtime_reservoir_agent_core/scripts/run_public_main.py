from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATASET = ROOT / "data_candidates" / "processed" / "cdss_agent_dataset"
CONTRACT_LIBRARY = ROOT / "experiments" / "semantic_contract_v3" / "llm_authored_semantic_contract_library.json"
HYDROLOGIC_POLICY = DATASET / "hydrologic_admissibility_policy" / "trained_hydrologic_admissibility_policy.json"


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the public core reservoir-agent configuration.")
    parser.add_argument("--max-steps", type=int, default=30, help="0 runs all 9,496 transitions.")
    parser.add_argument("--start-date", default="1987-10-01")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    out = args.out or ROOT / "outputs" / (
        "main_method_full" if args.max_steps == 0 else f"main_method_{args.max_steps}d"
    )
    if not out.is_absolute():
        out = ROOT / out

    command = [
        sys.executable,
        str(ROOT / "scripts" / "run_cdss_final_robust_mpc_agent.py"),
        "--dataset", str(DATASET),
        "--out", str(out),
        "--start-date", args.start_date,
        "--exclude-reservoirs", "3903508_Ex",
        "--horizon-days", "7",
        "--ensemble-size", "12",
        "--analog-window-days", "21",
        "--viability-floor-fraction", "0.25",
        "--service-ledger-scale-cfs-days", "1000",
        "--reserve-ledger-scale-acft", "100000",
        "--mpc-risk-weight", "0.55",
        "--mpc-worst-weight", "0.10",
        "--strategic-reserve-weight", "6.0",
        "--ledger-decay", "0.995",
        "--reserve-repayment-fraction", "0.08",
        "--ledger-recovery-fraction", "0.20",
        "--certificate-mode", "full",
        "--deliberation-backend", "contract_library",
        "--contract-library-path", str(CONTRACT_LIBRARY),
        "--event-triggered-deliberation",
        "--semantic-novelty-threshold", "0.16",
        "--semantic-trigger-threshold", "0.22",
        "--semantic-contract-max-age-days", "14",
        "--semantic-minimum-support-validity", "0.55",
        "--semantic-conflict-escalation-threshold", "0.18",
        "--semantic-modifier-decay-rate", "0.0",
        "--semantic-safety-veto-streak", "3",
        "--semantic-safety-requery-cooldown-days", "7",
        "--semantic-safety-dual-drift-threshold", "0.15",
        "--max-deliberation-rounds", "3",
        "--certificate-requery-service-regret-cfs", "75",
        "--certificate-requery-reserve-violation-acft", "50000",
        "--certificate-requery-actions", "service_override",
        "--shadow-baseline-mode", "trained_admissibility",
        "--shadow-score-tolerance", "0",
        "--hydrologic-admissibility-policy", str(HYDROLOGIC_POLICY),
        "--hydrologic-supervisor-decay", "0.985",
        "--hydrologic-supervisor-score-limit", "45",
        "--hydrologic-supervisor-service-limit-cfs", "55",
        "--hydrologic-supervisor-reserve-limit-acft", "60000",
        "--supply-guarantee-fraction", "0.96",
        "--supply-reserve-guard-mode", "forecast_risk_or_local_storage",
        "--supply-reserve-guard-min-demand-cfs", "25",
        "--supply-reserve-guard-local-storage-fraction", "0.75",
    ]
    if args.max_steps > 0:
        command.extend(("--max-steps", str(args.max_steps)))
    subprocess.run(command, cwd=ROOT, check=True)
    print(out)


if __name__ == "__main__":
    main()
