from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "experiments" / "gpt5_interface_audit"

calls = [json.loads(line) for line in (AUDIT / "gpt5_call_audit_sanitized.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
with (AUDIT / "paired_case_results.csv").open(encoding="utf-8-sig", newline="") as handle:
    rows = list(csv.DictReader(handle))
with (AUDIT / "gpt5_interface_audit_summary.json").open(encoding="utf-8") as handle:
    summary = json.load(handle)

assert len(calls) == len(rows) == summary["cases"] == 24
assert all(call["status"] == "success" for call in calls)
assert summary["raw_schema_valid_contracts"] == 24
assert summary["evidence_bound_contracts"] == 24
assert summary["projected_contracts"] == 0
assert summary["fallback_contracts"] == 0
assert summary["release_vector_changes"] == 5
print(json.dumps(summary, indent=2))
