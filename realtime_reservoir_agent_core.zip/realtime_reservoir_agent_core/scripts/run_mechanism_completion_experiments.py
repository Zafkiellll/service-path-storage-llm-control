from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATASET = ROOT / "data_candidates" / "processed" / "cdss_agent_dataset"
OUTPUT_ROOT = DATASET / "mechanism_completion_experiments"
LLM_LIBRARY = ROOT / "experiments" / "semantic_contract_v3" / "llm_authored_semantic_contract_library.json"
NEUTRAL_LIBRARY = ROOT / "experiments" / "mechanism_completion" / "neutral_semantic_contract_library.json"
HYDROLOGIC_POLICY = DATASET / "hydrologic_admissibility_policy" / "trained_hydrologic_admissibility_policy.json"


@dataclass(frozen=True)
class Experiment:
    experiment: str
    category: str
    arguments: tuple[str, ...]
    description: str


def semantic_event_args() -> tuple[str, ...]:
    return (
        "--event-triggered-deliberation",
        "--semantic-novelty-threshold", "0.16",
        "--semantic-trigger-threshold", "0.22",
        "--semantic-contract-max-age-days", "14",
        "--semantic-minimum-support-validity", "0.55",
        "--semantic-conflict-escalation-threshold", "0.18",
        "--semantic-modifier-decay-rate", "0.0",
        "--semantic-safety-veto-streak", "3",
        "--semantic-safety-requery-cooldown-days", "7",
        "--semantic-safety-dual-drift-threshold", "0.15",
        "--max-deliberation-rounds", "3",
        "--certificate-requery-service-regret-cfs", "75",
        "--certificate-requery-reserve-violation-acft", "50000",
        "--certificate-requery-actions", "service_override",
        "--shadow-baseline-mode", "trained_admissibility",
        "--shadow-score-tolerance", "0",
        "--hydrologic-admissibility-policy", str(HYDROLOGIC_POLICY),
        "--hydrologic-supervisor-decay", "0.985",
        "--hydrologic-supervisor-score-limit", "45",
        "--hydrologic-supervisor-service-limit-cfs", "55",
        "--hydrologic-supervisor-reserve-limit-acft", "60000",
        "--supply-guarantee-fraction", "0.96",
    )


def contract_author_args(library: Path) -> tuple[str, ...]:
    return (
        "--deliberation-backend", "contract_library",
        "--contract-library-path", str(library),
    ) + semantic_event_args()


def deterministic_author_args() -> tuple[str, ...]:
    return ("--deliberation-backend", "deterministic") + semantic_event_args()


def local_inventory_args(author_args: tuple[str, ...]) -> tuple[str, ...]:
    return author_args + (
        "--supply-reserve-guard-mode", "forecast_risk_or_local_storage",
        "--supply-reserve-guard-min-demand-cfs", "25",
        "--supply-reserve-guard-local-storage-fraction", "0.75",
    )


def path_viability_args(base_fraction: str) -> tuple[str, ...]:
    return contract_author_args(LLM_LIBRARY) + (
        "--supply-reserve-guard-mode", "forecast_risk",
        "--supply-reserve-guard-min-demand-cfs", "25",
        "--supply-path-viability-mode", "adaptive_envelope",
        "--supply-path-viability-base-fraction", base_fraction,
        "--supply-path-viability-max-fraction", "0.75",
        "--supply-path-viability-memory-days", "180",
        "--supply-path-viability-demand-lookahead-days", "180",
        "--supply-path-viability-demand-reserve-fraction", "0.35",
        "--supply-path-viability-forecast-multiplier", "1.0",
    )


def experiments() -> list[Experiment]:
    return [
        Experiment(
            "path_viability_base_025",
            "multiyear_path_viability",
            path_viability_args("0.25"),
            "Adaptive path viability envelope with a 25% irreducible base reserve.",
        ),
        Experiment(
            "path_viability_base_035",
            "multiyear_path_viability",
            path_viability_args("0.35"),
            "Adaptive path viability envelope with a 35% irreducible base reserve.",
        ),
        Experiment(
            "path_viability_base_045",
            "multiyear_path_viability",
            path_viability_args("0.45"),
            "Adaptive path viability envelope with a 45% irreducible base reserve.",
        ),
        Experiment(
            "strict_author_llm_contract",
            "strict_semantic_author_ablation",
            local_inventory_args(contract_author_args(LLM_LIBRARY)),
            "LLM-authored semantic contracts under the otherwise identical controller.",
        ),
        Experiment(
            "strict_author_deterministic",
            "strict_semantic_author_ablation",
            local_inventory_args(deterministic_author_args()),
            "Deterministic semantic author under the otherwise identical controller.",
        ),
        Experiment(
            "strict_author_neutral_contract",
            "strict_semantic_author_ablation",
            local_inventory_args(contract_author_args(NEUTRAL_LIBRARY)),
            "Modifier-neutralized contract control with matched evidence and retrieval structure.",
        ),
    ]


def build_neutral_library() -> None:
    payload = json.loads(LLM_LIBRARY.read_text(encoding="utf-8"))
    entries = payload.get("entries", [])
    if not isinstance(entries, list) or len(entries) < 3:
        raise ValueError("The source semantic contract library is too small to shuffle.")
    neutral = copy.deepcopy(payload)
    neutral_entries = neutral["entries"]
    for index, target in enumerate(neutral_entries):
        target["risk_posture"] = "balanced"
        target["support_budget_multiplier"] = 1.0
        target["buffer_budget_multiplier"] = 1.0
        target["reserve_floor_delta_acft"] = 0.0
        target["risk_aversion_delta"] = 0.0
        target["response_payload"]["risk_posture"] = "balanced"
        target["response_payload"]["support_budget_multiplier"] = 1.0
        target["response_payload"]["buffer_budget_multiplier"] = 1.0
        target["response_payload"]["reserve_floor_delta_acft"] = 0.0
        target["response_payload"]["risk_aversion_delta"] = 0.0
        canonical = json.dumps(
            target["response_payload"],
            ensure_ascii=True,
            sort_keys=True,
            separators=(",", ":"),
        )
        target["payload_sha256"] = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        target["entry_id"] = f"neutral_contract_{index + 1:04d}"
    neutral["library_name"] = "modifier_neutralized_contract_control"
    neutral["authorship"] = (
        "Negative-control library preserving evidence citations, intent labels, active skills, "
        "and retrieval structure while setting all optimization modifiers to neutral values."
    )
    neutral["intended_use"] = "Strict semantic-modifier ablation only."
    NEUTRAL_LIBRARY.parent.mkdir(parents=True, exist_ok=True)
    NEUTRAL_LIBRARY.write_text(
        json.dumps(neutral, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def expected_steps(stage: str) -> int:
    return {"smoke": 30, "screen": 1000, "full": 9496}[stage]


def max_steps(stage: str) -> int:
    return {"smoke": 30, "screen": 1000, "full": 0}[stage]


def command_for(python: Path, stage: str, output_dir: Path, experiment: Experiment) -> list[str]:
    command = [
        str(python),
        str(ROOT / "scripts" / "run_cdss_final_robust_mpc_agent.py"),
        "--dataset", str(DATASET),
        "--out", str(output_dir),
        "--exclude-reservoirs", "3903508_Ex",
        "--horizon-days", "7",
        "--ensemble-size", "12",
        "--analog-window-days", "21",
        "--viability-floor-fraction", "0.25",
        "--service-ledger-scale-cfs-days", "1000",
        "--reserve-ledger-scale-acft", "100000",
        "--mpc-risk-weight", "0.55",
        "--mpc-worst-weight", "0.10",
        "--strategic-reserve-weight", "6.0",
        "--ledger-decay", "0.995",
        "--reserve-repayment-fraction", "0.08",
        "--ledger-recovery-fraction", "0.20",
        "--certificate-mode", "full",
    ]
    if max_steps(stage) > 0:
        command.extend(("--max-steps", str(max_steps(stage))))
    command.extend(experiment.arguments)
    return command


def completed(output_dir: Path, stage: str) -> bool:
    summary_path = output_dir / "final_robust_mpc_summary.json"
    if not summary_path.exists():
        return False
    try:
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return (
        summary.get("termination_reason") == "completed"
        and int(summary.get("steps", 0)) == expected_steps(stage)
        and summary.get("exclude_reservoirs") == "3903508_Ex"
    )


def run_one(command: list[str], output_dir: Path) -> tuple[int, str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        command,
        cwd=ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    (output_dir / "run.log").write_text(result.stdout, encoding="utf-8")
    return result.returncode, result.stdout[-4000:]


def write_manifest(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the mechanism-completion experiment package.")
    parser.add_argument("--stage", choices=("smoke", "screen", "full"), default="smoke")
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--python", type=Path, required=True)
    parser.add_argument("--force", action="store_true")
    parser.add_argument(
        "--only",
        default="",
        help="Comma-separated experiment names to run; empty selects the full package.",
    )
    args = parser.parse_args()

    build_neutral_library()
    selected_names = {name.strip() for name in args.only.split(",") if name.strip()}
    selected_experiments = [
        experiment
        for experiment in experiments()
        if not selected_names or experiment.experiment in selected_names
    ]
    missing_names = selected_names - {experiment.experiment for experiment in selected_experiments}
    if missing_names:
        raise ValueError(f"Unknown experiments: {', '.join(sorted(missing_names))}")
    stage_root = OUTPUT_ROOT / args.stage
    stage_root.mkdir(parents=True, exist_ok=True)
    jobs: list[tuple[Experiment, Path, list[str]]] = []
    rows: list[dict[str, str]] = []
    for experiment in selected_experiments:
        output_dir = stage_root / experiment.experiment
        command = command_for(args.python, args.stage, output_dir, experiment)
        status = "completed_cached" if completed(output_dir, args.stage) and not args.force else "pending"
        rows.append(
            {
                "experiment": experiment.experiment,
                "category": experiment.category,
                "stage": args.stage,
                "status": status,
                "output_dir": str(output_dir),
                "command": subprocess.list2cmdline(command),
                "description": experiment.description,
            }
        )
        if status == "pending":
            jobs.append((experiment, output_dir, command))

    write_manifest(stage_root / "mechanism_completion_manifest.csv", rows)
    if not jobs:
        print(json.dumps({"stage": args.stage, "status": "already_completed"}, indent=2))
        return

    failures: list[dict[str, str | int]] = []
    with ThreadPoolExecutor(max_workers=max(1, min(args.workers, len(jobs)))) as executor:
        future_map = {
            executor.submit(run_one, command, output_dir): (experiment, output_dir)
            for experiment, output_dir, command in jobs
        }
        for future in as_completed(future_map):
            experiment, output_dir = future_map[future]
            returncode, tail = future.result()
            if returncode != 0 or not completed(output_dir, args.stage):
                failures.append(
                    {
                        "experiment": experiment.experiment,
                        "returncode": returncode,
                        "log_tail": tail,
                    }
                )
            print(f"{experiment.experiment}: returncode={returncode}", flush=True)

    for row in rows:
        output_dir = Path(row["output_dir"])
        row["status"] = "completed" if completed(output_dir, args.stage) else "failed"
    write_manifest(stage_root / "mechanism_completion_manifest.csv", rows)
    result = {
        "stage": args.stage,
        "experiments": len(rows),
        "completed": sum(row["status"] in {"completed", "completed_cached"} for row in rows),
        "failures": failures,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
