from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from realtime_reservoir_agent import DailyReservoirEnvironment


DEFAULT_DATASET = ROOT / "data_candidates" / "processed" / "cdss_agent_dataset"
DEFAULT_OUT = DEFAULT_DATASET / "baseline_runs"


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the transparent CDSS daily intent-rule scheduler.")
    parser.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--start-date", default="1987-10-01")
    parser.add_argument("--max-steps", type=int, default=0, help="0 means run to the end of the forcing period.")
    parser.add_argument("--forecast-horizon-days", type=int, default=7)
    parser.add_argument(
        "--exclude-reservoirs",
        default="",
        help="Comma-separated reservoir ids to exclude from physical control/storage accounting.",
    )
    parser.add_argument(
        "--clamp-negative-streamflow",
        action="store_true",
        help="Clamp negative stream-base-flow forcing values to zero for sensitivity analysis.",
    )
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    excluded_reservoirs = tuple(
        reservoir_id.strip()
        for reservoir_id in args.exclude_reservoirs.split(",")
        if reservoir_id.strip()
    )
    reservoir_ids = (
        selected_reservoir_ids(args.dataset, excluded_reservoirs)
        if excluded_reservoirs
        else None
    )
    env = DailyReservoirEnvironment(
        args.dataset,
        reservoir_ids=reservoir_ids,
        forecast_horizon_days=args.forecast_horizon_days,
        clamp_negative_streamflow=args.clamp_negative_streamflow,
    )
    env.reset(args.start_date)
    steps_available = len(env.forcing_dates) - env.date_index - 1
    step_count = steps_available if args.max_steps <= 0 else min(args.max_steps, steps_available)

    trace_rows: list[dict[str, str]] = []
    release_rows: list[dict[str, str]] = []
    storage_rows: list[dict[str, str]] = []
    intent_counts: Counter[str] = Counter()

    for _ in range(step_count):
        intent = env.form_intent()
        action = env.action_from_intent(intent)
        result = env.step(action)
        primary = str(intent["primary_intent"])
        intent_counts[primary] += 1
        trace_rows.append(
            {
                "date": result.date,
                "next_date": result.next_date,
                "primary_intent": primary,
                "storage_ratio": fmt(intent["storage_ratio"]),
                "demand_pressure": fmt(intent["demand_pressure"]),
                "forecast_wetness_ratio": fmt(intent["forecast_wetness_ratio"]),
                "target_encroachment_ratio": fmt(intent["target_encroachment_ratio"]),
                "total_inflow_proxy_cfs": fmt(result.metrics["total_inflow_proxy_cfs"]),
                "total_requested_release_cfs": fmt(result.metrics["total_requested_release_cfs"]),
                "total_applied_release_cfs": fmt(result.metrics["total_applied_release_cfs"]),
                "total_shortage_before_release_cfs": fmt(result.metrics["total_shortage_before_release_cfs"]),
                "total_shortage_after_release_cfs": fmt(result.metrics["total_shortage_after_release_cfs"]),
                "diversion_shortage_after_release_cfs": fmt(result.metrics["diversion_shortage_after_release_cfs"]),
                "instream_shortage_after_release_cfs": fmt(result.metrics["instream_shortage_after_release_cfs"]),
            }
        )
        for reservoir_id in env.reservoir_ids:
            release_rows.append(
                {
                    "date": result.date,
                    "reservoir_id": reservoir_id,
                    "primary_intent": primary,
                    "requested_release_cfs": fmt(result.requested_releases_cfs.get(reservoir_id, 0.0)),
                    "applied_release_cfs": fmt(result.applied_releases_cfs.get(reservoir_id, 0.0)),
                }
            )
            storage_rows.append(
                {
                    "date": result.date,
                    "reservoir_id": reservoir_id,
                    "storage_before_acft": fmt(result.storage_acft.get(reservoir_id, 0.0)),
                    "storage_after_acft": fmt(result.next_storage_acft.get(reservoir_id, 0.0)),
                }
            )

    write_csv(args.out / "intent_rule_trace.csv", trace_rows)
    write_csv(args.out / "intent_rule_release_schedule.csv", release_rows)
    write_csv(args.out / "intent_rule_storage_trajectory.csv", storage_rows)

    shortage_before = sum(float(row["total_shortage_before_release_cfs"]) for row in trace_rows)
    shortage_after = sum(float(row["total_shortage_after_release_cfs"]) for row in trace_rows)
    summary = {
        "dataset": str(args.dataset),
        "start_date": args.start_date,
        "exclude_reservoirs": args.exclude_reservoirs,
        "clamp_negative_streamflow": args.clamp_negative_streamflow,
        "forecast_horizon_days": args.forecast_horizon_days,
        "steps": step_count,
        "end_date": trace_rows[-1]["date"] if trace_rows else args.start_date,
        "intent_counts": dict(intent_counts),
        "mean_shortage_before_release_cfs": shortage_before / step_count if step_count else 0.0,
        "mean_shortage_after_release_cfs": shortage_after / step_count if step_count else 0.0,
        "mean_shortage_reduction_cfs": (shortage_before - shortage_after) / step_count if step_count else 0.0,
        "relative_shortage_reduction": (shortage_before - shortage_after) / shortage_before if shortage_before else 0.0,
        "outputs": [
            "intent_rule_trace.csv",
            "intent_rule_release_schedule.csv",
            "intent_rule_storage_trajectory.csv",
            "intent_rule_summary.json",
        ],
    }
    (args.out / "intent_rule_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def fmt(value: object) -> str:
    return f"{float(value):.6g}"


def selected_reservoir_ids(
    dataset: Path,
    excluded_reservoirs: tuple[str, ...],
) -> list[str]:
    excluded = set(excluded_reservoirs)
    rows: list[str] = []
    with (dataset / "reservoirs.csv").open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            reservoir_id = row["reservoir_id"]
            if reservoir_id in excluded:
                continue
            if row.get("active", "") != "True":
                continue
            try:
                capacity = float(row.get("content_max_acft", 0.0) or 0.0)
            except ValueError:
                capacity = 0.0
            if capacity <= 0.0:
                continue
            rows.append(reservoir_id)
    missing = sorted(excluded - read_all_reservoir_ids(dataset))
    if missing:
        raise ValueError(f"Excluded reservoir ids not found in reservoirs.csv: {missing}")
    if not rows:
        raise ValueError("No active reservoirs remain after --exclude-reservoirs filtering.")
    return rows


def read_all_reservoir_ids(dataset: Path) -> set[str]:
    with (dataset / "reservoirs.csv").open("r", encoding="utf-8-sig", newline="") as handle:
        return {row["reservoir_id"] for row in csv.DictReader(handle)}


if __name__ == "__main__":
    main()
