from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CDSS_ROOT = ROOT / "data_candidates" / "extracted" / "cdss"
DEFAULT_DAILY_ROOT = ROOT / "data_candidates" / "processed" / "cdss_daily"
DEFAULT_OUT = ROOT / "data_candidates" / "processed" / "cdss_agent_dataset"


NODE_TYPE_LABELS = {
    "DIV": "diversion",
    "FLO": "streamgage",
    "ISF": "instream_flow",
    "RES": "reservoir",
    "OTH": "other",
    "PLN": "plan",
    "END": "terminal",
}


@dataclass(frozen=True)
class NodeRecord:
    node_id: str
    name: str
    node_type: str
    downstream_id: str
    comment: str
    gwmax_cfs: str


@dataclass(frozen=True)
class ReservoirRecord:
    reservoir_id: str
    name: str
    node_id: str
    on_off: str
    one_fill_rule: str
    daily_id: str
    content_min_acft: str
    content_max_acft: str
    release_max_cfs: str
    dead_storage_acft: str
    owner_count: str
    evap_station_count: str
    precip_station_count: str
    cap_area_count: str
    initial_storage_acft: str


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a CDSS daily reservoir-agent dataset.")
    parser.add_argument("--cdss-root", type=Path, default=DEFAULT_CDSS_ROOT)
    parser.add_argument("--daily-root", type=Path, default=DEFAULT_DAILY_ROOT)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()

    cdss_root = args.cdss_root
    daily_root = args.daily_root
    out_dir = args.out
    out_dir.mkdir(parents=True, exist_ok=True)

    type_sets = build_station_type_sets(cdss_root)
    nodes = parse_rin(cdss_root / "Shoshone.rin", type_sets)
    node_rows, edge_rows = build_topology_rows(nodes)
    write_csv(out_dir / "nodes.csv", node_rows)
    write_csv(out_dir / "edges.csv", edge_rows)

    reservoirs, account_rows, cap_area_rows = parse_reservoirs(cdss_root / "Shoshone.res")
    reservoir_rows = enrich_reservoir_rows(reservoirs, nodes)
    write_csv(out_dir / "reservoirs.csv", reservoir_rows)
    write_csv(out_dir / "reservoir_accounts.csv", account_rows)
    write_csv(out_dir / "reservoir_capacity_area.csv", cap_area_rows)

    forcing_src = daily_root / "cdss_daily_forcing_complete.csv"
    forcing_dst = out_dir / "daily_forcing.csv"
    if not forcing_src.exists():
        raise FileNotFoundError(forcing_src)
    shutil.copyfile(forcing_src, forcing_dst)
    forcing_dates, forcing_columns = read_forcing_header_and_dates(forcing_dst)
    forcing_map_rows = build_forcing_mapping(forcing_columns, nodes)
    write_csv(out_dir / "forcing_mapping.csv", forcing_map_rows)

    target_records = parse_monthly_targets(cdss_root / "ShoshoneB.tar")
    target_rows = build_daily_target_rows(forcing_dates, target_records, reservoirs)
    write_csv(out_dir / "daily_reservoir_targets.csv", target_rows)
    write_target_wide(out_dir / "daily_reservoir_targets_wide.csv", target_rows)

    manifest = build_manifest(
        node_rows=node_rows,
        edge_rows=edge_rows,
        reservoir_rows=reservoir_rows,
        account_rows=account_rows,
        cap_area_rows=cap_area_rows,
        forcing_dates=forcing_dates,
        forcing_columns=forcing_columns,
        target_rows=target_rows,
    )
    (out_dir / "dataset_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    write_readme(out_dir, manifest)

    print(f"Wrote CDSS agent dataset to {out_dir}")
    print(
        f"nodes={len(node_rows)} edges={len(edge_rows)} reservoirs={len(reservoir_rows)} "
        f"forcing_days={len(forcing_dates)} target_rows={len(target_rows)}"
    )


def build_station_type_sets(cdss_root: Path) -> dict[str, set[str]]:
    return {
        "DIV": parse_statemod_station_ids(cdss_root / "Shoshone.dds"),
        "ISF": parse_statemod_station_ids(cdss_root / "Shoshone.ifs"),
        "RES": parse_statemod_station_ids(cdss_root / "Shoshone.res"),
        "PLN": parse_statemod_station_ids(cdss_root / "cm2015.pln"),
    }


def parse_statemod_station_ids(path: Path) -> set[str]:
    ids = set()
    if not path.exists():
        return ids
    for line in iter_data_lines(path):
        if line[:1].isspace():
            continue
        token = line.split()[0] if line.split() else ""
        if token and token.upper() not in {"CAP-AREA", "EVAPORATION", "-999"}:
            ids.add(token)
    return ids


def parse_rin(path: Path, type_sets: dict[str, set[str]]) -> list[NodeRecord]:
    rows: list[NodeRecord] = []
    in_data = False
    for line in read_lines(path):
        if line.strip().startswith("#>EndHeader"):
            in_data = True
            continue
        if not in_data or not line.strip() or line.lstrip().startswith("#"):
            continue
        node_id = field(line, 0, 12)
        if not node_id:
            continue
        name_field = field_raw(line, 12, 36)
        node_type = ""
        name = name_field.strip()
        type_match = re.search(r"_(DIV|FLO|ISF|RES|OTH|PLN|END)\s*$", name_field)
        if type_match:
            node_type = type_match.group(1)
            name = name_field[: type_match.start()].strip()
        if not node_type:
            for candidate_type, ids in type_sets.items():
                if node_id in ids:
                    node_type = candidate_type
                    break
        if not node_type and name.endswith("_"):
            name = name.rstrip("_").strip()
            node_type = "DIV"
        if not node_type and node_id.lower().endswith("_end"):
            node_type = "END"
        downstream_id = field(line, 36, 48)
        comment = field(line, 49, 61)
        gwmax = field(line, 62, None)
        rows.append(
            NodeRecord(
                node_id=node_id,
                name=name,
                node_type=node_type,
                downstream_id=downstream_id,
                comment=comment,
                gwmax_cfs=gwmax,
            )
        )
    return rows


def build_topology_rows(nodes: list[NodeRecord]) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    node_ids = {node.node_id for node in nodes}
    topological_index = {node.node_id: idx for idx, node in enumerate(nodes)}
    edge_rows: list[dict[str, str]] = []
    for node in nodes:
        if node.downstream_id and node.downstream_id not in {"-999", "0"}:
            edge_rows.append(
                {
                    "from_node_id": node.node_id,
                    "to_node_id": node.downstream_id,
                    "edge_type": "downstream",
                    "to_node_present": str(node.downstream_id in node_ids),
                }
            )
    outlets = {node.node_id for node in nodes if not node.downstream_id or node.downstream_id in {"-999", "0"}}
    node_rows = [
        {
            "node_id": node.node_id,
            "name": node.name,
            "node_type": node.node_type,
            "node_type_label": NODE_TYPE_LABELS.get(node.node_type, "unknown"),
            "downstream_id": node.downstream_id,
            "comment": node.comment,
            "gwmax_cfs": node.gwmax_cfs,
            "topological_index": str(topological_index[node.node_id]),
            "is_reservoir": str(node.node_type == "RES"),
            "is_diversion": str(node.node_type == "DIV"),
            "is_instream": str(node.node_type == "ISF"),
            "is_streamgage": str(node.node_type == "FLO"),
            "is_outlet": str(node.node_id in outlets),
        }
        for node in nodes
    ]
    return node_rows, edge_rows


def parse_reservoirs(path: Path) -> tuple[list[ReservoirRecord], list[dict[str, str]], list[dict[str, str]]]:
    lines = iter_data_lines(path)
    reservoirs: list[ReservoirRecord] = []
    account_rows: list[dict[str, str]] = []
    cap_area_rows: list[dict[str, str]] = []
    for line in lines:
        if not line.strip() or line[:1].isspace():
            continue
        reservoir_id = field(line, 0, 12)
        name = field(line, 12, 36)
        node_id = field(line, 36, 48)
        on_off = field(line, 48, 56)
        one_fill_rule = field(line, 56, 64)
        daily_id = field(line, 64, None)
        card2 = next(lines, "")
        card2_values = card2.split()
        if len(card2_values) < 8:
            continue
        content_min, content_max, release_max, dead_storage = card2_values[:4]
        owner_count = int(float(card2_values[4]))
        evap_count = int(float(card2_values[5]))
        precip_count = int(float(card2_values[6]))
        cap_area_count = int(float(card2_values[7]))
        initial_storage = 0.0
        for owner_index in range(owner_count):
            owner_line = next(lines, "")
            owner_name = field(owner_line, 12, 24)
            owner_values = owner_line[24:].split()
            owner_max = owner_values[0] if len(owner_values) > 0 else ""
            owner_initial = owner_values[1] if len(owner_values) > 1 else ""
            owner_evap = owner_values[2] if len(owner_values) > 2 else ""
            owner_fill = owner_values[3] if len(owner_values) > 3 else ""
            initial_storage += to_float(owner_initial)
            account_rows.append(
                {
                    "reservoir_id": reservoir_id,
                    "account_index": str(owner_index + 1),
                    "account_name": owner_name,
                    "account_max_acft": owner_max,
                    "initial_storage_acft": owner_initial,
                    "evap_distribution": owner_evap,
                    "fill_type": owner_fill,
                }
            )
        for _ in range(evap_count):
            next(lines, "")
        for _ in range(precip_count):
            next(lines, "")
        for table_index in range(cap_area_count):
            cap_line = next(lines, "")
            values = cap_line.split()
            if len(values) >= 5 and values[0].upper() == "CAP-AREA":
                cap_area_rows.append(
                    {
                        "reservoir_id": reservoir_id,
                        "table_index": str(table_index + 1),
                        "content_acft": values[2],
                        "area_acres": values[3],
                        "seepage_acft": values[4],
                    }
                )
        reservoirs.append(
            ReservoirRecord(
                reservoir_id=reservoir_id,
                name=name,
                node_id=node_id,
                on_off=on_off,
                one_fill_rule=one_fill_rule,
                daily_id=daily_id,
                content_min_acft=content_min,
                content_max_acft=content_max,
                release_max_cfs=release_max,
                dead_storage_acft=dead_storage,
                owner_count=str(owner_count),
                evap_station_count=str(evap_count),
                precip_station_count=str(precip_count),
                cap_area_count=str(cap_area_count),
                initial_storage_acft=format_float(initial_storage),
            )
        )
    return reservoirs, account_rows, cap_area_rows


def enrich_reservoir_rows(reservoirs: list[ReservoirRecord], nodes: list[NodeRecord]) -> list[dict[str, str]]:
    node_by_id = {node.node_id: node for node in nodes}
    rows = []
    for reservoir in reservoirs:
        node = node_by_id.get(reservoir.node_id)
        downstream_id = node.downstream_id if node else ""
        rows.append(
            {
                "reservoir_id": reservoir.reservoir_id,
                "name": reservoir.name,
                "node_id": reservoir.node_id,
                "downstream_id": downstream_id,
                "on_off": reservoir.on_off,
                "active": str(to_float(reservoir.on_off) > 0),
                "one_fill_rule": reservoir.one_fill_rule,
                "daily_id": reservoir.daily_id,
                "content_min_acft": reservoir.content_min_acft,
                "content_max_acft": reservoir.content_max_acft,
                "release_max_cfs": reservoir.release_max_cfs,
                "dead_storage_acft": reservoir.dead_storage_acft,
                "initial_storage_acft": reservoir.initial_storage_acft,
                "owner_count": reservoir.owner_count,
                "evap_station_count": reservoir.evap_station_count,
                "precip_station_count": reservoir.precip_station_count,
                "cap_area_count": reservoir.cap_area_count,
            }
        )
    return rows


def read_forcing_header_and_dates(path: Path) -> tuple[list[str], list[str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.reader(handle)
        header = next(reader)
        dates = [row[0] for row in reader if row]
    return dates, header[1:]


def build_forcing_mapping(columns: list[str], nodes: list[NodeRecord]) -> list[dict[str, str]]:
    node_by_id = {node.node_id: node for node in nodes}
    rows = []
    for column in columns:
        variable, _, station_id = column.partition("__")
        node = node_by_id.get(station_id)
        rows.append(
            {
                "column": column,
                "variable": variable,
                "station_id": station_id,
                "node_present": str(node is not None),
                "node_type": node.node_type if node else "",
                "node_type_label": NODE_TYPE_LABELS.get(node.node_type, "") if node else "",
                "node_name": node.name if node else "",
            }
        )
    return rows


def parse_monthly_targets(path: Path) -> dict[tuple[int, str], dict[str, list[float]]]:
    records: dict[tuple[int, str], list[list[float]]] = defaultdict(list)
    line_re = re.compile(r"^\s*(\d{4})\s+(\S+)\s+(.+)$")
    for line in iter_data_lines(path):
        match = line_re.match(line)
        if not match:
            continue
        water_year = int(match.group(1))
        reservoir_id = match.group(2)
        values = parse_numbers(match.group(3))
        if len(values) < 12:
            continue
        records[(water_year, reservoir_id)].append(values[:12])
    normalized: dict[tuple[int, str], dict[str, list[float]]] = {}
    for key, value_rows in records.items():
        min_values = value_rows[0] if value_rows else []
        max_values = value_rows[1] if len(value_rows) > 1 else []
        normalized[key] = {"min": min_values, "max": max_values}
    return normalized


def build_daily_target_rows(
    forcing_dates: list[str],
    target_records: dict[tuple[int, str], dict[str, list[float]]],
    reservoirs: list[ReservoirRecord],
) -> list[dict[str, str]]:
    capacity = {reservoir.reservoir_id: to_float(reservoir.content_max_acft) for reservoir in reservoirs}
    rows: list[dict[str, str]] = []
    for day_text in forcing_dates:
        current = datetime.strptime(day_text, "%Y-%m-%d").date()
        water_year, month_index = water_year_and_month_index(current)
        for reservoir in reservoirs:
            target = target_records.get((water_year, reservoir.reservoir_id), {})
            raw_min = value_at(target.get("min", []), month_index)
            raw_max = value_at(target.get("max", []), month_index)
            cap = capacity.get(reservoir.reservoir_id, 0.0)
            note_parts: list[str] = []
            effective_min = raw_min if raw_min is not None and raw_min >= 0 else 0.0
            if raw_min is not None and raw_min < 0:
                note_parts.append("negative_min_raw_replaced")
            if effective_min > cap:
                effective_min = cap
                note_parts.append("min_clamped_to_capacity")
            effective_max = raw_max if raw_max is not None and raw_max >= 0 else cap
            if raw_max is not None and raw_max < 0:
                note_parts.append("negative_max_raw_replaced")
            if effective_max > cap:
                effective_max = cap
                note_parts.append("max_clamped_to_capacity")
            if effective_max < effective_min:
                effective_max = effective_min
                note_parts.append("max_raised_to_min")
            rows.append(
                {
                    "date": day_text,
                    "reservoir_id": reservoir.reservoir_id,
                    "target_min_raw_acft": format_optional(raw_min),
                    "target_max_raw_acft": format_optional(raw_max),
                    "target_min_acft": format_float(effective_min),
                    "target_max_acft": format_float(effective_max),
                    "target_fill_note": ";".join(note_parts) if note_parts else "raw",
                }
            )
    return rows


def write_target_wide(path: Path, rows: list[dict[str, str]]) -> None:
    by_date: dict[str, dict[str, str]] = defaultdict(dict)
    reservoirs: list[str] = []
    seen = set()
    for row in rows:
        reservoir_id = row["reservoir_id"]
        if reservoir_id not in seen:
            seen.add(reservoir_id)
            reservoirs.append(reservoir_id)
        by_date[row["date"]][f"target_min__{reservoir_id}"] = row["target_min_acft"]
        by_date[row["date"]][f"target_max__{reservoir_id}"] = row["target_max_acft"]
    columns = [f"target_min__{reservoir_id}" for reservoir_id in reservoirs] + [
        f"target_max__{reservoir_id}" for reservoir_id in reservoirs
    ]
    wide_rows = []
    for day in sorted(by_date):
        wide_rows.append({"date": day, **{column: by_date[day].get(column, "") for column in columns}})
    write_csv(path, wide_rows, fieldnames=["date", *columns])


def build_manifest(
    node_rows: list[dict[str, str]],
    edge_rows: list[dict[str, str]],
    reservoir_rows: list[dict[str, str]],
    account_rows: list[dict[str, str]],
    cap_area_rows: list[dict[str, str]],
    forcing_dates: list[str],
    forcing_columns: list[str],
    target_rows: list[dict[str, str]],
) -> dict[str, object]:
    node_type_counts: dict[str, int] = defaultdict(int)
    for row in node_rows:
        node_type_counts[row["node_type"]] += 1
    return {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "dataset": "CDSS Upper Colorado StateMod Daily / Shoshone 2024",
        "time_step": "daily",
        "forcing_start": forcing_dates[0] if forcing_dates else "",
        "forcing_end": forcing_dates[-1] if forcing_dates else "",
        "forcing_day_count": len(forcing_dates),
        "forcing_column_count": len(forcing_columns),
        "node_count": len(node_rows),
        "edge_count": len(edge_rows),
        "node_type_counts": dict(sorted(node_type_counts.items())),
        "reservoir_count": len(reservoir_rows),
        "active_reservoir_count": sum(1 for row in reservoir_rows if row["active"] == "True"),
        "reservoir_account_count": len(account_rows),
        "capacity_area_row_count": len(cap_area_rows),
        "daily_target_row_count": len(target_rows),
        "files": [
            "nodes.csv",
            "edges.csv",
            "reservoirs.csv",
            "reservoir_accounts.csv",
            "reservoir_capacity_area.csv",
            "daily_forcing.csv",
            "forcing_mapping.csv",
            "daily_reservoir_targets.csv",
            "daily_reservoir_targets_wide.csv",
        ],
        "known_gap": "Daily reservoir storage/release/shortage labels require a StateMod build compatible with the 2024 Shoshone operating-right file.",
    }


def write_readme(out_dir: Path, manifest: dict[str, object]) -> None:
    lines = [
        "# CDSS Agent Dataset",
        "",
        "Agent-ready daily reservoir-group scheduling dataset derived from the CDSS Upper Colorado / Shoshone StateMod daily model.",
        "",
        "## Contents",
        "",
        "- `nodes.csv`: StateMod river-network nodes with corrected `_DIV/_RES/_ISF/_FLO/_OTH` type parsing.",
        "- `edges.csv`: directed downstream topology edges.",
        "- `reservoirs.csv`: reservoir capacities, release limits, initial storage and active flags.",
        "- `reservoir_accounts.csv`: StateMod reservoir ownership accounts.",
        "- `reservoir_capacity_area.csv`: storage-area-seepage curves.",
        "- `daily_forcing.csv`: complete daily stream-flow, diversion-demand and instream-demand forcing.",
        "- `forcing_mapping.csv`: forcing column to StateMod node mapping.",
        "- `daily_reservoir_targets.csv`: daily min/max target storage expanded from monthly StateMod targets.",
        "- `daily_reservoir_targets_wide.csv`: wide-form daily targets for fast environment loading.",
        "",
        "## Inventory",
        "",
        f"- Period: {manifest['forcing_start']} to {manifest['forcing_end']} ({manifest['forcing_day_count']} days).",
        f"- Nodes: {manifest['node_count']}; edges: {manifest['edge_count']}.",
        f"- Reservoirs: {manifest['reservoir_count']} total; {manifest['active_reservoir_count']} active.",
        f"- Forcing columns: {manifest['forcing_column_count']}.",
        "",
        "## Known Gap",
        "",
        str(manifest["known_gap"]),
        "",
    ]
    (out_dir / "README.md").write_text("\n".join(lines), encoding="utf-8")


def iter_data_lines(path: Path) -> Iterable[str]:
    in_data = False
    for line in read_lines(path):
        if line.strip().startswith("#>EndHeader"):
            in_data = True
            continue
        if not in_data or not line.strip() or line.lstrip().startswith("#"):
            continue
        yield line.rstrip("\n")


def read_lines(path: Path) -> Iterable[str]:
    for encoding in ("utf-8", "latin-1", "cp1252"):
        try:
            yield from path.read_text(encoding=encoding, errors="ignore").splitlines()
            return
        except Exception:
            continue


def write_csv(path: Path, rows: list[dict[str, str]], fieldnames: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = []
        for row in rows:
            for key in row:
                if key not in fieldnames:
                    fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def field(line: str, start: int, end: int | None) -> str:
    return field_raw(line, start, end).strip()


def field_raw(line: str, start: int, end: int | None) -> str:
    if start >= len(line):
        return ""
    return line[start:end] if end is not None else line[start:]


def parse_numbers(text: str) -> list[float]:
    values = []
    for token in text.split():
        try:
            values.append(float(token))
        except ValueError:
            continue
    return values


def to_float(value: object, default: float = 0.0) -> float:
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return default


def format_float(value: float) -> str:
    return f"{value:.6g}"


def format_optional(value: float | None) -> str:
    return "" if value is None else format_float(value)


def value_at(values: list[float], index: int) -> float | None:
    if 0 <= index < len(values):
        return values[index]
    return None


def water_year_and_month_index(day: date) -> tuple[int, int]:
    if day.month >= 10:
        return day.year + 1, day.month - 10
    return day.year, day.month + 2


if __name__ == "__main__":
    main()
