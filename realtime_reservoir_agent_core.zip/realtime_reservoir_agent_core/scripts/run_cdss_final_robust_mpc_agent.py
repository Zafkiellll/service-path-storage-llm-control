from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import sys
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from realtime_reservoir_agent import (  # noqa: E402
    DailyReservoirEnvironment,
    StructuredChatClientConfig,
    StructuredChatDeliberationClient,
    StructuredChatNetworkBudgetExceeded,
    StructuredChatReplayCacheMiss,
    EventTriggeredMultiSkillDeliberationLayer,
    ForecastCausalRobustMpcAgent,
    MultiSkillDeliberationLayer,
    PROMPT_VERSION,
    RobustIntentMpcPlanner,
    SeasonalAnalogEnsembleForecaster,
    StructuredLlmDeliberationBackend,
)
from realtime_reservoir_agent.semantic_contract_library import (  # noqa: E402
    FrozenSemanticContractLibraryBackend,
)


DEFAULT_DATASET = ROOT / "data_candidates" / "processed" / "cdss_agent_dataset"
DEFAULT_OUT = DEFAULT_DATASET / "final_robust_mpc_runs"


def main() -> None:
    parser = argparse.ArgumentParser(description="Run final forecast-causal robust-MPC reservoir agent.")
    parser.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--start-date", default="1987-10-01")
    parser.add_argument("--max-steps", type=int, default=0)
    parser.add_argument(
        "--initial-storage-json",
        type=Path,
        help="Optional reservoir-id to storage mapping applied after reset for counterfactual initialization.",
    )
    parser.add_argument(
        "--exclude-reservoirs",
        default="",
        help="Comma-separated reservoir ids to exclude from physical control/storage accounting.",
    )
    parser.add_argument(
        "--clamp-negative-streamflow",
        action="store_true",
        help="Clamp negative stream-base-flow forcing values to zero for sensitivity analysis.",
    )
    parser.add_argument("--horizon-days", type=int, default=7)
    parser.add_argument("--ensemble-size", type=int, default=12)
    parser.add_argument("--analog-window-days", type=int, default=21)
    parser.add_argument("--disable-deliberation", action="store_true")
    parser.add_argument("--disable-negotiation", action="store_true")
    parser.add_argument("--disable-conflict-graph", action="store_true")
    parser.add_argument("--event-triggered-deliberation", action="store_true")
    parser.add_argument("--semantic-novelty-threshold", type=float, default=0.16)
    parser.add_argument("--semantic-trigger-threshold", type=float, default=0.22)
    parser.add_argument("--semantic-contract-max-age-days", type=int, default=14)
    parser.add_argument("--semantic-minimum-support-validity", type=float, default=0.55)
    parser.add_argument("--semantic-conflict-escalation-threshold", type=float, default=0.18)
    parser.add_argument("--semantic-modifier-decay-rate", type=float, default=0.0)
    parser.add_argument("--semantic-safety-veto-streak", type=int, default=3)
    parser.add_argument("--semantic-safety-requery-cooldown-days", type=int, default=7)
    parser.add_argument("--semantic-safety-dual-drift-threshold", type=float, default=0.15)
    parser.add_argument(
        "--deliberation-backend",
        choices=("deterministic", "structured_chat", "contract_library"),
        default="deterministic",
    )
    parser.add_argument(
        "--contract-library-path",
        type=Path,
        default=ROOT / "experiments" / "semantic_contract_v3" / "frozen_semantic_contract_library.json",
    )
    parser.add_argument("--contract-library-max-candidates", type=int, default=80)
    parser.add_argument("--contract-library-min-score", type=float, default=0.24)
    parser.add_argument("--structured_chat-model", default=os.environ.get("LLM_MODEL", "gpt-5"))
    parser.add_argument("--structured_chat-base-url", default=os.environ.get("LLM_BASE_URL", ""))
    parser.add_argument("--structured_chat-cache-dir", type=Path)
    parser.add_argument("--structured_chat-timeout-seconds", type=float, default=90.0)
    parser.add_argument("--structured_chat-max-tokens", type=int, default=1400)
    parser.add_argument("--structured_chat-reasoning-effort", choices=("low", "medium", "high"), default="medium")
    parser.add_argument("--structured_chat-thinking", choices=("enabled", "disabled"), default="disabled")
    parser.add_argument("--structured_chat-force-refresh", action="store_true")
    parser.add_argument("--structured_chat-max-network-calls", type=int, default=1600)
    parser.add_argument("--structured_chat-replay-only", action="store_true")
    parser.add_argument("--allow-paid-full-run", action="store_true")
    parser.add_argument("--confirmatory-protocol", type=Path)
    parser.add_argument("--max-deliberation-rounds", type=int, default=1)
    parser.add_argument("--certificate-requery-service-regret-cfs", type=float, default=75.0)
    parser.add_argument("--certificate-requery-reserve-violation-acft", type=float, default=50000.0)
    parser.add_argument(
        "--certificate-requery-actions",
        default="service_override",
        help="Comma-separated certificate actions that trigger same-day re-deliberation.",
    )
    parser.add_argument(
        "--redeliberation-acceptance-mode",
        choices=("last", "certificate_score"),
        default="last",
    )
    parser.add_argument("--redeliberation-score-tolerance", type=float, default=0.0)
    parser.add_argument(
        "--shadow-baseline-mode",
        choices=("disabled", "certificate_score", "hydrologic_regret", "trained_admissibility"),
        default="disabled",
    )
    parser.add_argument("--shadow-score-tolerance", type=float, default=0.0)
    parser.add_argument("--hydrologic-admissibility-policy", type=Path)
    parser.add_argument("--hydrologic-supervisor-decay", type=float, default=0.985)
    parser.add_argument("--hydrologic-supervisor-score-limit", type=float, default=45.0)
    parser.add_argument("--hydrologic-supervisor-service-limit-cfs", type=float, default=55.0)
    parser.add_argument("--hydrologic-supervisor-reserve-limit-acft", type=float, default=60000.0)
    parser.add_argument("--viability-floor-fraction", type=float, default=0.25)
    parser.add_argument("--service-ledger-scale-cfs-days", type=float, default=1000.0)
    parser.add_argument("--reserve-ledger-scale-acft", type=float, default=100000.0)
    parser.add_argument("--mpc-risk-weight", type=float, default=0.55)
    parser.add_argument("--mpc-worst-weight", type=float, default=0.10)
    parser.add_argument("--strategic-reserve-weight", type=float, default=6.0)
    parser.add_argument("--ledger-decay", type=float, default=0.995)
    parser.add_argument("--reserve-repayment-fraction", type=float, default=0.08)
    parser.add_argument("--ledger-recovery-fraction", type=float, default=0.20)
    parser.add_argument(
        "--supply-guarantee-fraction",
        type=float,
        default=0.0,
        help="If positive, enforce a same-day node-level guarantee on monitored supply nodes.",
    )
    parser.add_argument(
        "--supply-guarantee-nodes",
        default="3604684,5104700",
        help="Comma-separated diversion node ids covered by the supply-guarantee certificate.",
    )
    parser.add_argument(
        "--disable-supply-reserve-guard",
        action="store_true",
        help="Disable topology-local reserve protection for supply-guaranteed nodes.",
    )
    parser.add_argument(
        "--supply-reserve-guard-mode",
        choices=("always", "forecast_risk", "forecast_risk_or_local_storage"),
        default="always",
        help="When enabled, choose whether local supply reserve guard is always active, forecast-risk triggered, or also local-storage triggered.",
    )
    parser.add_argument(
        "--supply-reserve-guard-min-demand-cfs",
        type=float,
        default=0.0,
        help="Minimum forecast demand at a monitored node needed to activate forecast-risk reserve guard.",
    )
    parser.add_argument(
        "--supply-reserve-guard-local-storage-fraction",
        type=float,
        default=0.0,
        help="Activate supply reserve guard when local priority-reservoir storage fraction is at or below this value.",
    )
    parser.add_argument(
        "--supply-path-viability-mode",
        choices=("disabled", "adaptive_envelope"),
        default="disabled",
        help="Enable a path-specific cross-day storage envelope in the physical certificate.",
    )
    parser.add_argument("--supply-path-viability-base-fraction", type=float, default=0.35)
    parser.add_argument("--supply-path-viability-max-fraction", type=float, default=0.75)
    parser.add_argument("--supply-path-viability-memory-days", type=float, default=180.0)
    parser.add_argument("--supply-path-viability-demand-lookahead-days", type=int, default=180)
    parser.add_argument("--supply-path-viability-demand-reserve-fraction", type=float, default=0.35)
    parser.add_argument("--supply-path-viability-forecast-multiplier", type=float, default=1.0)
    parser.add_argument(
        "--certificate-mode",
        choices=(
            "full",
            "mpc_only",
            "no_service_override",
            "no_ledger",
            "no_viability_boundary",
        ),
        default="full",
    )
    args = parser.parse_args()
    protocol_payload: dict[str, object] | None = None
    protocol_hash = ""
    if args.confirmatory_protocol is not None:
        protocol_payload, protocol_hash = validate_confirmatory_protocol(
            args,
            args.confirmatory_protocol,
        )
    hydrologic_admissibility_policy: dict[str, object] | None = None
    if args.hydrologic_admissibility_policy is not None:
        hydrologic_admissibility_policy = json.loads(
            args.hydrologic_admissibility_policy.read_text(encoding="utf-8")
        )

    if args.disable_deliberation and args.deliberation_backend == "structured_chat":
        parser.error("--disable-deliberation cannot be combined with --deliberation-backend structured_chat.")
    if args.disable_deliberation and args.event_triggered_deliberation:
        parser.error("--disable-deliberation cannot be combined with --event-triggered-deliberation.")
    if (
        args.deliberation_backend == "structured_chat"
        and args.max_steps <= 0
        and not args.allow_paid_full_run
    ):
        parser.error(
            "StructuredChat full-sequence execution may issue 9496 paid calls. "
            "Set --max-steps or explicitly pass --allow-paid-full-run."
        )

    args.out.mkdir(parents=True, exist_ok=True)
    if protocol_payload is not None:
        (args.out / "frozen_confirmatory_protocol.json").write_text(
            json.dumps(protocol_payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    excluded_reservoirs = tuple(
        reservoir_id.strip()
        for reservoir_id in args.exclude_reservoirs.split(",")
        if reservoir_id.strip()
    )
    reservoir_ids = (
        selected_reservoir_ids(args.dataset, excluded_reservoirs)
        if excluded_reservoirs
        else None
    )
    env = DailyReservoirEnvironment(
        args.dataset,
        reservoir_ids=reservoir_ids,
        forecast_horizon_days=args.horizon_days,
        clamp_negative_streamflow=args.clamp_negative_streamflow,
    )
    env.reset(args.start_date)
    initial_storage_override: dict[str, float] = {}
    initial_storage_override_hash = ""
    if args.initial_storage_json is not None:
        raw_initial_storage = json.loads(args.initial_storage_json.read_text(encoding="utf-8"))
        if isinstance(raw_initial_storage, dict) and "storage_acft" in raw_initial_storage:
            raw_initial_storage = raw_initial_storage["storage_acft"]
        if not isinstance(raw_initial_storage, dict):
            parser.error("--initial-storage-json must contain an object keyed by reservoir id.")
        unknown_reservoirs = sorted(set(str(key) for key in raw_initial_storage) - set(env.reservoir_ids))
        if unknown_reservoirs:
            parser.error(
                "--initial-storage-json contains excluded or unknown reservoirs: "
                + ",".join(unknown_reservoirs)
            )
        for reservoir_id, raw_value in raw_initial_storage.items():
            value = float(raw_value)
            spec = env.reservoir_specs[str(reservoir_id)]
            if value < spec.storage_min_acft - 1e-6 or value > spec.storage_max_acft + 1e-6:
                parser.error(
                    f"Initial storage {value} for {reservoir_id} is outside "
                    f"[{spec.storage_min_acft}, {spec.storage_max_acft}]."
                )
            initial_storage_override[str(reservoir_id)] = value
        env.storage_acft.update(initial_storage_override)
        initial_storage_override_hash = hashlib.sha256(
            json.dumps(
                initial_storage_override,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
        ).hexdigest()
    forecaster = SeasonalAnalogEnsembleForecaster(
        env,
        horizon_days=args.horizon_days,
        ensemble_size=args.ensemble_size,
        analog_window_days=args.analog_window_days,
    )
    structured_chat_client: StructuredChatDeliberationClient | None = None
    contract_library_backend: FrozenSemanticContractLibraryBackend | None = None
    deliberation_backend = None
    deliberation_layer = None
    if args.deliberation_backend == "structured_chat":
        cache_dir = args.structured_chat_cache_dir or (
            args.dataset / "llm_cache" / args.structured_chat_model.replace("/", "_")
        )
        structured_chat_client = StructuredChatDeliberationClient(
            StructuredChatClientConfig(
                model=args.structured_chat_model,
                base_url=args.structured_chat_base_url,
                timeout_seconds=args.structured_chat_timeout_seconds,
                max_tokens=args.structured_chat_max_tokens,
                reasoning_effort=args.structured_chat_reasoning_effort,
                thinking_enabled=args.structured_chat_thinking == "enabled",
                cache_dir=cache_dir,
                force_refresh=args.structured_chat_force_refresh,
                max_network_calls=(
                    args.structured_chat_max_network_calls
                    if args.structured_chat_max_network_calls > 0
                    else None
                ),
                replay_only=args.structured_chat_replay_only,
            )
        )
        deliberation_backend = StructuredLlmDeliberationBackend(structured_chat_client)
    elif args.deliberation_backend == "contract_library":
        contract_library_backend = FrozenSemanticContractLibraryBackend(
            args.contract_library_path,
            max_ranked_candidates=args.contract_library_max_candidates,
            minimum_accept_score=args.contract_library_min_score,
        )
        deliberation_backend = contract_library_backend
    if args.event_triggered_deliberation:
        deliberation_layer = EventTriggeredMultiSkillDeliberationLayer(
            backend=deliberation_backend,
            enable_conflict_graph=not args.disable_conflict_graph,
            novelty_threshold=args.semantic_novelty_threshold,
            trigger_threshold=args.semantic_trigger_threshold,
            max_contract_age_days=args.semantic_contract_max_age_days,
            minimum_support_validity=args.semantic_minimum_support_validity,
            conflict_escalation_threshold=args.semantic_conflict_escalation_threshold,
            modifier_decay_rate=args.semantic_modifier_decay_rate,
            safety_veto_streak_threshold=args.semantic_safety_veto_streak,
            safety_requery_cooldown_days=args.semantic_safety_requery_cooldown_days,
            safety_dual_drift_threshold=args.semantic_safety_dual_drift_threshold,
        )
    elif deliberation_backend is not None:
        deliberation_layer = MultiSkillDeliberationLayer(
            backend=deliberation_backend,
            enable_conflict_graph=not args.disable_conflict_graph,
        )

    agent = ForecastCausalRobustMpcAgent(
        forecaster,
        planner=RobustIntentMpcPlanner(
            risk_weight=args.mpc_risk_weight,
            worst_weight=args.mpc_worst_weight,
            strategic_reserve_weight=args.strategic_reserve_weight,
            viability_floor_fraction=args.viability_floor_fraction,
            service_ledger_scale_cfs_days=args.service_ledger_scale_cfs_days,
            reserve_ledger_scale_acft=args.reserve_ledger_scale_acft,
            ledger_decay=args.ledger_decay,
            reserve_repayment_fraction=args.reserve_repayment_fraction,
            ledger_recovery_fraction=args.ledger_recovery_fraction,
            certificate_mode=args.certificate_mode,
            supply_guarantee_fraction=args.supply_guarantee_fraction,
            supply_guarantee_nodes=tuple(
                node_id.strip()
                for node_id in args.supply_guarantee_nodes.split(",")
                if node_id.strip()
            ),
            enable_supply_reserve_guard=not args.disable_supply_reserve_guard,
            supply_reserve_guard_mode=args.supply_reserve_guard_mode,
            supply_reserve_guard_min_demand_cfs=args.supply_reserve_guard_min_demand_cfs,
            supply_reserve_guard_local_storage_fraction=args.supply_reserve_guard_local_storage_fraction,
            supply_path_viability_mode=args.supply_path_viability_mode,
            supply_path_viability_base_fraction=args.supply_path_viability_base_fraction,
            supply_path_viability_max_fraction=args.supply_path_viability_max_fraction,
            supply_path_viability_memory_days=args.supply_path_viability_memory_days,
            supply_path_viability_demand_lookahead_days=(
                args.supply_path_viability_demand_lookahead_days
            ),
            supply_path_viability_demand_reserve_fraction=(
                args.supply_path_viability_demand_reserve_fraction
            ),
            supply_path_viability_forecast_multiplier=(
                args.supply_path_viability_forecast_multiplier
            ),
        ),
        deliberation_layer=deliberation_layer,
        enable_deliberation=not args.disable_deliberation,
        enable_negotiation=not args.disable_negotiation,
        max_deliberation_rounds=args.max_deliberation_rounds,
        certificate_requery_service_regret_cfs=args.certificate_requery_service_regret_cfs,
        certificate_requery_reserve_violation_acft=args.certificate_requery_reserve_violation_acft,
        certificate_requery_actions=tuple(
            item.strip()
            for item in args.certificate_requery_actions.split(",")
            if item.strip()
        ),
        redeliberation_acceptance_mode=args.redeliberation_acceptance_mode,
        redeliberation_score_tolerance=args.redeliberation_score_tolerance,
        shadow_baseline_mode=args.shadow_baseline_mode,
        shadow_score_tolerance=args.shadow_score_tolerance,
        hydrologic_supervisor_decay=args.hydrologic_supervisor_decay,
        hydrologic_supervisor_score_limit=args.hydrologic_supervisor_score_limit,
        hydrologic_supervisor_service_limit_cfs=args.hydrologic_supervisor_service_limit_cfs,
        hydrologic_supervisor_reserve_limit_acft=args.hydrologic_supervisor_reserve_limit_acft,
        hydrologic_admissibility_policy=hydrologic_admissibility_policy,
    )

    steps_available = len(env.forcing_dates) - env.date_index - 1
    step_count = steps_available if args.max_steps <= 0 else min(args.max_steps, steps_available)
    trace_rows: list[dict[str, str]] = []
    release_rows: list[dict[str, str]] = []
    storage_rows: list[dict[str, str]] = []
    candidate_rows: list[dict[str, str]] = []
    skill_claim_rows: list[dict[str, str]] = []
    skill_conflict_rows: list[dict[str, str]] = []
    intent_counts: Counter[str] = Counter()
    certificate_counts: Counter[str] = Counter()
    negotiation_counts: Counter[str] = Counter()
    deliberation_counts: Counter[str] = Counter()
    deliberation_backend_counts: Counter[str] = Counter()
    termination_reason = "completed"
    deliberation_event_source = structured_chat_client or contract_library_backend

    for _ in range(step_count):
        deliberation_event_cursor = (
            len(deliberation_event_source.events)
            if deliberation_event_source is not None
            else 0
        )
        try:
            decision = agent.decide(env)
        except StructuredChatNetworkBudgetExceeded as exc:
            termination_reason = (
                f"structured_chat_network_budget_exhausted:"
                f"{exc.network_call_count}/{exc.max_network_calls}"
            )
            break
        except StructuredChatReplayCacheMiss as exc:
            termination_reason = f"structured_chat_replay_cache_miss:{exc.request_hash}"
            break
        intent_dict = decision.intent.as_dict()
        intent_counts[decision.intent.primary_intent] += 1
        certificate_counts[str(decision.diagnostics["certificate_selected_action"])] += 1
        negotiation_counts[str(decision.diagnostics["negotiation_status"])] += 1
        deliberation_counts[str(decision.diagnostics["deliberation_dominant_intent"])] += 1
        deliberation_backend_counts[str(decision.diagnostics["deliberation_backend"])] += 1
        result = env.step(decision.releases_cfs, intent_override=compact_intent_for_step(intent_dict))
        diag = decision.diagnostics
        if deliberation_event_source is not None:
            for event in deliberation_event_source.events[deliberation_event_cursor:]:
                event.update(
                    {
                        "date": result.date,
                        "accepted_contract_hash": str(diag["deliberation_policy_contract_hash"]),
                        "accepted_backend": str(diag["deliberation_backend"]),
                        "schema_valid": bool(diag["deliberation_schema_valid"]),
                        "evidence_bound": bool(diag["deliberation_evidence_bound"]),
                        "semantic_state_hash": str(diag["deliberation_semantic_state_hash"]),
                        "semantic_trigger_reasons": str(diag["deliberation_trigger_reasons"]),
                        "contract_schema_version": str(
                            diag["deliberation_contract_schema_version"]
                        ),
                        "llm_deliberation_round_count": float(
                            diag["llm_deliberation_round_count"]
                        ),
                        "llm_redeliberation_triggered": bool(
                            diag["llm_redeliberation_triggered"]
                        ),
                        "llm_final_round_index": float(diag["llm_final_round_index"]),
                        "validity_profile": {
                            "watch_features": str(
                                diag["deliberation_watch_features"]
                            ).split(","),
                            "novelty_tolerance": float(
                                diag["deliberation_validity_radius"]
                            ),
                            "max_age_days": int(
                                float(diag["deliberation_requested_max_age_days"])
                            ),
                            "safety_review_mode": str(
                                diag["deliberation_safety_review_mode"]
                            ),
                        },
                    }
                )
        for claim in diag["deliberation_claims"]:
            skill_claim_rows.append(
                {
                    "date": result.date,
                    "skill_name": str(claim["skill_name"]),
                    "supported_intent": str(claim["supported_intent"]),
                    "priority": fmt(claim["priority"]),
                    "confidence": fmt(claim["confidence"]),
                    "support_budget_cfs": fmt(claim["support_budget_cfs"]),
                    "buffer_budget_cfs": fmt(claim["buffer_budget_cfs"]),
                    "reserve_delta_acft": fmt(claim["reserve_delta_acft"]),
                    "risk_delta": fmt(claim["risk_delta"]),
                    "rationale": str(claim["rationale"]),
                    "evidence_json": json.dumps(claim["evidence"], ensure_ascii=False, sort_keys=True),
                }
            )
        for conflict in diag["deliberation_conflicts"]:
            skill_conflict_rows.append(
                {
                    "date": result.date,
                    "source_skill": str(conflict["source_skill"]),
                    "target_skill": str(conflict["target_skill"]),
                    "conflict_type": str(conflict["conflict_type"]),
                    "severity": fmt(conflict["severity"]),
                    "evidence_json": json.dumps(conflict["evidence"], ensure_ascii=False, sort_keys=True),
                }
            )
        trace_rows.append(
            {
                "date": result.date,
                "next_date": result.next_date,
                "primary_intent": decision.intent.primary_intent,
                "evidence_chain": decision.intent.evidence_chain(),
                "forecast_member_count": fmt(decision.forecast.member_count),
                "forecast_fallback_used": fmt(1.0 if decision.forecast.fallback_used else 0.0),
                "storage_ratio": fmt(decision.intent.pressures["storage_ratio"]),
                "target_surplus_ratio": fmt(decision.intent.pressures["target_surplus_ratio"]),
                "target_encroachment_ratio": fmt(decision.intent.pressures["target_encroachment_ratio"]),
                "forecast_shortage_pressure": fmt(decision.intent.pressures["forecast_shortage_pressure"]),
                "ecology_pressure": fmt(decision.intent.pressures["ecology_pressure"]),
                "drought_pressure": fmt(decision.intent.pressures["drought_pressure"]),
                "mpc_candidate_id": str(diag["mpc_candidate_id"]),
                "mpc_planning_intent": str(diag["mpc_planning_intent"]),
                "mpc_robust_cost": fmt(diag["mpc_robust_cost"]),
                "mpc_mean_cost": fmt(diag["mpc_mean_cost"]),
                "mpc_cvar_cost": fmt(diag["mpc_cvar_cost"]),
                "mpc_worst_cost": fmt(diag["mpc_worst_cost"]),
                "mpc_candidate_count": fmt(diag["mpc_candidate_count"]),
                "mpc_risk_weight": fmt(diag["mpc_risk_weight"]),
                "mpc_worst_weight": fmt(diag["mpc_worst_weight"]),
                "mpc_strategic_reserve_weight": fmt(diag["mpc_strategic_reserve_weight"]),
                "deliberation_backend": str(diag["deliberation_backend"]),
                "deliberation_active_skill_count": fmt(diag["deliberation_active_skill_count"]),
                "deliberation_active_skills": str(diag["deliberation_active_skills"]),
                "deliberation_conflict_count": fmt(diag["deliberation_conflict_count"]),
                "deliberation_dominant_intent": str(diag["deliberation_dominant_intent"]),
                "deliberation_auxiliary_intents": str(diag["deliberation_auxiliary_intents"]),
                "deliberation_risk_posture": str(diag["deliberation_risk_posture"]),
                "deliberation_support_multiplier": fmt(diag["deliberation_support_multiplier"]),
                "deliberation_buffer_multiplier": fmt(diag["deliberation_buffer_multiplier"]),
                "deliberation_reserve_delta_acft": fmt(diag["deliberation_reserve_delta_acft"]),
                "deliberation_risk_aversion_delta": fmt(diag["deliberation_risk_aversion_delta"]),
                "deliberation_schema_valid": fmt(diag["deliberation_schema_valid"]),
                "deliberation_evidence_bound": fmt(diag["deliberation_evidence_bound"]),
                "deliberation_max_claim_priority": fmt(diag["deliberation_max_claim_priority"]),
                "deliberation_total_claim_support_cfs": fmt(diag["deliberation_total_claim_support_cfs"]),
                "deliberation_total_claim_reserve_acft": fmt(diag["deliberation_total_claim_reserve_acft"]),
                "deliberation_policy_contract_hash": str(diag["deliberation_policy_contract_hash"]),
                "deliberation_influence_score": fmt(diag["deliberation_influence_score"]),
                "deliberation_event_triggered": fmt(diag["deliberation_event_triggered"]),
                "deliberation_trigger_score": fmt(diag["deliberation_trigger_score"]),
                "deliberation_trigger_reasons": str(diag["deliberation_trigger_reasons"]),
                "deliberation_contract_age_days": fmt(diag["deliberation_contract_age_days"]),
                "deliberation_state_novelty": fmt(diag["deliberation_state_novelty"]),
                "deliberation_contract_reused": fmt(diag["deliberation_contract_reused"]),
                "deliberation_support_validity": fmt(diag["deliberation_support_validity"]),
                "deliberation_semantic_state_hash": str(diag["deliberation_semantic_state_hash"]),
                "deliberation_contract_schema_version": str(
                    diag["deliberation_contract_schema_version"]
                ),
                "deliberation_watch_features": str(diag["deliberation_watch_features"]),
                "deliberation_validity_radius": fmt(diag["deliberation_validity_radius"]),
                "deliberation_requested_max_age_days": fmt(
                    diag["deliberation_requested_max_age_days"]
                ),
                "deliberation_safety_review_mode": str(
                    diag["deliberation_safety_review_mode"]
                ),
                "deliberation_evidence_citations_json": json.dumps(
                    diag["deliberation_evidence_citations"],
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                "deliberation_conflict_resolutions_json": json.dumps(
                    diag["deliberation_conflict_resolutions"],
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                "deliberation_decision_steps_json": json.dumps(
                    diag["deliberation_decision_steps"],
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                "deliberation_trace": str(diag["deliberation_trace"]),
                "llm_deliberation_round_count": fmt(diag["llm_deliberation_round_count"]),
                "llm_redeliberation_triggered": fmt(diag["llm_redeliberation_triggered"]),
                "llm_final_round_index": fmt(diag["llm_final_round_index"]),
                "llm_accepted_round_index": fmt(diag["llm_accepted_round_index"]),
                "llm_round_acceptance_mode": str(diag["llm_round_acceptance_mode"]),
                "llm_round_score_reverted": fmt(diag["llm_round_score_reverted"]),
                "llm_accepted_round_score": fmt(diag["llm_accepted_round_score"]),
                "llm_redeliberation_reasons": str(diag["llm_redeliberation_reasons"]),
                "llm_rounds_json": json.dumps(
                    diag["llm_rounds_json"],
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                "shadow_supervisor_mode": str(diag.get("shadow_supervisor_mode", "disabled")),
                "shadow_supervisor_selected_source": str(
                    diag.get("shadow_supervisor_selected_source", "semantic_contract")
                ),
                "shadow_supervisor_selected_shadow": fmt(
                    diag.get("shadow_supervisor_selected_shadow", 0.0)
                ),
                "shadow_supervisor_semantic_score": fmt(
                    diag.get("shadow_supervisor_semantic_score", 0.0)
                ),
                "shadow_supervisor_shadow_score": fmt(
                    diag.get("shadow_supervisor_shadow_score", 0.0)
                ),
                "shadow_supervisor_score_delta": fmt(
                    diag.get("shadow_supervisor_score_delta", 0.0)
                ),
                "shadow_semantic_selected_action": str(
                    diag.get("shadow_semantic_selected_action", "")
                ),
                "shadow_semantic_shortage_after_cfs": fmt(
                    diag.get("shadow_semantic_shortage_after_cfs", 0.0)
                ),
                "shadow_semantic_reserve_violation_acft": fmt(
                    diag.get("shadow_semantic_reserve_violation_acft", 0.0)
                ),
                "hydrologic_supervisor_mode": str(diag.get("hydrologic_supervisor_mode", "disabled")),
                "hydrologic_supervisor_regime_key": str(
                    diag.get("hydrologic_supervisor_regime_key", "")
                ),
                "hydrologic_supervisor_season": str(
                    diag.get("hydrologic_supervisor_season", "")
                ),
                "hydrologic_supervisor_storage_regime": str(
                    diag.get("hydrologic_supervisor_storage_regime", "")
                ),
                "hydrologic_supervisor_shortage_regime": str(
                    diag.get("hydrologic_supervisor_shortage_regime", "")
                ),
                "hydrologic_supervisor_ecology_regime": str(
                    diag.get("hydrologic_supervisor_ecology_regime", "")
                ),
                "hydrologic_supervisor_wetness_regime": str(
                    diag.get("hydrologic_supervisor_wetness_regime", "")
                ),
                "hydrologic_supervisor_admission_rule": str(
                    diag.get("hydrologic_supervisor_admission_rule", "")
                ),
                "hydrologic_supervisor_score_delta": fmt(
                    diag.get("hydrologic_supervisor_score_delta", 0.0)
                ),
                "hydrologic_supervisor_service_delta_cfs": fmt(
                    diag.get("hydrologic_supervisor_service_delta_cfs", 0.0)
                ),
                "hydrologic_supervisor_reserve_delta_acft": fmt(
                    diag.get("hydrologic_supervisor_reserve_delta_acft", 0.0)
                ),
                "hydrologic_supervisor_next_storage_delta_acft": fmt(
                    diag.get("hydrologic_supervisor_next_storage_delta_acft", 0.0)
                ),
                "hydrologic_supervisor_semantic_next_storage_acft": fmt(
                    diag.get("hydrologic_supervisor_semantic_next_storage_acft", 0.0)
                ),
                "hydrologic_supervisor_shadow_next_storage_acft": fmt(
                    diag.get("hydrologic_supervisor_shadow_next_storage_acft", 0.0)
                ),
                "hydrologic_supervisor_score_debt_before": fmt(
                    diag.get("hydrologic_supervisor_score_debt_before", 0.0)
                ),
                "hydrologic_supervisor_score_debt_after": fmt(
                    diag.get("hydrologic_supervisor_score_debt_after", 0.0)
                ),
                "hydrologic_supervisor_score_credit_after": fmt(
                    diag.get("hydrologic_supervisor_score_credit_after", 0.0)
                ),
                "hydrologic_supervisor_service_debt_after_cfs": fmt(
                    diag.get("hydrologic_supervisor_service_debt_after_cfs", 0.0)
                ),
                "hydrologic_supervisor_reserve_debt_after_acft": fmt(
                    diag.get("hydrologic_supervisor_reserve_debt_after_acft", 0.0)
                ),
                "hydrologic_supervisor_score_limit": fmt(
                    diag.get("hydrologic_supervisor_score_limit", 0.0)
                ),
                "hydrologic_supervisor_service_limit_cfs": fmt(
                    diag.get("hydrologic_supervisor_service_limit_cfs", 0.0)
                ),
                "hydrologic_supervisor_reserve_limit_acft": fmt(
                    diag.get("hydrologic_supervisor_reserve_limit_acft", 0.0)
                ),
                "hydrologic_supervisor_regime_observations": fmt(
                    diag.get("hydrologic_supervisor_regime_observations", 0.0)
                ),
                "hydrologic_supervisor_semantic_selected_days": fmt(
                    diag.get("hydrologic_supervisor_semantic_selected_days", 0.0)
                ),
                "hydrologic_supervisor_shadow_selected_days": fmt(
                    diag.get("hydrologic_supervisor_shadow_selected_days", 0.0)
                ),
                "hydrologic_supervisor_regime_label": str(
                    diag.get("hydrologic_supervisor_regime_label", "")
                ),
                "trained_admissibility_policy_id": str(
                    diag.get("trained_admissibility_policy_id", "")
                ),
                "trained_admissibility_training_end_date": str(
                    diag.get("trained_admissibility_training_end_date", "")
                ),
                "trained_admissibility_test_start_date": str(
                    diag.get("trained_admissibility_test_start_date", "")
                ),
                "trained_admissibility_state_key": str(
                    diag.get("trained_admissibility_state_key", "")
                ),
                "trained_admissibility_matched_rule_count": fmt(
                    diag.get("trained_admissibility_matched_rule_count", 0.0)
                ),
                "trained_admissibility_benefit_rule_count": fmt(
                    diag.get("trained_admissibility_benefit_rule_count", 0.0)
                ),
                "trained_admissibility_fragile_rule_count": fmt(
                    diag.get("trained_admissibility_fragile_rule_count", 0.0)
                ),
                "trained_admissibility_strongest_benefit_cfs": fmt(
                    diag.get("trained_admissibility_strongest_benefit_cfs", 0.0)
                ),
                "trained_admissibility_strongest_fragility_cfs": fmt(
                    diag.get("trained_admissibility_strongest_fragility_cfs", 0.0)
                ),
                "trained_admissibility_matched_rules_json": json.dumps(
                    diag.get("trained_admissibility_matched_rules_json", []),
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                "negotiation_status": str(diag["negotiation_status"]),
                "negotiation_rounds": fmt(diag["negotiation_rounds"]),
                "negotiation_initial_support_cfs": fmt(diag["negotiation_initial_support_cfs"]),
                "negotiation_final_support_cfs": fmt(diag["negotiation_final_support_cfs"]),
                "negotiation_reserve_target_acft": fmt(diag["negotiation_reserve_target_acft"]),
                "negotiation_hard_safety_floor_acft": fmt(diag["negotiation_hard_safety_floor_acft"]),
                "negotiation_support_acceptance_ratio": fmt(diag["negotiation_support_acceptance_ratio"]),
                "negotiation_routed_service_gain_cfs": fmt(diag["negotiation_routed_service_gain_cfs"]),
                "negotiation_support_gap_cfs": fmt(diag["negotiation_support_gap_cfs"]),
                "negotiation_feasible_release_cfs": fmt(diag["negotiation_feasible_release_cfs"]),
                "negotiation_marginal_service_efficiency": fmt(diag["negotiation_marginal_service_efficiency"]),
                "negotiation_limiting_factor": str(diag["negotiation_limiting_factor"]),
                "certificate_mode": str(diag["certificate_mode"]),
                "certificate_selected_action": str(diag["certificate_selected_action"]),
                "certificate_pre_supply_selected_action": str(
                    diag.get("certificate_pre_supply_selected_action", "")
                ),
                "certificate_mpc_shortage_after_cfs": fmt(diag["certificate_mpc_shortage_after_cfs"]),
                "certificate_anchor_shortage_after_cfs": fmt(diag["certificate_anchor_shortage_after_cfs"]),
                "certificate_raw_anchor_shortage_after_cfs": fmt(diag["certificate_raw_anchor_shortage_after_cfs"]),
                "certificate_service_gap_cfs": fmt(diag["certificate_service_gap_cfs"]),
                "certificate_storage_gain_acft": fmt(diag["certificate_storage_gain_acft"]),
                "certificate_selected_shortage_after_cfs": fmt(diag["certificate_selected_shortage_after_cfs"]),
                "certificate_selected_next_storage_acft": fmt(diag["certificate_selected_next_storage_acft"]),
                "certificate_hard_reserve_floor_acft": fmt(diag["certificate_hard_reserve_floor_acft"]),
                "certificate_nominal_viability_floor_acft": fmt(diag["certificate_nominal_viability_floor_acft"]),
                "certificate_viability_floor_acft": fmt(diag["certificate_viability_floor_acft"]),
                "certificate_viability_recovery_gap_acft": fmt(diag["certificate_viability_recovery_gap_acft"]),
                "certificate_maximum_reachable_storage_acft": fmt(diag["certificate_maximum_reachable_storage_acft"]),
                "certificate_raw_anchor_viable": fmt(diag["certificate_raw_anchor_viable"]),
                "certificate_service_regret_cfs": fmt(diag["certificate_service_regret_cfs"]),
                "certificate_reserve_violation_acft": fmt(diag["certificate_reserve_violation_acft"]),
                "certificate_reserve_borrowing_acft": fmt(diag["certificate_reserve_borrowing_acft"]),
                "certificate_reserve_repayment_acft": fmt(diag["certificate_reserve_repayment_acft"]),
                "certificate_service_ledger_before": fmt(diag["certificate_service_ledger_before"]),
                "certificate_service_ledger_after": fmt(diag["certificate_service_ledger_after"]),
                "certificate_reserve_ledger_before": fmt(diag["certificate_reserve_ledger_before"]),
                "certificate_reserve_ledger_after": fmt(diag["certificate_reserve_ledger_after"]),
                "certificate_service_dual_weight": fmt(diag["certificate_service_dual_weight"]),
                "certificate_reserve_dual_weight": fmt(diag["certificate_reserve_dual_weight"]),
                "certificate_override_margin": fmt(diag["certificate_override_margin"]),
                "certificate_service_override_days": fmt(diag["certificate_service_override_days"]),
                "certificate_supply_reserve_guard_enabled": fmt(
                    diag.get("certificate_supply_reserve_guard_enabled", 0.0)
                ),
                "certificate_supply_reserve_guard_applied": fmt(
                    diag.get("certificate_supply_reserve_guard_applied", 0.0)
                ),
                "certificate_supply_reserve_guard_reduction_cfs": fmt(
                    diag.get("certificate_supply_reserve_guard_reduction_cfs", 0.0)
                ),
                "certificate_supply_reserve_guard_target_release_cfs": fmt(
                    diag.get("certificate_supply_reserve_guard_target_release_cfs", 0.0)
                ),
                "certificate_supply_reserve_guard_mode": str(
                    diag.get("certificate_supply_reserve_guard_mode", "")
                ),
                "certificate_supply_reserve_guard_min_demand_cfs": fmt(
                    diag.get("certificate_supply_reserve_guard_min_demand_cfs", 0.0)
                ),
                "certificate_supply_reserve_guard_local_storage_fraction": fmt(
                    diag.get("certificate_supply_reserve_guard_local_storage_fraction", 0.0)
                ),
                "certificate_path_viability_mode": str(
                    diag.get("certificate_path_viability_mode", "disabled")
                ),
                "certificate_path_viability_enabled": fmt(
                    diag.get("certificate_path_viability_enabled", 0.0)
                ),
                "certificate_path_viability_applied": fmt(
                    diag.get("certificate_path_viability_applied", 0.0)
                ),
                "certificate_path_viability_reduction_cfs": fmt(
                    diag.get("certificate_path_viability_reduction_cfs", 0.0)
                ),
                "certificate_path_viability_min_margin_acft": fmt(
                    diag.get("certificate_path_viability_min_margin_acft", 0.0)
                ),
                "certificate_path_viability_details_json": json.dumps(
                    diag.get("certificate_path_viability_details_json", []),
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                ),
                "certificate_supply_guarantee_enabled": fmt(
                    diag.get("certificate_supply_guarantee_enabled", 0.0)
                ),
                "certificate_supply_guarantee_fraction": fmt(
                    diag.get("certificate_supply_guarantee_fraction", 0.0)
                ),
                "certificate_supply_guarantee_nodes": str(
                    diag.get("certificate_supply_guarantee_nodes", "")
                ),
                "certificate_supply_guarantee_applied": fmt(
                    diag.get("certificate_supply_guarantee_applied", 0.0)
                ),
                "certificate_supply_guarantee_extra_release_cfs": fmt(
                    diag.get("certificate_supply_guarantee_extra_release_cfs", 0.0)
                ),
                "certificate_supply_guarantee_shortfall_before_cfs": fmt(
                    diag.get("certificate_supply_guarantee_shortfall_before_cfs", 0.0)
                ),
                "certificate_supply_guarantee_shortfall_after_cfs": fmt(
                    diag.get("certificate_supply_guarantee_shortfall_after_cfs", 0.0)
                ),
                "certificate_supply_guarantee_worst_satisfaction_before": fmt(
                    diag.get("certificate_supply_guarantee_worst_satisfaction_before", 1.0)
                ),
                "certificate_supply_guarantee_worst_satisfaction_after": fmt(
                    diag.get("certificate_supply_guarantee_worst_satisfaction_after", 1.0)
                ),
                "certificate_supply_guarantee_nodes_below_before": fmt(
                    diag.get("certificate_supply_guarantee_nodes_below_before", 0.0)
                ),
                "certificate_supply_guarantee_nodes_below_after": fmt(
                    diag.get("certificate_supply_guarantee_nodes_below_after", 0.0)
                ),
                "certificate_supply_guarantee_node_details_json": json.dumps(
                    diag.get("certificate_supply_guarantee_node_details_json", []),
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                "total_storage_before_acft": fmt(sum(result.storage_acft.values())),
                "total_storage_after_acft": fmt(sum(result.next_storage_acft.values())),
                "total_inflow_proxy_cfs": fmt(result.metrics["total_inflow_proxy_cfs"]),
                "total_requested_release_cfs": fmt(result.metrics["total_requested_release_cfs"]),
                "total_applied_release_cfs": fmt(result.metrics["total_applied_release_cfs"]),
                "total_diversion_demand_cfs": fmt(result.metrics.get("total_diversion_demand_cfs", 0.0)),
                "total_instream_demand_cfs": fmt(result.metrics.get("total_instream_demand_cfs", 0.0)),
                "total_shortage_before_release_cfs": fmt(result.metrics["total_shortage_before_release_cfs"]),
                "total_shortage_after_release_cfs": fmt(result.metrics["total_shortage_after_release_cfs"]),
                "diversion_shortage_before_release_cfs": fmt(
                    result.metrics.get("diversion_shortage_before_release_cfs", 0.0)
                ),
                "diversion_shortage_after_release_cfs": fmt(result.metrics["diversion_shortage_after_release_cfs"]),
                "instream_shortage_before_release_cfs": fmt(
                    result.metrics.get("instream_shortage_before_release_cfs", 0.0)
                ),
                "instream_shortage_after_release_cfs": fmt(result.metrics["instream_shortage_after_release_cfs"]),
            }
        )
        for rank, candidate in enumerate(diag["mpc_top_candidates"], start=1):
            candidate_rows.append(
                {
                    "date": result.date,
                    "rank": str(rank),
                    "candidate_id": str(candidate["candidate_id"]),
                    "robust_cost": fmt(candidate["robust_cost"]),
                    "mean_cost": fmt(candidate["mean_cost"]),
                    "cvar_cost": fmt(candidate["cvar_cost"]),
                }
            )
        for reservoir_id in env.reservoir_ids:
            release_rows.append(
                {
                    "date": result.date,
                    "reservoir_id": reservoir_id,
                    "primary_intent": decision.intent.primary_intent,
                    "applied_release_cfs": fmt(result.applied_releases_cfs.get(reservoir_id, 0.0)),
                }
            )
            storage_rows.append(
                {
                    "date": result.date,
                    "reservoir_id": reservoir_id,
                    "storage_before_acft": fmt(result.storage_acft.get(reservoir_id, 0.0)),
                    "storage_after_acft": fmt(result.next_storage_acft.get(reservoir_id, 0.0)),
                }
            )

    write_csv(args.out / "final_robust_mpc_trace.csv", trace_rows)
    write_csv(args.out / "final_robust_mpc_release_schedule.csv", release_rows)
    write_csv(args.out / "final_robust_mpc_storage_trajectory.csv", storage_rows)
    write_csv(args.out / "final_robust_mpc_candidate_audit.csv", candidate_rows)
    write_csv(args.out / "final_skill_claim_audit.csv", skill_claim_rows)
    write_csv(args.out / "final_skill_conflict_audit.csv", skill_conflict_rows)
    if structured_chat_client is not None:
        write_jsonl(args.out / "final_llm_call_audit.jsonl", structured_chat_client.events)
    if contract_library_backend is not None:
        write_jsonl(
            args.out / "final_contract_library_audit.jsonl",
            contract_library_backend.events,
        )
    summary = summarize(
        args,
        trace_rows,
        intent_counts,
        certificate_counts,
        negotiation_counts,
        deliberation_counts,
        deliberation_backend_counts,
        structured_chat_client,
        contract_library_backend,
        termination_reason,
        step_count,
        protocol_payload,
        protocol_hash,
        hydrologic_admissibility_policy,
        initial_storage_override,
        initial_storage_override_hash,
    )
    (args.out / "final_robust_mpc_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


def summarize(
    args: argparse.Namespace,
    trace_rows: list[dict[str, str]],
    intent_counts: Counter[str],
    certificate_counts: Counter[str],
    negotiation_counts: Counter[str],
    deliberation_counts: Counter[str],
    deliberation_backend_counts: Counter[str],
    structured_chat_client: StructuredChatDeliberationClient | None,
    contract_library_backend: FrozenSemanticContractLibraryBackend | None,
    termination_reason: str,
    requested_steps: int,
    protocol_payload: dict[str, object] | None,
    protocol_hash: str,
    hydrologic_admissibility_policy: dict[str, object] | None,
    initial_storage_override: dict[str, float],
    initial_storage_override_hash: str,
) -> dict[str, object]:
    steps = len(trace_rows)
    shortage_before = sum(float(row["total_shortage_before_release_cfs"]) for row in trace_rows)
    shortage_after = sum(float(row["total_shortage_after_release_cfs"]) for row in trace_rows)
    applied_release = sum(float(row["total_applied_release_cfs"]) for row in trace_rows)
    storage_after = [float(row["total_storage_after_acft"]) for row in trace_rows]
    llm_events = structured_chat_client.events if structured_chat_client is not None else []
    llm_success_events = [event for event in llm_events if event.get("status") in {"success", "cache_hit"}]
    llm_network_events = [event for event in llm_events if event.get("status") == "success"]
    llm_usage_events = [event for event in llm_network_events if isinstance(event.get("usage"), dict)]
    llm_fallback_days = sum(
        count
        for backend, count in deliberation_backend_counts.items()
        if "fallback" in backend
    )
    trigger_days = sum(float(row["deliberation_event_triggered"]) > 0.5 for row in trace_rows)
    reuse_days = sum(float(row["deliberation_contract_reused"]) > 0.5 for row in trace_rows)
    trigger_reason_counts: Counter[str] = Counter()
    redeliberation_reason_counts: Counter[str] = Counter()
    for row in trace_rows:
        for reason in row["deliberation_trigger_reasons"].split(","):
            if reason and reason != "contract_reuse":
                trigger_reason_counts[reason] += 1
        for reason in row.get("llm_redeliberation_reasons", "").split(","):
            if reason:
                redeliberation_reason_counts[reason] += 1
    return {
        "dataset": str(args.dataset),
        "agent": "ForecastCausalRobustMpcAgent",
        "forecast_model": "SeasonalAnalogEnsembleForecaster",
        "deliberation_layer": (
            "disabled"
            if args.disable_deliberation
            else (
                "EventTriggeredMultiSkillDeliberationLayer"
                if args.event_triggered_deliberation
                else "MultiSkillDeliberationLayer"
            )
        ),
        "deliberation_backend_requested": args.deliberation_backend,
        "disable_deliberation": args.disable_deliberation,
        "disable_negotiation": args.disable_negotiation,
        "disable_conflict_graph": args.disable_conflict_graph,
        "deliberation_backend_counts": dict(deliberation_backend_counts),
        "semantic_trigger_days": trigger_days,
        "semantic_reuse_days": reuse_days,
        "semantic_trigger_rate": trigger_days / steps if steps else 0.0,
        "semantic_reuse_rate": reuse_days / steps if steps else 0.0,
        "semantic_trigger_reason_counts": dict(trigger_reason_counts),
        "semantic_mean_contract_age_days": (
            sum(float(row["deliberation_contract_age_days"]) for row in trace_rows) / steps
            if steps
            else 0.0
        ),
        "semantic_mean_state_novelty": (
            sum(float(row["deliberation_state_novelty"]) for row in trace_rows) / steps
            if steps
            else 0.0
        ),
        "semantic_mean_support_validity": (
            sum(float(row["deliberation_support_validity"]) for row in trace_rows) / steps
            if steps
            else 0.0
        ),
        "semantic_novelty_threshold": args.semantic_novelty_threshold,
        "semantic_trigger_threshold": args.semantic_trigger_threshold,
        "semantic_contract_max_age_days": args.semantic_contract_max_age_days,
        "semantic_minimum_support_validity": args.semantic_minimum_support_validity,
        "semantic_conflict_escalation_threshold": args.semantic_conflict_escalation_threshold,
        "semantic_modifier_decay_rate": args.semantic_modifier_decay_rate,
        "semantic_safety_veto_streak": args.semantic_safety_veto_streak,
        "semantic_safety_requery_cooldown_days": args.semantic_safety_requery_cooldown_days,
        "semantic_safety_dual_drift_threshold": args.semantic_safety_dual_drift_threshold,
        "llm_model": args.structured_chat_model if structured_chat_client is not None else "",
        "llm_base_url": args.structured_chat_base_url if structured_chat_client is not None else "",
        "llm_call_status_counts": (
            dict(Counter(str(event.get("status", "")) for event in llm_events))
            if structured_chat_client is not None
            else {}
        ),
        "llm_prompt_tokens": sum(int(event["usage"].get("prompt_tokens", 0)) for event in llm_usage_events),
        "llm_completion_tokens": sum(int(event["usage"].get("completion_tokens", 0)) for event in llm_usage_events),
        "llm_total_tokens": sum(int(event["usage"].get("total_tokens", 0)) for event in llm_usage_events),
        "llm_mean_latency_seconds": (
            sum(float(event.get("latency_seconds", 0.0)) for event in llm_network_events) / len(llm_network_events)
            if llm_network_events
            else 0.0
        ),
        "llm_network_call_count": len(llm_network_events),
        "llm_network_attempted_call_count": (
            structured_chat_client.network_call_count
            if structured_chat_client is not None
            else 0
        ),
        "llm_network_budget_limit": (
            args.structured_chat_max_network_calls
            if structured_chat_client is not None and args.structured_chat_max_network_calls > 0
            else 0
        ),
        "llm_replay_only": bool(args.structured_chat_replay_only) if structured_chat_client is not None else False,
        "llm_cache_hit_count": sum(event.get("status") == "cache_hit" for event in llm_events),
        "llm_fallback_days": llm_fallback_days,
        "llm_fallback_rate": llm_fallback_days / steps if steps else 0.0,
        "max_deliberation_rounds": args.max_deliberation_rounds,
        "certificate_requery_service_regret_cfs": args.certificate_requery_service_regret_cfs,
        "certificate_requery_reserve_violation_acft": args.certificate_requery_reserve_violation_acft,
        "certificate_requery_actions": args.certificate_requery_actions,
        "redeliberation_acceptance_mode": args.redeliberation_acceptance_mode,
        "redeliberation_score_tolerance": args.redeliberation_score_tolerance,
        "shadow_baseline_mode": args.shadow_baseline_mode,
        "shadow_score_tolerance": args.shadow_score_tolerance,
        "hydrologic_admissibility_policy": str(args.hydrologic_admissibility_policy or ""),
        "hydrologic_admissibility_policy_id": (
            str((hydrologic_admissibility_policy or {}).get("policy_id", ""))
            if isinstance(hydrologic_admissibility_policy, dict)
            else ""
        ),
        "hydrologic_admissibility_rule_count": (
            len((hydrologic_admissibility_policy or {}).get("regime_rules", []))
            if isinstance(hydrologic_admissibility_policy, dict)
            else 0
        ),
        "hydrologic_supervisor_decay": args.hydrologic_supervisor_decay,
        "hydrologic_supervisor_score_limit": args.hydrologic_supervisor_score_limit,
        "hydrologic_supervisor_service_limit_cfs": args.hydrologic_supervisor_service_limit_cfs,
        "hydrologic_supervisor_reserve_limit_acft": args.hydrologic_supervisor_reserve_limit_acft,
        "shadow_supervisor_selected_days": sum(
            float(row.get("shadow_supervisor_selected_shadow", 0.0)) > 0.5
            for row in trace_rows
        ),
        "hydrologic_supervisor_unique_regimes": len(
            {
                row.get("hydrologic_supervisor_regime_key", "")
                for row in trace_rows
                if row.get("hydrologic_supervisor_regime_key", "")
            }
        ),
        "hydrologic_supervisor_shadow_fallback_days": sum(
            row.get("hydrologic_supervisor_admission_rule", "") == "regime_regret_shadow_fallback"
            for row in trace_rows
        ),
        "hydrologic_supervisor_service_gain_admission_days": sum(
            row.get("hydrologic_supervisor_admission_rule", "")
            == "hydrologic_service_gain_with_regime_budget"
            for row in trace_rows
        ),
        "hydrologic_supervisor_low_storage_recovery_days": sum(
            row.get("hydrologic_supervisor_admission_rule", "")
            == "low_storage_recovery_preference"
            for row in trace_rows
        ),
        "hydrologic_supervisor_seasonal_storage_recovery_days": sum(
            row.get("hydrologic_supervisor_admission_rule", "")
            == "seasonal_storage_recovery_budget"
            for row in trace_rows
        ),
        "trained_admissibility_benefit_days": sum(
            row.get("hydrologic_supervisor_regime_label", "") == "benefit"
            for row in trace_rows
        ),
        "trained_admissibility_fragile_days": sum(
            row.get("hydrologic_supervisor_regime_label", "") == "fragile"
            for row in trace_rows
        ),
        "trained_admissibility_conflict_days": sum(
            row.get("hydrologic_supervisor_regime_label", "") == "conflict"
            for row in trace_rows
        ),
        "trained_admissibility_unclassified_days": sum(
            row.get("hydrologic_supervisor_regime_label", "") == "unclassified"
            for row in trace_rows
        ),
        "trained_admissibility_semantic_admission_days": sum(
            row.get("shadow_supervisor_selected_source", "") == "semantic_contract"
            and str(row.get("hydrologic_supervisor_admission_rule", "")).startswith("trained_")
            for row in trace_rows
        ),
        "trained_admissibility_shadow_fallback_days": sum(
            row.get("shadow_supervisor_selected_source", "") == "shadow_baseline"
            and str(row.get("hydrologic_supervisor_admission_rule", "")).startswith("trained_")
            for row in trace_rows
        ),
        "llm_redeliberation_days": sum(
            float(row.get("llm_redeliberation_triggered", 0.0)) > 0.5
            for row in trace_rows
        ),
        "llm_round_score_reverted_days": sum(
            float(row.get("llm_round_score_reverted", 0.0)) > 0.5
            for row in trace_rows
        ),
        "llm_redeliberation_rate": (
            sum(float(row.get("llm_redeliberation_triggered", 0.0)) > 0.5 for row in trace_rows) / steps
            if steps
            else 0.0
        ),
        "llm_mean_deliberation_round_count": (
            sum(float(row.get("llm_deliberation_round_count", 1.0)) for row in trace_rows) / steps
            if steps
            else 0.0
        ),
        "llm_redeliberation_reason_counts": dict(redeliberation_reason_counts),
        "contract_library_path": (
            str(contract_library_backend.library_path)
            if contract_library_backend is not None
            else ""
        ),
        "contract_library_sha256": (
            contract_library_backend.library_sha256
            if contract_library_backend is not None
            else ""
        ),
        "contract_library_entry_count": (
            len(contract_library_backend.entries)
            if contract_library_backend is not None
            else 0
        ),
        "contract_library_status_counts": (
            dict(Counter(str(event.get("status", "")) for event in contract_library_backend.events))
            if contract_library_backend is not None
            else {}
        ),
        "contract_library_mean_score": (
            sum(float(event.get("score", 0.0)) for event in contract_library_backend.events)
            / len(contract_library_backend.events)
            if contract_library_backend is not None and contract_library_backend.events
            else 0.0
        ),
        "contract_library_network_calls": 0,
        "contract_library_total_tokens": 0,
        "negotiator": "BilevelIntentNegotiator",
        "planner": "RobustIntentMpcPlanner",
        "start_date": args.start_date,
        "exclude_reservoirs": args.exclude_reservoirs,
        "clamp_negative_streamflow": args.clamp_negative_streamflow,
        "horizon_days": args.horizon_days,
        "ensemble_size": args.ensemble_size,
        "analog_window_days": args.analog_window_days,
        "viability_floor_fraction": args.viability_floor_fraction,
        "service_ledger_scale_cfs_days": args.service_ledger_scale_cfs_days,
        "reserve_ledger_scale_acft": args.reserve_ledger_scale_acft,
        "mpc_risk_weight": args.mpc_risk_weight,
        "mpc_worst_weight": args.mpc_worst_weight,
        "strategic_reserve_weight": args.strategic_reserve_weight,
        "ledger_decay": args.ledger_decay,
        "reserve_repayment_fraction": args.reserve_repayment_fraction,
        "ledger_recovery_fraction": args.ledger_recovery_fraction,
        "certificate_mode": args.certificate_mode,
        "supply_guarantee_fraction": args.supply_guarantee_fraction,
        "supply_guarantee_nodes": args.supply_guarantee_nodes,
        "supply_reserve_guard_enabled": not args.disable_supply_reserve_guard,
        "supply_reserve_guard_mode": args.supply_reserve_guard_mode,
        "supply_reserve_guard_min_demand_cfs": args.supply_reserve_guard_min_demand_cfs,
        "supply_reserve_guard_local_storage_fraction": args.supply_reserve_guard_local_storage_fraction,
        "supply_path_viability_mode": args.supply_path_viability_mode,
        "supply_path_viability_base_fraction": args.supply_path_viability_base_fraction,
        "supply_path_viability_max_fraction": args.supply_path_viability_max_fraction,
        "supply_path_viability_memory_days": args.supply_path_viability_memory_days,
        "supply_path_viability_demand_lookahead_days": (
            args.supply_path_viability_demand_lookahead_days
        ),
        "supply_path_viability_demand_reserve_fraction": (
            args.supply_path_viability_demand_reserve_fraction
        ),
        "supply_path_viability_forecast_multiplier": (
            args.supply_path_viability_forecast_multiplier
        ),
        "supply_path_viability_applied_days": sum(
            float(row.get("certificate_path_viability_applied", 0.0)) > 0.5
            for row in trace_rows
        ),
        "supply_path_viability_mean_reduction_cfs": (
            sum(
                float(row.get("certificate_path_viability_reduction_cfs", 0.0))
                for row in trace_rows
            )
            / steps
            if steps
            else 0.0
        ),
        "supply_path_viability_minimum_margin_acft": (
            min(
                float(row.get("certificate_path_viability_min_margin_acft", 0.0))
                for row in trace_rows
            )
            if trace_rows and args.supply_path_viability_mode != "disabled"
            else 0.0
        ),
        "initial_storage_override_path": (
            str(args.initial_storage_json) if args.initial_storage_json is not None else ""
        ),
        "initial_storage_override_sha256": initial_storage_override_hash,
        "initial_storage_override_count": len(initial_storage_override),
        "initial_storage_override_total_acft": (
            sum(initial_storage_override.values()) if initial_storage_override else 0.0
        ),
        "supply_reserve_guard_applied_days": sum(
            float(row.get("certificate_supply_reserve_guard_applied", 0.0)) > 0.5
            for row in trace_rows
        ),
        "supply_reserve_guard_mean_reduction_cfs": (
            sum(float(row.get("certificate_supply_reserve_guard_reduction_cfs", 0.0)) for row in trace_rows) / steps
            if steps
            else 0.0
        ),
        "supply_guarantee_applied_days": sum(
            float(row.get("certificate_supply_guarantee_applied", 0.0)) > 0.5
            for row in trace_rows
        ),
        "supply_guarantee_mean_extra_release_cfs": (
            sum(float(row.get("certificate_supply_guarantee_extra_release_cfs", 0.0)) for row in trace_rows) / steps
            if steps
            else 0.0
        ),
        "supply_guarantee_mean_shortfall_before_cfs": (
            sum(float(row.get("certificate_supply_guarantee_shortfall_before_cfs", 0.0)) for row in trace_rows) / steps
            if steps
            else 0.0
        ),
        "supply_guarantee_mean_shortfall_after_cfs": (
            sum(float(row.get("certificate_supply_guarantee_shortfall_after_cfs", 0.0)) for row in trace_rows) / steps
            if steps
            else 0.0
        ),
        "steps": steps,
        "requested_steps": requested_steps,
        "termination_reason": termination_reason,
        "confirmatory_protocol_id": (
            str(protocol_payload.get("protocol_id", ""))
            if protocol_payload is not None
            else ""
        ),
        "confirmatory_protocol_sha256": protocol_hash,
        "end_date": trace_rows[-1]["date"] if trace_rows else args.start_date,
        "intent_counts": dict(intent_counts),
        "deliberation_dominant_intent_counts": dict(deliberation_counts),
        "certificate_action_counts": dict(certificate_counts),
        "negotiation_status_counts": dict(negotiation_counts),
        "mean_shortage_before_release_cfs": shortage_before / steps if steps else 0.0,
        "mean_shortage_after_release_cfs": shortage_after / steps if steps else 0.0,
        "mean_shortage_reduction_cfs": (shortage_before - shortage_after) / steps if steps else 0.0,
        "relative_shortage_reduction": (shortage_before - shortage_after) / shortage_before if shortage_before else 0.0,
        "mean_applied_release_cfs": applied_release / steps if steps else 0.0,
        "minimum_total_storage_acft": min(storage_after) if storage_after else 0.0,
        "mean_total_storage_acft": sum(storage_after) / steps if steps else 0.0,
        "final_total_storage_acft": storage_after[-1] if storage_after else 0.0,
        "outputs": [
            "final_robust_mpc_trace.csv",
            "final_robust_mpc_release_schedule.csv",
            "final_robust_mpc_storage_trajectory.csv",
            "final_robust_mpc_candidate_audit.csv",
            "final_skill_claim_audit.csv",
            "final_skill_conflict_audit.csv",
            *(
                ["final_llm_call_audit.jsonl"]
                if structured_chat_client is not None
                else []
            ),
            *(
                ["final_contract_library_audit.jsonl"]
                if contract_library_backend is not None
                else []
            ),
            "final_robust_mpc_summary.json",
        ],
    }


def selected_reservoir_ids(
    dataset: Path,
    excluded_reservoirs: tuple[str, ...],
) -> list[str]:
    excluded = set(excluded_reservoirs)
    rows: list[str] = []
    with (dataset / "reservoirs.csv").open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            reservoir_id = row["reservoir_id"]
            if reservoir_id in excluded:
                continue
            if row.get("active", "") != "True":
                continue
            try:
                capacity = float(row.get("content_max_acft", 0.0) or 0.0)
            except ValueError:
                capacity = 0.0
            if capacity <= 0.0:
                continue
            rows.append(reservoir_id)
    missing = sorted(excluded - set(read_all_reservoir_ids(dataset)))
    if missing:
        raise ValueError(f"Excluded reservoir ids not found in reservoirs.csv: {missing}")
    if not rows:
        raise ValueError("No active reservoirs remain after --exclude-reservoirs filtering.")
    return rows


def read_all_reservoir_ids(dataset: Path) -> set[str]:
    with (dataset / "reservoirs.csv").open("r", encoding="utf-8-sig", newline="") as handle:
        return {row["reservoir_id"] for row in csv.DictReader(handle)}


def validate_confirmatory_protocol(
    args: argparse.Namespace,
    path: Path,
) -> tuple[dict[str, object], str]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Confirmatory protocol must be a JSON object.")
    expected = payload["runtime"]
    if not isinstance(expected, dict):
        raise ValueError("Confirmatory protocol runtime section is invalid.")
    actual = {
        "prompt_version": PROMPT_VERSION,
        "start_date": args.start_date,
        "max_steps": args.max_steps,
        "exclude_reservoirs": args.exclude_reservoirs,
        "clamp_negative_streamflow": args.clamp_negative_streamflow,
        "allow_paid_full_run": args.allow_paid_full_run,
        "disable_deliberation": args.disable_deliberation,
        "disable_negotiation": args.disable_negotiation,
        "disable_conflict_graph": args.disable_conflict_graph,
        "deliberation_backend": args.deliberation_backend,
        "event_triggered_deliberation": args.event_triggered_deliberation,
        "structured_chat_model": args.structured_chat_model,
        "structured_chat_thinking": args.structured_chat_thinking,
        "structured_chat_reasoning_effort": args.structured_chat_reasoning_effort,
        "structured_chat_max_tokens": args.structured_chat_max_tokens,
        "structured_chat_max_network_calls": args.structured_chat_max_network_calls,
        "structured_chat_replay_only": args.structured_chat_replay_only,
        "max_deliberation_rounds": args.max_deliberation_rounds,
        "certificate_requery_service_regret_cfs": args.certificate_requery_service_regret_cfs,
        "certificate_requery_reserve_violation_acft": args.certificate_requery_reserve_violation_acft,
        "certificate_requery_actions": args.certificate_requery_actions,
        "redeliberation_acceptance_mode": args.redeliberation_acceptance_mode,
        "redeliberation_score_tolerance": args.redeliberation_score_tolerance,
        "shadow_baseline_mode": args.shadow_baseline_mode,
        "shadow_score_tolerance": args.shadow_score_tolerance,
        "hydrologic_supervisor_decay": args.hydrologic_supervisor_decay,
        "hydrologic_supervisor_score_limit": args.hydrologic_supervisor_score_limit,
        "hydrologic_supervisor_service_limit_cfs": args.hydrologic_supervisor_service_limit_cfs,
        "hydrologic_supervisor_reserve_limit_acft": args.hydrologic_supervisor_reserve_limit_acft,
        "semantic_novelty_threshold": args.semantic_novelty_threshold,
        "semantic_trigger_threshold": args.semantic_trigger_threshold,
        "semantic_contract_max_age_days": args.semantic_contract_max_age_days,
        "semantic_minimum_support_validity": args.semantic_minimum_support_validity,
        "semantic_conflict_escalation_threshold": (
            args.semantic_conflict_escalation_threshold
        ),
        "semantic_modifier_decay_rate": args.semantic_modifier_decay_rate,
        "semantic_safety_veto_streak": args.semantic_safety_veto_streak,
        "semantic_safety_requery_cooldown_days": (
            args.semantic_safety_requery_cooldown_days
        ),
        "semantic_safety_dual_drift_threshold": (
            args.semantic_safety_dual_drift_threshold
        ),
        "horizon_days": args.horizon_days,
        "ensemble_size": args.ensemble_size,
        "analog_window_days": args.analog_window_days,
        "viability_floor_fraction": args.viability_floor_fraction,
        "service_ledger_scale_cfs_days": args.service_ledger_scale_cfs_days,
        "reserve_ledger_scale_acft": args.reserve_ledger_scale_acft,
        "mpc_risk_weight": args.mpc_risk_weight,
        "mpc_worst_weight": args.mpc_worst_weight,
        "strategic_reserve_weight": args.strategic_reserve_weight,
        "ledger_decay": args.ledger_decay,
        "reserve_repayment_fraction": args.reserve_repayment_fraction,
        "ledger_recovery_fraction": args.ledger_recovery_fraction,
        "certificate_mode": args.certificate_mode,
        "supply_guarantee_fraction": args.supply_guarantee_fraction,
        "supply_guarantee_nodes": args.supply_guarantee_nodes,
        "disable_supply_reserve_guard": args.disable_supply_reserve_guard,
        "supply_reserve_guard_mode": args.supply_reserve_guard_mode,
        "supply_reserve_guard_min_demand_cfs": args.supply_reserve_guard_min_demand_cfs,
        "supply_reserve_guard_local_storage_fraction": args.supply_reserve_guard_local_storage_fraction,
    }
    mismatches = {
        key: {"expected": expected.get(key), "actual": value}
        for key, value in actual.items()
        if expected.get(key) != value
    }
    if mismatches:
        raise ValueError(
            "Runtime arguments differ from the frozen confirmatory protocol: "
            + json.dumps(mismatches, ensure_ascii=False, sort_keys=True)
        )
    execution = payload.get("execution", {})
    if not isinstance(execution, dict):
        raise ValueError("Confirmatory protocol execution section is invalid.")
    expected_cache = ROOT / str(execution["cache_dir"])
    if args.structured_chat_cache_dir is None:
        args.structured_chat_cache_dir = expected_cache
    elif args.structured_chat_cache_dir.resolve() != expected_cache.resolve():
        raise ValueError(
            f"Confirmatory cache directory must be {expected_cache}, "
            f"not {args.structured_chat_cache_dir}."
        )
    expected_out = ROOT / str(execution["output_dir"])
    if args.out == DEFAULT_OUT:
        args.out = expected_out
    elif args.out.resolve() != expected_out.resolve():
        raise ValueError(
            f"Confirmatory output directory must be {expected_out}, not {args.out}."
        )
    source_hashes = payload.get("source_sha256", {})
    if not isinstance(source_hashes, dict):
        raise ValueError("Confirmatory protocol source_sha256 section is invalid.")
    hash_mismatches: dict[str, dict[str, str]] = {}
    for relative_path, expected_hash in source_hashes.items():
        source_path = ROOT / str(relative_path)
        actual_hash = hashlib.sha256(source_path.read_bytes()).hexdigest()
        if actual_hash != expected_hash:
            hash_mismatches[str(relative_path)] = {
                "expected": str(expected_hash),
                "actual": actual_hash,
            }
    if hash_mismatches:
        raise ValueError(
            "Source files differ from the frozen confirmatory protocol: "
            + json.dumps(hash_mismatches, ensure_ascii=False, sort_keys=True)
        )
    encoded = json.dumps(
        payload,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return payload, hashlib.sha256(encoded).hexdigest()


def compact_intent_for_step(intent: dict[str, object]) -> dict[str, float | str]:
    compact: dict[str, float | str] = {}
    for key, value in intent.items():
        if isinstance(value, (int, float, str)):
            compact[key] = value
    return compact


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_jsonl(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True))
            handle.write("\n")


def fmt(value: object) -> str:
    return f"{float(value):.6g}"


if __name__ == "__main__":
    main()
