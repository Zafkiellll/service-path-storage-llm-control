# Real-time Multi-reservoir Agent: Core Public Release

This package contains the executable control core, minimum scientific data dependencies, and the sanitized GPT-5 interface-audit evidence used in the manuscript. Plotting code, manuscript files, development logs, local session paths, credentials, and API caches are excluded.

## Included methods

- Daily networked reservoir environment with mass balance and routing constraints.
- Causal seasonal-analog forecast ensemble.
- Evidence-bound skills, explicit conflict graph, and schema 3.0 semantic contracts.
- Event-triggered deliberation, two-level negotiation, robust model predictive control, and physical action certification.
- Hydrologic-admissibility screening and service-path storage protection.
- Rule, forecast-causal, ablation, and invalid-contract safety tests.

## Quick start

```bash
python scripts/smoke_test_cdss_daily_environment.py
python scripts/run_public_main.py --max-steps 30
python scripts/verify_gpt5_interface_audit.py
```

The default long-period command uses the archived semantic-contract library and does not contact an external model provider. The provider-neutral `StructuredLlmDeliberationBackend` accepts any callable that returns the declared schema. An optional structured-chat adapter is included for deployment experiments and requires independently supplied `LLM_API_KEY`, `LLM_BASE_URL`, and `LLM_MODEL` values.

The 9,496-day experiment is a causal closed-loop evaluation of the event-triggered contract-to-control protocol. The separate prespecified 24-case audit records direct GPT-5 interface execution; its sanitized requests, responses, hashes, and paired control effects are under `experiments/gpt5_interface_audit/`.

## Data

The bundled CDSS-derived dataset contains 9,497 daily records from 1987-10-01 through 2013-09-30, 885 nodes, 884 directed edges, and 36 reservoir records. It supports a causal model replay, not reconstruction of historical operator decisions. See `data_candidates/processed/cdss_agent_dataset/DATASET_CARD.md`.

## Reuse

Authors should add their chosen software license and confirm the upstream Colorado Decision Support Systems data terms before publishing a new archive version.
