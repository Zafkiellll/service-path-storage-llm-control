# Real-time Multi-reservoir Agent: Core Public Release

This package contains only the executable control core and its minimum scientific data dependencies. It excludes plotting code, manuscript files, figures, experiment outputs, API caches, development logs, and internal review material.

## Included methods

- Daily networked reservoir environment with mass-balance and routing constraints.
- Causal seasonal-analog forecast ensemble.
- Evidence-bound hydrologic modules and explicit conflict graph.
- Event-triggered LLM-authored semantic contracts with bounded modifiers.
- Two-level intent negotiation and ensemble robust model predictive control (MPC).
- Deterministic physical-feasibility checks, safety ledgers, hydrologic-regime screening, and service-path storage protection.
- Transparent rule and forecast-causal baselines.
- Semantic-contract fault-injection audit.

## Requirements

- Python 3.11 or 3.12.
- The core runtime uses only the Python standard library.

## Quick start

From the package root:

```bash
python scripts/smoke_test_cdss_daily_environment.py
python scripts/run_public_main.py --max-steps 30
```

The second command writes results to `outputs/main_method_30d/`. Use `--max-steps 0` for all 9,496 closed-loop transitions. A full run is computationally expensive.

## Main causal-replay configuration

`scripts/run_public_main.py` runs the paper's core configuration with:

- the nonphysical `3903508_Ex` account excluded;
- event-triggered, multi-round LLM-authored semantic contracts;
- trained hydrologic-admissibility screening;
- robust MPC and full physical-feasibility checks;
- a 0.75 service-path storage activation fraction.

The bundled semantic contracts support deterministic causal replay. They are not evidence of full-period provider-network deployment. The online adapter remains available in `realtime_reservoir_agent/deepseek_client.py`; live use requires an independently supplied `DEEPSEEK_API_KEY` and should be treated as a separate experiment.

## Data

The bundled dataset is derived from the CDSS Upper Colorado/Shoshone StateMod daily model. It contains 9,497 dates from 1987-10-01 through 2013-09-30, 885 nodes, 884 directed edges, and 36 reservoir records. See `data_candidates/processed/cdss_agent_dataset/DATASET_CARD.md`.

The dataset does not contain native daily observed operator release or storage labels. Daily target-storage series are expanded from monthly StateMod targets; inflow forcing and operational experiments must be interpreted as a causal model replay, not as reconstruction of historical operator decisions.

## Layout

```text
realtime_reservoir_agent/          control implementation
scripts/                           core construction, run, and safety-audit entry points
experiments/                       semantic-contract data used by replay and ablation
data_candidates/processed/...      daily forcing, topology, reservoir metadata, and policy
```

## Data source

Colorado Decision Support Systems, Upper Colorado River Basin StateMod model files and documentation: https://cdss.colorado.gov/modeling-data/surface-water-statemod

## License notice

No software or data license was selected as part of this packaging task. Add the authors' chosen license and verify the upstream CDSS data terms before publishing the repository.
