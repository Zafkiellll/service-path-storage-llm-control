from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .causal_intent_agent import CausalIntent
from .daily_environment import DailyReservoirEnvironment, clamp, safe_divide
from .skill_deliberation import (
    ConflictEdge,
    EvidenceBoundedDeliberationBackend,
    SkillClaim,
    SkillDeliberationResult,
    apply_certificate_feedback_adjustment,
    build_llm_deliberation_request,
    deterministic_validity_profile,
    project_llm_deliberation_payload,
    validate_llm_deliberation,
)


RELEASE_INTENTS = {
    "support_downstream_demands",
    "support_ecology",
    "pre_release_buffer",
}
CONSERVATION_INTENTS = {"conserve_storage", "recover_targets"}


@dataclass(frozen=True)
class FrozenContractEntry:
    entry_id: str
    payload: dict[str, Any]
    payload_hash: str
    source_count: int
    source_models: tuple[str, ...]
    source_request_hashes: tuple[str, ...]


class FrozenSemanticContractLibraryBackend:
    """Offline backend that retrieves and instantiates frozen LLM contracts.

    The backend treats prior LLM responses as reusable semantic contracts,
    transfers the selected contract to the current admissible evidence set, and
    then reuses the same validator and projection envelope as the online LLM
    backend.
    """

    name = "frozen_semantic_contract_library"

    def __init__(
        self,
        library_path: Path,
        fallback: EvidenceBoundedDeliberationBackend | None = None,
        max_ranked_candidates: int = 80,
        minimum_accept_score: float = 0.24,
    ) -> None:
        self.library_path = Path(library_path)
        self.entries = load_frozen_contract_library(self.library_path)
        self.library_sha256 = hashlib.sha256(
            self.library_path.read_bytes()
        ).hexdigest()
        self.fallback = fallback or EvidenceBoundedDeliberationBackend()
        self.max_ranked_candidates = max(1, max_ranked_candidates)
        self.minimum_accept_score = clamp(minimum_accept_score, 0.0, 1.0)
        self.events: list[dict[str, Any]] = []

    def deliberate(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        claims: list[SkillClaim],
        conflicts: list[ConflictEdge],
    ) -> SkillDeliberationResult:
        return self._deliberate(env, intent, claims, conflicts, None, 0)

    def deliberate_with_feedback(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        claims: list[SkillClaim],
        conflicts: list[ConflictEdge],
        certificate_feedback: dict[str, Any],
        round_index: int,
    ) -> SkillDeliberationResult:
        return self._deliberate(
            env,
            intent,
            claims,
            conflicts,
            certificate_feedback,
            round_index,
        )

    def _deliberate(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        claims: list[SkillClaim],
        conflicts: list[ConflictEdge],
        certificate_feedback: dict[str, Any] | None,
        round_index: int,
    ) -> SkillDeliberationResult:
        request = build_llm_deliberation_request(
            env,
            intent,
            claims,
            conflicts,
            certificate_feedback=certificate_feedback,
            round_index=round_index,
        )
        request_hash = stable_hash(request)
        if not claims:
            result = self.fallback.deliberate(env, intent, claims, conflicts)
            self._record_event(
                env,
                request_hash,
                "fallback_no_claims",
                None,
                0.0,
                "no_active_skill_claims",
                (),
                (),
                round_index,
                certificate_feedback,
            )
            return with_backend(result, f"{self.name}:fallback_no_claims")

        fallback = self.fallback.deliberate(env, intent, claims, conflicts)
        ranked = sorted(
            (
                (self._pre_score(entry.payload, fallback, claims, conflicts), entry)
                for entry in self.entries
            ),
            key=lambda item: item[0],
            reverse=True,
        )[: self.max_ranked_candidates]

        best: tuple[float, FrozenContractEntry, SkillDeliberationResult, str, tuple[str, ...], tuple[str, ...]] | None = None
        rejection_notes: list[str] = []
        for pre_score, entry in ranked:
            if pre_score <= 0.0:
                continue
            try:
                payload, transfer_actions = instantiate_contract_payload(
                    entry.payload,
                    fallback,
                    claims,
                    conflicts,
                    intent,
                )
            except ValueError as exc:
                rejection_notes.append(f"{entry.entry_id}:instantiate:{type(exc).__name__}")
                continue
            status = "transferred"
            repairs: tuple[str, ...] = ()
            try:
                result = validate_llm_deliberation(
                    payload,
                    intent,
                    claims,
                    conflicts,
                    f"{self.name}:transferred",
                )
            except (KeyError, TypeError, ValueError) as raw_error:
                try:
                    projected, repair_actions = project_llm_deliberation_payload(
                        payload,
                        intent,
                        claims,
                        conflicts,
                    )
                    result = validate_llm_deliberation(
                        projected,
                        intent,
                        claims,
                        conflicts,
                        f"{self.name}:projected",
                    )
                    status = "projected"
                    repairs = tuple(repair_actions)
                    result = SkillDeliberationResult(
                        **{
                            **result.__dict__,
                            "schema_valid": False,
                            "deliberation_trace": (
                                f"library_projection={','.join(repair_actions)} | "
                                f"{result.deliberation_trace}"
                            ),
                        }
                    )
                except (KeyError, TypeError, ValueError) as projected_error:
                    rejection_notes.append(
                        f"{entry.entry_id}:validate:{type(raw_error).__name__}/"
                        f"{type(projected_error).__name__}"
                    )
                    continue

            final_score = clamp(
                0.72 * pre_score + 0.28 * consistency_score(result, fallback, claims),
                0.0,
                1.0,
            )
            if best is None or final_score > best[0]:
                best = (
                    final_score,
                    entry,
                    result,
                    status,
                    tuple(transfer_actions),
                    repairs,
                )

        if best is None or best[0] < self.minimum_accept_score:
            result = with_backend(fallback, f"{self.name}:fallback")
            self._record_event(
                env,
                request_hash,
                "fallback",
                None,
                best[0] if best else 0.0,
                "no_valid_library_contract_above_gate",
                (),
                tuple(rejection_notes[:8]),
                round_index,
                certificate_feedback,
            )
            return result

        score, entry, result, status, transfer_actions, repairs = best
        if certificate_feedback is not None:
            result = apply_certificate_feedback_adjustment(
                result,
                certificate_feedback,
                f"{result.backend_name}:certificate_feedback",
                round_index,
            )
        result = SkillDeliberationResult(
            **{
                **result.__dict__,
                "deliberation_trace": (
                    f"library_entry={entry.entry_id};score={score:.3f};"
                    f"library_sha={self.library_sha256[:12]};"
                    f"transfer={','.join(transfer_actions) or 'none'} | "
                    f"{result.deliberation_trace}"
                ),
            }
        )
        self._record_event(
            env,
            request_hash,
            status,
            entry,
            score,
            "accepted",
            transfer_actions,
            repairs,
            round_index,
            certificate_feedback,
        )
        return result

    def _pre_score(
        self,
        payload: dict[str, Any],
        fallback: SkillDeliberationResult,
        claims: list[SkillClaim],
        conflicts: list[ConflictEdge],
    ) -> float:
        claim_by_skill = {claim.skill_name: claim for claim in claims}
        strength_by_intent = intent_strengths(claims)
        payload_active = set(as_string_list(payload.get("active_skills", [])))
        current_active = set(claim_by_skill)
        skill_overlap = safe_divide(
            len(payload_active & current_active),
            len(payload_active | current_active),
        )
        dominant = str(payload.get("dominant_intent", ""))
        dominant_support = strength_by_intent.get(dominant, 0.0)
        if dominant_support <= 0.0:
            priority = as_string_list(payload.get("priority_order", []))
            dominant_support = max(
                (strength_by_intent.get(name, 0.0) for name in priority),
                default=0.0,
            )
        current_edges = {
            (conflict.source_skill, conflict.target_skill)
            for conflict in conflicts
        }
        payload_edges = {
            (str(item.get("source_skill", "")), str(item.get("target_skill", "")))
            for item in payload.get("conflict_resolutions", [])
            if isinstance(item, dict)
        }
        conflict_overlap = (
            safe_divide(len(payload_edges & current_edges), len(current_edges))
            if current_edges
            else 1.0
        )
        modifier = modifier_direction_score(payload, claims)
        fallback_alignment = 1.0 if dominant == fallback.dominant_intent else 0.55
        recurrence = 1.0
        return clamp(
            0.30 * skill_overlap
            + 0.26 * dominant_support
            + 0.18 * modifier
            + 0.14 * conflict_overlap
            + 0.08 * fallback_alignment
            + 0.04 * recurrence,
            0.0,
            1.0,
        )

    def _record_event(
        self,
        env: DailyReservoirEnvironment,
        request_hash: str,
        status: str,
        entry: FrozenContractEntry | None,
        score: float,
        validation_status: str,
        transfer_actions: tuple[str, ...],
        repair_or_rejection: tuple[str, ...],
        round_index: int = 0,
        certificate_feedback: dict[str, Any] | None = None,
    ) -> None:
        self.events.append(
            {
                "date": env.current_date,
                "status": status,
                "deliberation_round": round_index,
                "certificate_feedback_present": certificate_feedback is not None,
                "certificate_feedback_reasons": (
                    list(certificate_feedback.get("requery_reasons", []))
                    if isinstance(certificate_feedback, dict)
                    else []
                ),
                "request_hash": request_hash,
                "library_path": str(self.library_path),
                "library_sha256": self.library_sha256,
                "entry_id": entry.entry_id if entry else "",
                "entry_payload_hash": entry.payload_hash if entry else "",
                "score": score,
                "contract_validation_status": validation_status,
                "transfer_actions": list(transfer_actions),
                "repair_or_rejection_notes": list(repair_or_rejection),
                "source_count": entry.source_count if entry else 0,
                "source_models": list(entry.source_models) if entry else [],
                "network_calls": 0,
                "total_tokens": 0,
            }
        )


def instantiate_contract_payload(
    payload: dict[str, Any],
    fallback: SkillDeliberationResult,
    claims: list[SkillClaim],
    conflicts: list[ConflictEdge],
    intent: CausalIntent,
) -> tuple[dict[str, Any], tuple[str, ...]]:
    claim_by_skill = {claim.skill_name: claim for claim in claims}
    allowed_intents = {claim.supported_intent for claim in claims} | {intent.primary_intent}
    actions: list[str] = []
    dominant = str(payload.get("dominant_intent", ""))
    if dominant not in allowed_intents or not any(
        claim.supported_intent == dominant for claim in claims
    ):
        replacement = first_supported_intent(
            as_string_list(payload.get("priority_order", [])),
            claims,
        ) or fallback.dominant_intent
        if replacement not in allowed_intents or not any(
            claim.supported_intent == replacement for claim in claims
        ):
            raise ValueError("No transferable dominant intent is supported now.")
        dominant = replacement
        actions.append("rebind_dominant_intent")

    active = [
        name
        for name in as_string_list(payload.get("active_skills", []))
        if name in claim_by_skill
    ]
    supporting = [
        claim.skill_name
        for claim in sorted(
            claims,
            key=lambda item: item.priority * item.confidence,
            reverse=True,
        )
        if claim.supported_intent == dominant
    ]
    if not any(claim_by_skill[name].supported_intent == dominant for name in active):
        if not supporting:
            raise ValueError("Dominant intent lacks an active support skill.")
        active.insert(0, supporting[0])
        actions.append("activate_current_dominant_support")
    for claim in sorted(claims, key=lambda item: item.priority * item.confidence, reverse=True):
        if len(active) >= 4:
            break
        if claim.skill_name not in active and claim.priority >= 0.20:
            active.append(claim.skill_name)
            actions.append("add_high_priority_current_skill")
    active = unique(active)

    citations = transferred_citations(payload, active, claim_by_skill)
    if not citations:
        raise ValueError("Transferred contract has no admissible evidence citation.")
    resolutions = transferred_conflict_resolutions(conflicts, claims, active, payload)
    priority = unique(
        [
            name
            for name in as_string_list(payload.get("priority_order", []))
            if name in allowed_intents
        ]
    )
    if dominant not in priority:
        priority.insert(0, dominant)
    auxiliary = unique(
        [
            name
            for name in as_string_list(payload.get("auxiliary_intents", []))
            if name in allowed_intents and name != dominant
        ]
    )
    rejected = unique(
        [
            name
            for name in as_string_list(payload.get("rejected_intents", []))
            if name in allowed_intents and name != dominant and name not in auxiliary
        ]
    )
    watch_features, radius, max_age, review_mode = transferred_validity_profile(
        payload,
        dominant,
        conflicts,
        intent,
    )
    cited_for_steps = tuple(active[: min(3, len(active))])
    return (
        {
            "contract_schema_version": "3.0",
            "dominant_intent": dominant,
            "auxiliary_intents": auxiliary,
            "rejected_intents": rejected,
            "priority_order": priority,
            "active_skills": active,
            "evidence_citations": citations,
            "conflict_resolutions": resolutions,
            "decision_steps": [
                {
                    "stage": "diagnosis",
                    "conclusion": (
                        f"Retrieved frozen semantic contract is instantiated on current "
                        f"evidence; {dominant} has active support."
                    ),
                    "cited_skills": list(cited_for_steps),
                },
                {
                    "stage": "conflict_resolution",
                    "conclusion": (
                        "Current directed skill conflicts are resolved with the retrieved "
                        "contract preference where compatible and bounded compromise otherwise."
                    ),
                    "cited_skills": list(cited_for_steps),
                },
                {
                    "stage": "policy_translation",
                    "conclusion": (
                        "The validated contract changes optimization weights but leaves "
                        "release feasibility to the physical certificate."
                    ),
                    "cited_skills": list(cited_for_steps),
                },
            ],
            "risk_posture": valid_risk_posture(str(payload.get("risk_posture", "balanced"))),
            "support_budget_multiplier": float(payload.get("support_budget_multiplier", 1.0)),
            "buffer_budget_multiplier": float(payload.get("buffer_budget_multiplier", 1.0)),
            "reserve_floor_delta_acft": float(payload.get("reserve_floor_delta_acft", 0.0)),
            "risk_aversion_delta": float(payload.get("risk_aversion_delta", 0.0)),
            "validity_profile": {
                "watch_features": list(watch_features),
                "novelty_tolerance": radius,
                "max_age_days": max_age,
                "safety_review_mode": review_mode,
            },
            "reasoning_summary": (
                "A prior LLM-authored semantic contract was selected from the frozen "
                "library, rebound to the current admissible evidence keys, and then "
                "validated before entering MPC."
            ),
        },
        tuple(unique(actions)),
    )


def transferred_citations(
    payload: dict[str, Any],
    active: list[str],
    claim_by_skill: dict[str, SkillClaim],
) -> list[dict[str, Any]]:
    citations: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in payload.get("evidence_citations", []):
        if not isinstance(item, dict):
            continue
        skill_name = str(item.get("skill_name", ""))
        if skill_name not in active or skill_name not in claim_by_skill:
            continue
        keys = [
            key
            for key in as_string_list(item.get("evidence_keys", []))
            if key in claim_by_skill[skill_name].evidence
        ]
        if keys:
            citations.append({"skill_name": skill_name, "evidence_keys": keys[:3]})
            seen.add(skill_name)
    for skill_name in active:
        if skill_name in seen:
            continue
        keys = list(claim_by_skill[skill_name].evidence)[:3]
        if keys:
            citations.append({"skill_name": skill_name, "evidence_keys": keys})
    return citations


def transferred_conflict_resolutions(
    conflicts: list[ConflictEdge],
    claims: list[SkillClaim],
    active: list[str],
    payload: dict[str, Any],
) -> list[dict[str, Any]]:
    if not conflicts:
        return []
    claim_strength = {
        claim.skill_name: claim.priority * claim.confidence
        for claim in claims
    }
    style_by_edge = {
        (str(item.get("source_skill", "")), str(item.get("target_skill", ""))): item
        for item in payload.get("conflict_resolutions", [])
        if isinstance(item, dict)
    }
    active_set = set(active)
    ranked = sorted(
        conflicts,
        key=lambda edge: (
            float(edge.source_skill in active_set or edge.target_skill in active_set),
            edge.severity,
        ),
        reverse=True,
    )
    resolutions: list[dict[str, Any]] = []
    for edge in ranked[: max(1, min(6, len(ranked)))]:
        previous = style_by_edge.get((edge.source_skill, edge.target_skill))
        if previous and str(previous.get("controlling_skill", "")) in {
            edge.source_skill,
            edge.target_skill,
        }:
            mode = str(previous.get("resolution", "bounded_compromise"))
            if mode not in {
                "favor_source",
                "favor_target",
                "bounded_compromise",
                "defer_to_physical_certificate",
            }:
                mode = "bounded_compromise"
            controlling = str(previous["controlling_skill"])
        else:
            source_weight = claim_strength.get(edge.source_skill, 0.0)
            target_weight = claim_strength.get(edge.target_skill, 0.0)
            if abs(source_weight - target_weight) <= 0.10:
                mode = "bounded_compromise"
            elif source_weight > target_weight:
                mode = "favor_source"
            else:
                mode = "favor_target"
            controlling = edge.source_skill if source_weight >= target_weight else edge.target_skill
        resolutions.append(
            {
                "source_skill": edge.source_skill,
                "target_skill": edge.target_skill,
                "resolution": mode,
                "controlling_skill": controlling,
            }
        )
    return resolutions


def transferred_validity_profile(
    payload: dict[str, Any],
    dominant: str,
    conflicts: list[ConflictEdge],
    intent: CausalIntent,
) -> tuple[tuple[str, ...], float, int, str]:
    default_features, default_radius, default_age, default_mode = deterministic_validity_profile(
        dominant,
        conflicts,
        intent,
    )
    profile = payload.get("validity_profile", {})
    if not isinstance(profile, dict):
        profile = {}
    features = [
        feature
        for feature in as_string_list(profile.get("watch_features", []))
        if feature in {
            "storage_ratio",
            "target_surplus",
            "target_encroachment",
            "demand_pressure",
            "forecast_shortage",
            "ecology_pressure",
            "drought_pressure",
            "uncertainty_pressure",
            "high_flow_pressure",
            "max_claim_priority",
            "release_claim_share",
            "conservation_claim_share",
        }
    ]
    for feature in default_features:
        if len(features) >= 6:
            break
        if feature not in features:
            features.append(feature)
    features = features[:6]
    if len(features) < 3:
        features = list(default_features[:3])
    radius = clamp(float(profile.get("novelty_tolerance", default_radius)), 0.08, 0.20)
    age = int(clamp(float(profile.get("max_age_days", default_age)), 7, 14))
    mode = str(profile.get("safety_review_mode", default_mode))
    if mode not in {"bidirectional", "service_sensitive", "reserve_sensitive"}:
        mode = default_mode
    return tuple(features), radius, age, mode


def intent_strengths(claims: list[SkillClaim]) -> dict[str, float]:
    strengths: dict[str, float] = {}
    max_strength = max((claim.priority * claim.confidence for claim in claims), default=1.0)
    for claim in claims:
        strength = safe_divide(claim.priority * claim.confidence, max_strength)
        strengths[claim.supported_intent] = max(
            strengths.get(claim.supported_intent, 0.0),
            strength,
        )
    return strengths


def modifier_direction_score(payload: dict[str, Any], claims: list[SkillClaim]) -> float:
    total = sum(max(0.0, claim.priority * claim.confidence) for claim in claims)
    release_drive = sum(
        claim.priority * claim.confidence
        for claim in claims
        if claim.supported_intent in RELEASE_INTENTS
    )
    conservation_drive = sum(
        claim.priority * claim.confidence
        for claim in claims
        if claim.supported_intent in CONSERVATION_INTENTS
    )
    release_share = safe_divide(release_drive, total)
    conservation_share = safe_divide(conservation_drive, total)
    support = float(payload.get("support_budget_multiplier", 1.0))
    reserve = float(payload.get("reserve_floor_delta_acft", 0.0))
    risk = float(payload.get("risk_aversion_delta", 0.0))
    release_score = 1.0 - abs((support - 1.0) - 0.18 * (release_share - conservation_share)) / 0.50
    reserve_expected = max(0.0, conservation_share - 0.35 * release_share)
    reserve_score = 1.0 - abs(math.tanh(reserve / 50000.0) - reserve_expected)
    risk_score = 1.0 - abs(clamp(risk / 0.35, 0.0, 1.0) - max(conservation_share, 0.25 * release_share))
    return clamp(0.45 * release_score + 0.30 * reserve_score + 0.25 * risk_score, 0.0, 1.0)


def consistency_score(
    result: SkillDeliberationResult,
    fallback: SkillDeliberationResult,
    claims: list[SkillClaim],
) -> float:
    strengths = intent_strengths(claims)
    dominant_strength = strengths.get(result.dominant_intent, 0.0)
    skill_coverage = safe_divide(
        len(set(result.active_skills) & {claim.skill_name for claim in claims}),
        max(1, len(result.active_skills)),
    )
    posture_score = 1.0 if result.risk_posture == fallback.risk_posture else 0.75
    return clamp(
        0.45 * dominant_strength + 0.35 * skill_coverage + 0.20 * posture_score,
        0.0,
        1.0,
    )


def first_supported_intent(priority_order: list[str], claims: list[SkillClaim]) -> str:
    supported = {claim.supported_intent for claim in claims}
    for name in priority_order:
        if name in supported:
            return name
    return ""


def valid_risk_posture(value: str) -> str:
    return value if value in {"conservative", "balanced", "service_oriented"} else "balanced"


def with_backend(result: SkillDeliberationResult, backend_name: str) -> SkillDeliberationResult:
    return SkillDeliberationResult(**{**result.__dict__, "backend_name": backend_name})


def load_frozen_contract_library(path: Path) -> list[FrozenContractEntry]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    entries = raw.get("entries", [])
    if not isinstance(entries, list) or not entries:
        raise ValueError(f"Frozen contract library has no entries: {path}")
    result: list[FrozenContractEntry] = []
    for index, item in enumerate(entries):
        if not isinstance(item, dict):
            continue
        payload = item.get("response_payload", item.get("payload"))
        if not isinstance(payload, dict):
            continue
        payload_hash = str(item.get("payload_sha256") or stable_hash(payload))
        result.append(
            FrozenContractEntry(
                entry_id=str(item.get("entry_id", f"contract_{index:04d}")),
                payload=payload,
                payload_hash=payload_hash,
                source_count=int(item.get("source_count", 1)),
                source_models=tuple(as_string_list(item.get("source_models", []))),
                source_request_hashes=tuple(
                    as_string_list(item.get("source_request_hashes", []))
                ),
            )
        )
    if not result:
        raise ValueError(f"Frozen contract library has no usable entries: {path}")
    return result


def stable_hash(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def as_string_list(value: Any) -> list[str]:
    if not isinstance(value, (list, tuple)):
        return []
    return [str(item) for item in value]


def unique(values: list[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        if value not in result:
            result.append(value)
    return result
