from __future__ import annotations

import hashlib
import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any


PROMPT_VERSION = "reservoir-deliberation-v3"
DEFAULT_BASE_URL = "https://api.deepseek.com"
DEFAULT_MODEL = "deepseek-v4-pro"


@dataclass(frozen=True)
class DeepSeekClientConfig:
    model: str = DEFAULT_MODEL
    base_url: str = DEFAULT_BASE_URL
    timeout_seconds: float = 90.0
    max_tokens: int = 1400
    reasoning_effort: str = "medium"
    thinking_enabled: bool = False
    max_retries: int = 3
    cache_dir: Path | None = None
    force_refresh: bool = False
    max_network_calls: int | None = None
    replay_only: bool = False


class DeepSeekDeliberationClient:
    """Audited callable adapter for DeepSeek's OpenAI-compatible endpoint."""

    def __init__(
        self,
        config: DeepSeekClientConfig | None = None,
        api_key: str | None = None,
    ) -> None:
        self.config = config or DeepSeekClientConfig()
        self.api_key = api_key or environment_secret("DEEPSEEK_API_KEY")
        if not self.api_key and not self.config.replay_only:
            raise RuntimeError(
                "DEEPSEEK_API_KEY is unavailable. Set it as a process or Windows user environment variable."
            )
        if not self.api_key:
            self.api_key = ""
        self.events: list[dict[str, Any]] = []
        self.network_call_count = 0
        if self.config.cache_dir is not None:
            self.config.cache_dir.mkdir(parents=True, exist_ok=True)

    def __call__(self, request: dict[str, Any]) -> dict[str, Any]:
        request_hash = stable_hash(
            {
                "prompt_version": PROMPT_VERSION,
                "model": self.config.model,
                "base_url": self.config.base_url,
                "thinking_enabled": self.config.thinking_enabled,
                "reasoning_effort": self.config.reasoning_effort,
                "max_tokens": self.config.max_tokens,
                "request": request,
            }
        )
        cache_path = self.cache_path(request_hash)
        if cache_path is not None and cache_path.exists() and not self.config.force_refresh:
            cached = json.loads(cache_path.read_text(encoding="utf-8"))
            self.events.append(
                sanitize_for_audit(
                    {
                    "request_hash": request_hash,
                    "prompt_version": PROMPT_VERSION,
                    "model": self.config.model,
                    "base_url": self.config.base_url,
                    "status": "cache_hit",
                    "cached": True,
                    "latency_seconds": 0.0,
                    "usage": cached.get("usage", {}),
                    "request": request,
                    "response_payload": cached["response_payload"],
                    },
                    self.api_key,
                )
            )
            return cached["response_payload"]

        if self.config.replay_only:
            event = {
                "request_hash": request_hash,
                "prompt_version": PROMPT_VERSION,
                "model": self.config.model,
                "base_url": self.config.base_url,
                "status": "replay_cache_miss",
                "cached": False,
                "network_call_count": self.network_call_count,
                "date": request.get("state", {}).get("date", ""),
                "deliberation_round": request.get("deliberation_round", 0),
            }
            self.events.append(sanitize_for_audit(event, self.api_key))
            raise DeepSeekReplayCacheMiss(request_hash, cache_path)

        if (
            self.config.max_network_calls is not None
            and self.network_call_count >= self.config.max_network_calls
        ):
            event = {
                "request_hash": request_hash,
                "prompt_version": PROMPT_VERSION,
                "model": self.config.model,
                "base_url": self.config.base_url,
                "status": "budget_exhausted",
                "cached": False,
                "network_call_count": self.network_call_count,
                "max_network_calls": self.config.max_network_calls,
                "date": request.get("state", {}).get("date", ""),
                "deliberation_round": request.get("deliberation_round", 0),
            }
            self.events.append(sanitize_for_audit(event, self.api_key))
            raise DeepSeekNetworkBudgetExceeded(
                self.network_call_count,
                self.config.max_network_calls,
            )
        self.network_call_count += 1
        body = self.request_body(request)
        started = time.perf_counter()
        last_error: Exception | None = None
        for attempt in range(1, self.config.max_retries + 1):
            try:
                response = self.post_json(body)
                choice = response["choices"][0]
                message = choice["message"]
                content = message.get("content")
                if not isinstance(content, str) or not content.strip():
                    reasoning = message.get("reasoning_content", "")
                    raise EmptyCompletionError(
                        finish_reason=str(choice.get("finish_reason", "")),
                        reasoning_length=len(reasoning) if isinstance(reasoning, str) else 0,
                        response_id=str(response.get("id", "")),
                    )
                payload = parse_json_object(content)
                latency = time.perf_counter() - started
                event = {
                    "request_hash": request_hash,
                    "prompt_version": PROMPT_VERSION,
                    "model": self.config.model,
                    "base_url": self.config.base_url,
                    "status": "success",
                    "cached": False,
                    "attempts": attempt,
                    "latency_seconds": latency,
                    "usage": response.get("usage", {}),
                    "request_id": response.get("id", ""),
                    "request": request,
                    "response_payload": payload,
                }
                self.events.append(sanitize_for_audit(event, self.api_key))
                if cache_path is not None:
                    cache_path.write_text(
                        json.dumps(
                            {
                                "request_hash": request_hash,
                                "prompt_version": PROMPT_VERSION,
                                "model": self.config.model,
                                "usage": response.get("usage", {}),
                                "response_payload": payload,
                            },
                            ensure_ascii=False,
                            indent=2,
                        ),
                        encoding="utf-8",
                    )
                return payload
            except (
                EmptyCompletionError,
                KeyError,
                TypeError,
                ValueError,
                json.JSONDecodeError,
                urllib.error.URLError,
            ) as exc:
                last_error = exc
                if attempt < self.config.max_retries:
                    time.sleep(min(8.0, 2.0 ** (attempt - 1)))

        latency = time.perf_counter() - started
        self.events.append(
            sanitize_for_audit(
                {
                "request_hash": request_hash,
                "prompt_version": PROMPT_VERSION,
                "model": self.config.model,
                "base_url": self.config.base_url,
                "status": "error",
                "cached": False,
                "attempts": self.config.max_retries,
                "latency_seconds": latency,
                "error_type": type(last_error).__name__ if last_error else "UnknownError",
                "error": str(last_error) if last_error else "Unknown DeepSeek error",
                "finish_reason": getattr(last_error, "finish_reason", ""),
                "reasoning_length": getattr(last_error, "reasoning_length", 0),
                "request_id": getattr(last_error, "response_id", ""),
                "request": request,
                },
                self.api_key,
            )
        )
        raise RuntimeError(f"DeepSeek deliberation failed: {last_error}") from last_error

    def request_body(self, request: dict[str, Any]) -> dict[str, Any]:
        system_prompt = (
            "You are the semantic deliberation layer of a safety-critical multi-reservoir "
            "scheduling agent. Resolve only the supplied evidence-bound skill claims. "
            "Never invent observations, skills, intents, constraints, or release actions. "
            "When certificate_feedback is supplied, treat it as a physical-certificate "
            "critique of the previous semantic contract and revise only the semantic "
            "contract fields allowed by output_schema. "
            "Use admissible_choices as closed enumerations. Rejected intents must also "
            "come from the admissible intent list. Evidence keys must belong to their "
            "cited skill. Return exactly one JSON object matching output_schema, without "
            "Markdown. Example JSON shape: "
            '{"contract_schema_version":"3.0",'
            '"dominant_intent":"support_downstream_demands",'
            '"auxiliary_intents":["conserve_storage"],"rejected_intents":[],'
            '"priority_order":["support_downstream_demands","conserve_storage"],'
            '"active_skills":["demand_support","drought_hedging"],'
            '"evidence_citations":[{"skill_name":"demand_support",'
            '"evidence_keys":["current_diversion_shortage_cfs"]}],'
            '"conflict_resolutions":[{"source_skill":"demand_support",'
            '"target_skill":"drought_hedging","resolution":"bounded_compromise",'
            '"controlling_skill":"demand_support"}],'
            '"decision_steps":[{"stage":"diagnosis","conclusion":"Immediate shortage '
            'dominates.","cited_skills":["demand_support"]},'
            '{"stage":"conflict_resolution","conclusion":"Retain a bounded reserve.",'
            '"cited_skills":["demand_support","drought_hedging"]},'
            '{"stage":"policy_translation","conclusion":"Increase support modestly.",'
            '"cited_skills":["demand_support"]}],'
            '"risk_posture":"balanced",'
            '"support_budget_multiplier":1.05,"buffer_budget_multiplier":1.0,'
            '"reserve_floor_delta_acft":5000.0,"risk_aversion_delta":0.03,'
            '"validity_profile":{"watch_features":["forecast_shortage","demand_pressure",'
            '"storage_ratio"],"novelty_tolerance":0.12,"max_age_days":7,'
            '"safety_review_mode":"bidirectional"},'
            '"reasoning_summary":"Evidence-bound explanation."}'
        )
        body: dict[str, Any] = {
            "model": self.config.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": json.dumps(request, ensure_ascii=False, separators=(",", ":")),
                },
            ],
            "stream": False,
            "max_tokens": self.config.max_tokens,
            "reasoning_effort": self.config.reasoning_effort,
            "response_format": {"type": "json_object"},
        }
        body["thinking"] = {"type": "enabled" if self.config.thinking_enabled else "disabled"}
        return body

    def post_json(self, body: dict[str, Any]) -> dict[str, Any]:
        endpoint = f"{self.config.base_url.rstrip('/')}/chat/completions"
        encoded = json.dumps(body, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            endpoint,
            data=encoded,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.config.timeout_seconds) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise urllib.error.URLError(f"HTTP {exc.code}: {detail[:1000]}") from exc

    def cache_path(self, request_hash: str) -> Path | None:
        if self.config.cache_dir is None:
            return None
        return self.config.cache_dir / f"{request_hash}.json"


def environment_secret(name: str) -> str | None:
    value = os.environ.get(name)
    if value:
        return value
    if os.name != "nt":
        return None
    try:
        import winreg

        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
            value, _ = winreg.QueryValueEx(key, name)
            return str(value) if value else None
    except (FileNotFoundError, OSError):
        return None


class EmptyCompletionError(ValueError):
    def __init__(self, finish_reason: str, reasoning_length: int, response_id: str) -> None:
        self.finish_reason = finish_reason
        self.reasoning_length = reasoning_length
        self.response_id = response_id
        super().__init__(
            "DeepSeek returned empty final content "
            f"(finish_reason={finish_reason!r}, reasoning_length={reasoning_length})."
        )


class DeepSeekNetworkBudgetExceeded(Exception):
    def __init__(self, network_call_count: int, max_network_calls: int) -> None:
        self.network_call_count = network_call_count
        self.max_network_calls = max_network_calls
        super().__init__(
            "DeepSeek network-call budget exhausted "
            f"({network_call_count}/{max_network_calls})."
        )


class DeepSeekReplayCacheMiss(Exception):
    def __init__(self, request_hash: str, cache_path: Path | None) -> None:
        self.request_hash = request_hash
        self.cache_path = cache_path
        super().__init__(
            "DeepSeek replay-only mode could not find a cached deliberation "
            f"for request_hash={request_hash}"
            + (f" at {cache_path}" if cache_path is not None else " because cache_dir is unset")
            + "."
        )


def parse_json_object(content: Any) -> dict[str, Any]:
    if isinstance(content, dict):
        return content
    if not isinstance(content, str):
        raise TypeError("DeepSeek response content must be a JSON string or object.")
    text = content.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        text = "\n".join(lines[1:-1]).strip()
    payload = json.loads(text)
    if not isinstance(payload, dict):
        raise TypeError("DeepSeek response must decode to a JSON object.")
    return payload


def stable_hash(payload: dict[str, Any]) -> str:
    encoded = json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def sanitize_for_audit(value: Any, secret: str) -> Any:
    if isinstance(value, dict):
        return {str(key): sanitize_for_audit(item, secret) for key, item in value.items()}
    if isinstance(value, list):
        return [sanitize_for_audit(item, secret) for item in value]
    if isinstance(value, tuple):
        return [sanitize_for_audit(item, secret) for item in value]
    if isinstance(value, str) and secret:
        return value.replace(secret, "[REDACTED]")
    return value
