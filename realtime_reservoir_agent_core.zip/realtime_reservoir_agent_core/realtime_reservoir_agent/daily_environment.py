from __future__ import annotations

import csv
from collections import defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from statistics import mean


CFS_DAY_TO_ACFT = 1.983471074
UNLIMITED_RELEASE_CFS = 900000.0


@dataclass(frozen=True)
class ReservoirSpec:
    reservoir_id: str
    name: str
    storage_min_acft: float
    storage_max_acft: float
    release_max_cfs: float
    initial_storage_acft: float
    active: bool

    @property
    def effective_release_max_cfs(self) -> float:
        if self.release_max_cfs >= UNLIMITED_RELEASE_CFS:
            return max(0.0, self.storage_max_acft - self.storage_min_acft) / CFS_DAY_TO_ACFT
        return max(0.0, self.release_max_cfs)


@dataclass
class StepResult:
    date: str
    next_date: str
    intent: dict[str, float | str]
    requested_releases_cfs: dict[str, float]
    applied_releases_cfs: dict[str, float]
    storage_acft: dict[str, float]
    next_storage_acft: dict[str, float]
    metrics: dict[str, float]


class DailyReservoirEnvironment:
    """Daily CDSS-derived reservoir-group environment.

    The environment is intentionally transparent: observations expose the
    forcing and storage state, `form_intent()` returns a structured reason for
    action, and `action_from_intent()` creates releases from explicit rule
    scores. It is not a StateMod replacement; reservoir inflow uses a documented
    stream-gage proxy until compatible daily StateMod outputs are available.
    """

    def __init__(
        self,
        dataset_dir: str | Path,
        reservoir_ids: list[str] | None = None,
        forecast_horizon_days: int = 7,
        inflow_capture_factor: float = 1.0,
        clamp_negative_streamflow: bool = False,
    ) -> None:
        self.dataset_dir = Path(dataset_dir)
        self.forecast_horizon_days = forecast_horizon_days
        self.inflow_capture_factor = inflow_capture_factor
        self.clamp_negative_streamflow = clamp_negative_streamflow

        self.nodes = read_records(self.dataset_dir / "nodes.csv")
        self.edges = read_records(self.dataset_dir / "edges.csv")
        self.reservoir_rows = read_records(self.dataset_dir / "reservoirs.csv")
        self.node_by_id = {row["node_id"]: row for row in self.nodes}
        self.adj = defaultdict(list)
        self.rev_adj = defaultdict(list)
        for edge in self.edges:
            upstream = edge["from_node_id"]
            downstream = edge["to_node_id"]
            self.adj[upstream].append(downstream)
            self.rev_adj[downstream].append(upstream)
        self.topological_order = [row["node_id"] for row in sorted(self.nodes, key=lambda item: int(item["topological_index"]))]

        self.forcing_dates, self.forcing_columns, self.forcing_values = read_wide(self.dataset_dir / "daily_forcing.csv")
        self.forcing_date_index = {day: idx for idx, day in enumerate(self.forcing_dates)}
        self.target_dates, self.target_columns, self.target_values = read_wide(
            self.dataset_dir / "daily_reservoir_targets_wide.csv"
        )
        self.target_date_index = {day: idx for idx, day in enumerate(self.target_dates)}

        all_specs = self._load_reservoir_specs()
        if reservoir_ids is None:
            self.reservoir_ids = [
                reservoir_id for reservoir_id, spec in all_specs.items()
                if spec.active and spec.storage_max_acft > 0.0
            ]
        else:
            self.reservoir_ids = reservoir_ids
        self.reservoir_specs = {reservoir_id: all_specs[reservoir_id] for reservoir_id in self.reservoir_ids}
        self.stream_columns = [column for column in self.forcing_columns if column.startswith("stream_base_flow__")]
        self.diversion_columns = [column for column in self.forcing_columns if column.startswith("diversion_demand__")]
        self.instream_columns = [column for column in self.forcing_columns if column.startswith("instream_flow_demand__")]
        self.stream_node_ids = [column.split("__", 1)[1] for column in self.stream_columns]
        self.diversion_node_ids = [column.split("__", 1)[1] for column in self.diversion_columns]
        self.instream_node_ids = [column.split("__", 1)[1] for column in self.instream_columns]
        self.inflow_proxy = self._build_inflow_proxy()

        self.date_index = 0
        self.storage_acft: dict[str, float] = {}

    def reset(self, start_date: str | None = None) -> dict[str, object]:
        if start_date is None:
            self.date_index = 0
        else:
            index = self.forcing_date_index.get(start_date)
            if index is None:
                raise ValueError(f"Date {start_date!r} is not in daily forcing range.")
            self.date_index = index
        current_date = self.current_date
        self.storage_acft = {}
        for reservoir_id, spec in self.reservoir_specs.items():
            target_max = self.target_max(current_date, reservoir_id, default=spec.initial_storage_acft)
            initial = target_max if target_max > 0 else spec.initial_storage_acft
            self.storage_acft[reservoir_id] = clamp(initial, spec.storage_min_acft, spec.storage_max_acft)
        return self.observation()

    @property
    def current_date(self) -> str:
        return self.forcing_dates[self.date_index]

    @property
    def next_date(self) -> str:
        return self.forcing_dates[min(self.date_index + 1, len(self.forcing_dates) - 1)]

    def observation(self) -> dict[str, object]:
        date = self.current_date
        return {
            "date": date,
            "forecast_horizon_days": self.forecast_horizon_days,
            "reservoir_ids": list(self.reservoir_ids),
            "storage_acft": dict(self.storage_acft),
            "target_min_acft": {reservoir_id: self.target_min(date, reservoir_id) for reservoir_id in self.reservoir_ids},
            "target_max_acft": {reservoir_id: self.target_max(date, reservoir_id) for reservoir_id in self.reservoir_ids},
            "forcing_today": self.forcing_row(date),
            "forecast_summary": self.forecast_summary(self.forecast_horizon_days),
            "inflow_proxy": dict(self.inflow_proxy),
        }

    def form_intent(self, forecast_horizon_days: int | None = None) -> dict[str, float | str]:
        horizon = forecast_horizon_days or self.forecast_horizon_days
        date = self.current_date
        forecast = self.forecast_summary(horizon)
        total_storage = sum(self.storage_acft.values())
        total_capacity = sum(spec.storage_max_acft for spec in self.reservoir_specs.values())
        storage_ratio = total_storage / total_capacity if total_capacity > 0 else 0.0
        total_target_min = sum(self.target_min(date, reservoir_id) for reservoir_id in self.reservoir_ids)
        total_target_max = sum(self.target_max(date, reservoir_id) for reservoir_id in self.reservoir_ids)
        demand_today = self.total_diversion_demand(date)
        instream_today = self.total_instream_demand(date)
        flow_today = self.total_stream_flow(date)
        demand_pressure = safe_divide(demand_today + instream_today, flow_today + 1.0)
        storage_surplus = safe_divide(total_storage - total_target_min, total_capacity)
        encroachment = safe_divide(total_storage - total_target_max, total_capacity)
        wetness = safe_divide(forecast["mean_stream_flow_cfs"], flow_today + 1.0)

        scores = {
            "conserve_storage": max(0.0, (0.45 - storage_ratio) * 2.0) + max(0.0, 1.0 - wetness),
            "support_downstream_demands": max(0.0, demand_pressure - 0.65),
            "support_ecology": max(0.0, instream_today / (flow_today + instream_today + 1.0)),
            "pre_release_buffer": max(0.0, encroachment * 4.0) + max(0.0, wetness - 1.35),
            "recover_targets": max(0.0, -storage_surplus * 4.0),
        }
        primary = max(scores, key=scores.get)
        if scores[primary] < 0.2:
            primary = "balanced"
        return {
            "primary_intent": primary,
            "storage_ratio": storage_ratio,
            "demand_pressure": demand_pressure,
            "forecast_wetness_ratio": wetness,
            "storage_surplus_ratio": storage_surplus,
            "target_encroachment_ratio": encroachment,
            **scores,
        }

    def action_from_intent(self, intent: dict[str, float | str] | None = None) -> dict[str, float]:
        if intent is None:
            intent = self.form_intent()
        date = self.current_date
        inflow_cfs = self.estimate_reservoir_inflows_cfs(date)
        primary = str(intent["primary_intent"])
        downstream_need_cfs = max(0.0, self.total_diversion_demand(date) + self.total_instream_demand(date) - self.total_stream_flow(date))
        release_request: dict[str, float] = {}
        available_surplus: dict[str, float] = {}
        total_surplus = 0.0

        for reservoir_id, spec in self.reservoir_specs.items():
            storage = self.storage_acft.get(reservoir_id, 0.0)
            inflow_acft = inflow_cfs.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT
            target_min = self.target_min(date, reservoir_id)
            target_max = self.target_max(date, reservoir_id)
            surplus_acft = max(0.0, storage + inflow_acft - target_min)
            available_surplus[reservoir_id] = surplus_acft
            total_surplus += surplus_acft
            target_tracking_cfs = max(0.0, storage + inflow_acft - target_max) / CFS_DAY_TO_ACFT

            if primary == "conserve_storage" or primary == "recover_targets":
                requested = target_tracking_cfs * 0.25
            elif primary == "pre_release_buffer":
                requested = target_tracking_cfs + 0.05 * surplus_acft / CFS_DAY_TO_ACFT
            else:
                requested = target_tracking_cfs
            release_request[reservoir_id] = requested

        if primary in {"support_downstream_demands", "support_ecology", "balanced"} and downstream_need_cfs > 0 and total_surplus > 0:
            support_fraction = 0.35 if primary == "balanced" else 0.75
            support_cfs = downstream_need_cfs * support_fraction
            for reservoir_id, surplus_acft in available_surplus.items():
                release_request[reservoir_id] += support_cfs * safe_divide(surplus_acft, total_surplus)

        return self.project_releases(release_request, inflow_cfs)

    def step(
        self,
        releases_cfs: dict[str, float] | None = None,
        intent_override: dict[str, float | str] | None = None,
    ) -> StepResult:
        if releases_cfs is None:
            intent = intent_override or self.form_intent()
            requested = self.action_from_intent(intent)
        else:
            intent = intent_override or self.form_intent()
            requested = dict(releases_cfs)
        date = self.current_date
        inflow_cfs = self.estimate_reservoir_inflows_cfs(date)
        applied = self.project_releases(requested, inflow_cfs)
        previous_storage = dict(self.storage_acft)
        next_storage: dict[str, float] = {}
        spill_cfs: dict[str, float] = {}

        for reservoir_id, spec in self.reservoir_specs.items():
            inflow_acft = inflow_cfs.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT
            release_acft = applied.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT
            raw_next = previous_storage.get(reservoir_id, 0.0) + inflow_acft - release_acft
            spill_acft = max(0.0, raw_next - spec.storage_max_acft)
            next_storage[reservoir_id] = clamp(raw_next, spec.storage_min_acft, spec.storage_max_acft)
            spill_cfs[reservoir_id] = spill_acft / CFS_DAY_TO_ACFT

        routing = self.route(date, {key: applied.get(key, 0.0) + spill_cfs.get(key, 0.0) for key in self.reservoir_ids})
        metrics = {
            **routing,
            "total_storage_acft": sum(previous_storage.values()),
            "total_next_storage_acft": sum(next_storage.values()),
            "total_inflow_proxy_cfs": sum(inflow_cfs.values()),
            "total_requested_release_cfs": sum(max(0.0, value) for value in requested.values()),
            "total_applied_release_cfs": sum(applied.values()),
            "total_spill_cfs": sum(spill_cfs.values()),
        }
        self.storage_acft = next_storage
        if self.date_index < len(self.forcing_dates) - 1:
            self.date_index += 1
        return StepResult(
            date=date,
            next_date=self.current_date,
            intent=intent,
            requested_releases_cfs=requested,
            applied_releases_cfs=applied,
            storage_acft=previous_storage,
            next_storage_acft=next_storage,
            metrics=metrics,
        )

    def project_releases(self, releases_cfs: dict[str, float], inflow_cfs: dict[str, float]) -> dict[str, float]:
        projected = {}
        for reservoir_id, spec in self.reservoir_specs.items():
            requested = max(0.0, releases_cfs.get(reservoir_id, 0.0))
            storage = self.storage_acft.get(reservoir_id, 0.0)
            available_cfs = max(0.0, storage + inflow_cfs.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT - spec.storage_min_acft) / CFS_DAY_TO_ACFT
            projected[reservoir_id] = min(requested, spec.effective_release_max_cfs, available_cfs)
        return projected

    def route(self, date: str, releases_cfs: dict[str, float]) -> dict[str, float]:
        base_arrival = defaultdict(float)
        release_arrival = defaultdict(float)
        total_diversion_demand = 0.0
        total_diversion_shortage_before = 0.0
        total_diversion_shortage_after = 0.0
        total_instream_demand = 0.0
        total_instream_shortage_before = 0.0
        total_instream_shortage_after = 0.0

        stream_values = self.stream_flow_by_node(date)
        diversion_values = self.diversion_demand_by_node(date)
        instream_values = self.instream_demand_by_node(date)

        for node_id in self.topological_order:
            local_base = stream_values.get(node_id, 0.0)
            base = max(base_arrival[node_id], local_base)
            release = release_arrival[node_id] + max(0.0, releases_cfs.get(node_id, 0.0))

            instream_req = instream_values.get(node_id, 0.0)
            if instream_req > 0:
                total_instream_demand += instream_req
                total_instream_shortage_before += max(0.0, instream_req - base)
                total_instream_shortage_after += max(0.0, instream_req - base - release)

            diversion_req = diversion_values.get(node_id, 0.0)
            if diversion_req > 0:
                total_diversion_demand += diversion_req
                met_base = min(base, diversion_req)
                base -= met_base
                remaining = diversion_req - met_base
                total_diversion_shortage_before += remaining
                met_release = min(release, remaining)
                release -= met_release
                total_diversion_shortage_after += remaining - met_release

            for downstream in self.adj.get(node_id, []):
                base_arrival[downstream] += base
                release_arrival[downstream] += release

        outlet_nodes = [row["node_id"] for row in self.nodes if row["is_outlet"] == "True"]
        base_outlet = sum(base_arrival[node] for node in outlet_nodes)
        release_outlet = sum(release_arrival[node] for node in outlet_nodes)
        return {
            "total_stream_base_cfs": sum(stream_values.values()),
            "total_diversion_demand_cfs": total_diversion_demand,
            "total_instream_demand_cfs": total_instream_demand,
            "diversion_shortage_before_release_cfs": total_diversion_shortage_before,
            "diversion_shortage_after_release_cfs": total_diversion_shortage_after,
            "instream_shortage_before_release_cfs": total_instream_shortage_before,
            "instream_shortage_after_release_cfs": total_instream_shortage_after,
            "total_shortage_before_release_cfs": total_diversion_shortage_before + total_instream_shortage_before,
            "total_shortage_after_release_cfs": total_diversion_shortage_after + total_instream_shortage_after,
            "baseflow_at_outlet_cfs": base_outlet,
            "release_at_outlet_cfs": release_outlet,
        }

    def forecast_summary(self, horizon_days: int) -> dict[str, float]:
        end_index = min(len(self.forcing_dates), self.date_index + max(1, horizon_days))
        dates = self.forcing_dates[self.date_index:end_index]
        stream = [self.total_stream_flow(day) for day in dates]
        diversion = [self.total_diversion_demand(day) for day in dates]
        instream = [self.total_instream_demand(day) for day in dates]
        return {
            "mean_stream_flow_cfs": mean(stream) if stream else 0.0,
            "max_stream_flow_cfs": max(stream) if stream else 0.0,
            "mean_diversion_demand_cfs": mean(diversion) if diversion else 0.0,
            "mean_instream_demand_cfs": mean(instream) if instream else 0.0,
        }

    def estimate_reservoir_inflows_cfs(self, date: str) -> dict[str, float]:
        stream_values = self.stream_flow_by_node(date)
        grouped_capacity = defaultdict(float)
        for reservoir_id, mapping in self.inflow_proxy.items():
            grouped_capacity[str(mapping["proxy_node_id"])] += self.reservoir_specs[reservoir_id].storage_max_acft
        inflows = {}
        for reservoir_id, mapping in self.inflow_proxy.items():
            proxy_node = str(mapping["proxy_node_id"])
            proxy_flow = stream_values.get(proxy_node, 0.0)
            cap = self.reservoir_specs[reservoir_id].storage_max_acft
            share = safe_divide(cap, grouped_capacity[proxy_node])
            inflows[reservoir_id] = proxy_flow * share * self.inflow_capture_factor
        return inflows

    def target_min(self, date: str, reservoir_id: str, default: float = 0.0) -> float:
        return self._target_value(date, f"target_min__{reservoir_id}", default)

    def target_max(self, date: str, reservoir_id: str, default: float = 0.0) -> float:
        spec = self.reservoir_specs.get(reservoir_id)
        fallback = spec.storage_max_acft if spec else default
        return self._target_value(date, f"target_max__{reservoir_id}", fallback)

    def forcing_row(self, date: str) -> dict[str, float]:
        idx = self.forcing_date_index[date]
        return {column: self.forcing_values[column][idx] for column in self.forcing_columns}

    def stream_flow_by_node(self, date: str) -> dict[str, float]:
        row = self.forcing_row(date)
        if self.clamp_negative_streamflow:
            return {column.split("__", 1)[1]: max(0.0, row[column]) for column in self.stream_columns}
        return {column.split("__", 1)[1]: row[column] for column in self.stream_columns}

    def diversion_demand_by_node(self, date: str) -> dict[str, float]:
        row = self.forcing_row(date)
        return {column.split("__", 1)[1]: row[column] for column in self.diversion_columns}

    def instream_demand_by_node(self, date: str) -> dict[str, float]:
        row = self.forcing_row(date)
        return {column.split("__", 1)[1]: row[column] for column in self.instream_columns}

    def total_stream_flow(self, date: str) -> float:
        return sum(self.stream_flow_by_node(date).values())

    def total_diversion_demand(self, date: str) -> float:
        return sum(self.diversion_demand_by_node(date).values())

    def total_instream_demand(self, date: str) -> float:
        return sum(self.instream_demand_by_node(date).values())

    def _load_reservoir_specs(self) -> dict[str, ReservoirSpec]:
        specs = {}
        for row in self.reservoir_rows:
            reservoir_id = row["reservoir_id"]
            specs[reservoir_id] = ReservoirSpec(
                reservoir_id=reservoir_id,
                name=row["name"],
                storage_min_acft=parse_float(row["content_min_acft"]),
                storage_max_acft=parse_float(row["content_max_acft"]),
                release_max_cfs=parse_float(row["release_max_cfs"]),
                initial_storage_acft=parse_float(row["initial_storage_acft"]),
                active=row["active"] == "True",
            )
        return specs

    def _target_value(self, date: str, column: str, default: float) -> float:
        idx = self.target_date_index.get(date)
        if idx is None:
            return default
        values = self.target_values.get(column)
        if values is None or idx >= len(values):
            return default
        return values[idx]

    def _build_inflow_proxy(self) -> dict[str, dict[str, str | int]]:
        stream_set = set(self.stream_node_ids)
        proxy = {}
        for reservoir_id in self.reservoir_ids:
            downstream = nearest_node(reservoir_id, self.adj, stream_set)
            if downstream is not None:
                proxy[reservoir_id] = {
                    "proxy_node_id": downstream[0],
                    "direction": "downstream_gage",
                    "hops": downstream[1],
                }
                continue
            upstream = nearest_node(reservoir_id, self.rev_adj, stream_set)
            if upstream is not None:
                proxy[reservoir_id] = {
                    "proxy_node_id": upstream[0],
                    "direction": "upstream_gage",
                    "hops": upstream[1],
                }
                continue
            proxy[reservoir_id] = {"proxy_node_id": self.stream_node_ids[0], "direction": "fallback_gage", "hops": -1}
        return proxy


def nearest_node(start: str, adjacency: dict[str, list[str]], candidates: set[str]) -> tuple[str, int] | None:
    queue = deque([(start, 0)])
    seen = {start}
    while queue:
        node, hops = queue.popleft()
        if node in candidates and node != start:
            return node, hops
        for nxt in adjacency.get(node, []):
            if nxt not in seen:
                seen.add(nxt)
                queue.append((nxt, hops + 1))
    return None


def read_records(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_wide(path: Path) -> tuple[list[str], list[str], dict[str, list[float]]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.reader(handle)
        header = next(reader)
        columns = header[1:]
        dates: list[str] = []
        values = {column: [] for column in columns}
        for row in reader:
            if not row:
                continue
            dates.append(row[0])
            for idx, column in enumerate(columns, start=1):
                values[column].append(parse_float(row[idx] if idx < len(row) else ""))
    return dates, columns, values


def parse_float(value: object, default: float = 0.0) -> float:
    try:
        text = str(value).strip()
        if text in {"", "NA", "NaN", "nan", "-999", "-999.0"}:
            return default
        return float(text)
    except (TypeError, ValueError):
        return default


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def safe_divide(numerator: float, denominator: float) -> float:
    return numerator / denominator if denominator else 0.0
