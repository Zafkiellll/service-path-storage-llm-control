from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from statistics import mean

from .daily_environment import DailyReservoirEnvironment, safe_divide


@dataclass(frozen=True)
class ForecastMember:
    source_date: str
    source_index: int
    stream_scale: float
    demand_scale: float
    values_by_lead: list[dict[str, float]]


@dataclass(frozen=True)
class EnsembleForecast:
    issue_date: str
    horizon_days: int
    members: list[ForecastMember]
    fallback_used: bool

    @property
    def member_count(self) -> int:
        return len(self.members)


class SeasonalAnalogEnsembleForecaster:
    """Realtime-compatible historical analog ensemble forecaster.

    For an issue date, candidates are earlier historical windows with similar
    day-of-year. The future segment of each candidate is already in the past
    relative to the issue date, so this is a hindcast-style forecast generator
    rather than future leakage. Stream and demand magnitudes are scaled by the
    current-day observed totals to preserve the present hydrologic state.
    """

    def __init__(
        self,
        env: DailyReservoirEnvironment,
        horizon_days: int = 14,
        ensemble_size: int = 24,
        analog_window_days: int = 21,
        min_members: int = 6,
        max_scale: float = 3.0,
    ) -> None:
        self.env = env
        self.horizon_days = horizon_days
        self.ensemble_size = ensemble_size
        self.analog_window_days = analog_window_days
        self.min_members = min_members
        self.max_scale = max_scale
        self.date_objects = [datetime.strptime(day, "%Y-%m-%d").date() for day in env.forcing_dates]
        self.day_of_year = [day.timetuple().tm_yday for day in self.date_objects]
        self.total_stream_by_index = [
            sum(env.forcing_values[column][idx] for column in env.stream_columns)
            for idx in range(len(env.forcing_dates))
        ]
        self.total_diversion_by_index = [
            sum(env.forcing_values[column][idx] for column in env.diversion_columns)
            for idx in range(len(env.forcing_dates))
        ]
        self.total_instream_by_index = [
            sum(env.forcing_values[column][idx] for column in env.instream_columns)
            for idx in range(len(env.forcing_dates))
        ]
        self.doy_to_indices: dict[int, list[int]] = {}
        for idx, doy in enumerate(self.day_of_year):
            self.doy_to_indices.setdefault(doy, []).append(idx)

    def forecast(self, issue_index: int | None = None, horizon_days: int | None = None) -> EnsembleForecast:
        if issue_index is None:
            issue_index = self.env.date_index
        horizon = horizon_days or self.horizon_days
        current_doy = self.day_of_year[issue_index]
        candidates = self._candidate_indices(issue_index, current_doy, horizon)
        members = [
            self._member_from_candidate(issue_index, candidate, horizon)
            for candidate in candidates[: self.ensemble_size]
        ]
        fallback_used = False
        if len(members) < self.min_members:
            fallback_used = True
            members.extend(self._persistence_members(issue_index, horizon, self.min_members - len(members)))
        return EnsembleForecast(
            issue_date=self.env.forcing_dates[issue_index],
            horizon_days=horizon,
            members=members,
            fallback_used=fallback_used,
        )

    def summarize(self, forecast: EnsembleForecast) -> dict[str, float]:
        stream_totals = []
        demand_totals = []
        instream_totals = []
        shortage_totals = []
        high_flow_totals = []
        for member in forecast.members:
            stream = sum(sum_leads(member.values_by_lead, self.env.stream_columns))
            demand = sum(sum_leads(member.values_by_lead, self.env.diversion_columns))
            instream = sum(sum_leads(member.values_by_lead, self.env.instream_columns))
            stream_totals.append(stream)
            demand_totals.append(demand)
            instream_totals.append(instream)
            shortage_totals.append(max(0.0, demand + instream - stream))
            high_flow_totals.append(stream)
        horizon = max(1, forecast.horizon_days)
        stream_daily = [value / horizon for value in stream_totals]
        demand_daily = [value / horizon for value in demand_totals]
        instream_daily = [value / horizon for value in instream_totals]
        shortage_daily = [value / horizon for value in shortage_totals]
        return {
            "forecast_member_count": float(forecast.member_count),
            "forecast_fallback_used": 1.0 if forecast.fallback_used else 0.0,
            "mean_stream_flow_cfs": mean(stream_daily) if stream_daily else 0.0,
            "p10_stream_flow_cfs": percentile(stream_daily, 0.10),
            "p90_stream_flow_cfs": percentile(stream_daily, 0.90),
            "mean_diversion_demand_cfs": mean(demand_daily) if demand_daily else 0.0,
            "mean_instream_demand_cfs": mean(instream_daily) if instream_daily else 0.0,
            "mean_shortage_pressure_cfs": mean(shortage_daily) if shortage_daily else 0.0,
            "p90_shortage_pressure_cfs": percentile(shortage_daily, 0.90),
            "stream_uncertainty_width_cfs": percentile(stream_daily, 0.90) - percentile(stream_daily, 0.10),
            "total_horizon_stream_cfs_day": mean(stream_totals) if stream_totals else 0.0,
            "total_horizon_shortage_cfs_day": mean(shortage_totals) if shortage_totals else 0.0,
            "p90_horizon_stream_cfs_day": percentile(high_flow_totals, 0.90),
        }

    def reservoir_inflow_summary(self, forecast: EnsembleForecast) -> dict[str, dict[str, float]]:
        totals_by_reservoir: dict[str, list[float]] = {reservoir_id: [] for reservoir_id in self.env.reservoir_ids}
        grouped_capacity = self._capacity_by_proxy_node()
        for member in forecast.members:
            proxy_stream_totals: dict[str, float] = {node_id: 0.0 for node_id in grouped_capacity}
            for lead_values in member.values_by_lead:
                for column in self.env.stream_columns:
                    node_id = column.split("__", 1)[1]
                    if node_id in proxy_stream_totals:
                        proxy_stream_totals[node_id] += lead_values.get(column, 0.0)
            member_totals = {reservoir_id: 0.0 for reservoir_id in self.env.reservoir_ids}
            for reservoir_id, mapping in self.env.inflow_proxy.items():
                proxy_node = str(mapping["proxy_node_id"])
                spec = self.env.reservoir_specs[reservoir_id]
                share = safe_divide(spec.storage_max_acft, grouped_capacity.get(proxy_node, 0.0))
                member_totals[reservoir_id] = proxy_stream_totals.get(proxy_node, 0.0) * share
            for reservoir_id, value in member_totals.items():
                totals_by_reservoir[reservoir_id].append(value)
        return {
            reservoir_id: {
                "mean_cfs_day": mean(values) if values else 0.0,
                "p90_cfs_day": percentile(values, 0.90),
                "p10_cfs_day": percentile(values, 0.10),
            }
            for reservoir_id, values in totals_by_reservoir.items()
        }

    def _candidate_indices(self, issue_index: int, current_doy: int, horizon: int) -> list[int]:
        candidates: list[tuple[float, int]] = []
        current_stream = self.total_stream_by_index[issue_index]
        current_demand = self.total_diversion_by_index[issue_index]
        for offset in range(-self.analog_window_days, self.analog_window_days + 1):
            doy = wrap_day_of_year(current_doy + offset)
            for candidate in self.doy_to_indices.get(doy, []):
                if candidate + horizon >= issue_index:
                    continue
                candidate_stream = self.total_stream_by_index[candidate]
                candidate_demand = self.total_diversion_by_index[candidate]
                hydro_distance = abs(safe_divide(candidate_stream - current_stream, current_stream + 1.0))
                demand_distance = abs(safe_divide(candidate_demand - current_demand, current_demand + 1.0))
                distance = abs(offset) / max(1, self.analog_window_days) + 0.65 * hydro_distance + 0.25 * demand_distance
                candidates.append((distance, candidate))
        candidates.sort(key=lambda item: item[0])
        return [candidate for _, candidate in candidates]

    def _member_from_candidate(self, issue_index: int, candidate: int, horizon: int) -> ForecastMember:
        issue_date = self.env.forcing_dates[issue_index]
        candidate_date = self.env.forcing_dates[candidate]
        stream_scale = bounded_scale(self.total_stream_by_index[issue_index], self.total_stream_by_index[candidate], self.max_scale)
        demand_scale = bounded_scale(
            self.total_diversion_by_index[issue_index] + self.total_instream_by_index[issue_index],
            self.total_diversion_by_index[candidate] + self.total_instream_by_index[candidate],
            self.max_scale,
        )
        values_by_lead = []
        for lead in range(horizon):
            source_index = min(candidate + lead, len(self.env.forcing_dates) - 1)
            source_date = self.env.forcing_dates[source_index]
            row = self.env.forcing_row(source_date)
            adjusted = {}
            for column, value in row.items():
                if column.startswith("stream_base_flow__"):
                    adjusted[column] = value * stream_scale
                elif column.startswith(("diversion_demand__", "instream_flow_demand__")):
                    adjusted[column] = value * demand_scale
                else:
                    adjusted[column] = value
            values_by_lead.append(adjusted)
        return ForecastMember(
            source_date=candidate_date,
            source_index=candidate,
            stream_scale=stream_scale,
            demand_scale=demand_scale,
            values_by_lead=values_by_lead,
        )

    def _persistence_members(self, issue_index: int, horizon: int, needed: int) -> list[ForecastMember]:
        issue_date = self.env.forcing_dates[issue_index]
        row = self.env.forcing_row(issue_date)
        members = []
        for member_idx in range(max(0, needed)):
            multiplier = 1.0 + 0.04 * (member_idx - needed / 2.0)
            values_by_lead = []
            for lead in range(horizon):
                lead_decay = max(0.75, 1.0 - 0.015 * lead)
                values_by_lead.append(
                    {
                        column: max(0.0, value * multiplier * lead_decay)
                        for column, value in row.items()
                    }
                )
            members.append(
                ForecastMember(
                    source_date=issue_date,
                    source_index=issue_index,
                    stream_scale=multiplier,
                    demand_scale=multiplier,
                    values_by_lead=values_by_lead,
                )
            )
        return members

    def _capacity_by_proxy_node(self) -> dict[str, float]:
        grouped: dict[str, float] = {}
        for reservoir_id, mapping in self.env.inflow_proxy.items():
            proxy_node = str(mapping["proxy_node_id"])
            grouped[proxy_node] = grouped.get(proxy_node, 0.0) + self.env.reservoir_specs[reservoir_id].storage_max_acft
        return grouped


def sum_leads(values_by_lead: list[dict[str, float]], columns: list[str]) -> list[float]:
    return [sum(lead.get(column, 0.0) for column in columns) for lead in values_by_lead]


def percentile(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    position = q * (len(ordered) - 1)
    low = int(position)
    high = min(low + 1, len(ordered) - 1)
    weight = position - low
    return ordered[low] * (1.0 - weight) + ordered[high] * weight


def bounded_scale(current: float, candidate: float, max_scale: float) -> float:
    if candidate <= 0:
        return 1.0
    return max(1.0 / max_scale, min(max_scale, current / candidate))


def wrap_day_of_year(day: int) -> int:
    while day < 1:
        day += 366
    while day > 366:
        day -= 366
    return day
