from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .daily_environment import CFS_DAY_TO_ACFT, DailyReservoirEnvironment, safe_divide
from .forecasting import EnsembleForecast, SeasonalAnalogEnsembleForecaster


INTENT_LABELS = (
    "conserve_storage",
    "support_downstream_demands",
    "support_ecology",
    "pre_release_buffer",
    "recover_targets",
    "balanced",
)


@dataclass(frozen=True)
class CausalIntent:
    primary_intent: str
    scores: dict[str, float]
    pressures: dict[str, float]
    obligations: dict[str, float]
    evidence: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {
            "primary_intent": self.primary_intent,
            **{f"score_{key}": value for key, value in self.scores.items()},
            **self.pressures,
            **{f"obligation_{key}": value for key, value in self.obligations.items()},
            "evidence_chain": self.evidence_chain(),
        }

    def evidence_chain(self) -> str:
        items = self.evidence.get("dominant_causes", [])
        return " -> ".join(str(item) for item in items)


class ForecastCausalIntentAgent:
    """Forecast-driven transparent causal-intent scheduler.

    The agent is deliberately split into two layers:

    1. A causal pressure layer maps storage state, topology-routed shortages,
       and ensemble forecast summaries into signed intent scores.
    2. A planning layer converts the selected intent into releases through
       explicit obligations and physical projection, rather than a black-box
       direct action head.
    """

    def __init__(
        self,
        forecaster: SeasonalAnalogEnsembleForecaster,
        shortage_support_fraction: float = 0.82,
        balanced_support_fraction: float = 0.38,
        ecology_support_fraction: float = 0.70,
        prerelease_fraction: float = 0.72,
    ) -> None:
        self.forecaster = forecaster
        self.shortage_support_fraction = shortage_support_fraction
        self.balanced_support_fraction = balanced_support_fraction
        self.ecology_support_fraction = ecology_support_fraction
        self.prerelease_fraction = prerelease_fraction

    def decide(self, env: DailyReservoirEnvironment) -> tuple[CausalIntent, dict[str, float], EnsembleForecast]:
        forecast = self.forecaster.forecast(env.date_index)
        forecast_summary = self.forecaster.summarize(forecast)
        reservoir_inflow = self.forecaster.reservoir_inflow_summary(forecast)
        intent = self.form_intent(env, forecast, forecast_summary, reservoir_inflow)
        releases = self.plan_releases(env, intent, forecast_summary, reservoir_inflow)
        return intent, releases, forecast

    def form_intent(
        self,
        env: DailyReservoirEnvironment,
        forecast: EnsembleForecast,
        forecast_summary: dict[str, float],
        reservoir_inflow: dict[str, dict[str, float]],
    ) -> CausalIntent:
        date = env.current_date
        no_release = env.route(date, {})
        total_capacity = sum(spec.storage_max_acft for spec in env.reservoir_specs.values())
        total_storage = sum(env.storage_acft.values())
        total_target_min = sum(env.target_min(date, reservoir_id) for reservoir_id in env.reservoir_ids)
        total_target_max = sum(env.target_max(date, reservoir_id) for reservoir_id in env.reservoir_ids)
        total_forecast_inflow_acft = sum(item["mean_cfs_day"] for item in reservoir_inflow.values()) * CFS_DAY_TO_ACFT
        p90_forecast_inflow_acft = sum(item["p90_cfs_day"] for item in reservoir_inflow.values()) * CFS_DAY_TO_ACFT

        current_shortage = no_release["total_shortage_before_release_cfs"]
        current_ecology_shortage = no_release["instream_shortage_before_release_cfs"]
        flow_today = max(0.0, env.total_stream_flow(date))
        demand_today = env.total_diversion_demand(date)
        instream_today = env.total_instream_demand(date)

        storage_ratio = safe_divide(total_storage, total_capacity)
        target_surplus = safe_divide(total_storage - total_target_min, total_capacity)
        target_encroachment = safe_divide(total_storage + p90_forecast_inflow_acft - total_target_max, total_capacity)
        forecast_shortage_pressure = safe_divide(forecast_summary["p90_shortage_pressure_cfs"], forecast_summary["mean_stream_flow_cfs"] + 1.0)
        current_demand_pressure = safe_divide(demand_today + instream_today, flow_today + 1.0)
        drought_pressure = max(0.0, safe_divide(flow_today - forecast_summary["p10_stream_flow_cfs"], flow_today + 1.0))
        uncertainty_pressure = safe_divide(forecast_summary["stream_uncertainty_width_cfs"], forecast_summary["mean_stream_flow_cfs"] + 1.0)
        high_flow_pressure = safe_divide(forecast_summary["p90_stream_flow_cfs"], flow_today + 1.0)
        ecology_pressure = safe_divide(current_ecology_shortage + forecast_summary["mean_instream_demand_cfs"], flow_today + 1.0)

        pressures = {
            "storage_ratio": storage_ratio,
            "target_surplus_ratio": target_surplus,
            "target_encroachment_ratio": target_encroachment,
            "current_demand_pressure": current_demand_pressure,
            "forecast_shortage_pressure": forecast_shortage_pressure,
            "drought_pressure": drought_pressure,
            "forecast_uncertainty_pressure": uncertainty_pressure,
            "high_flow_pressure": high_flow_pressure,
            "ecology_pressure": ecology_pressure,
            "current_shortage_cfs": current_shortage,
            "forecast_mean_stream_flow_cfs": forecast_summary["mean_stream_flow_cfs"],
            "forecast_p10_stream_flow_cfs": forecast_summary["p10_stream_flow_cfs"],
            "forecast_p90_stream_flow_cfs": forecast_summary["p90_stream_flow_cfs"],
            "forecast_member_count": forecast_summary["forecast_member_count"],
            "forecast_fallback_used": forecast_summary["forecast_fallback_used"],
        }

        scores = {
            "support_downstream_demands": 1.30 * forecast_shortage_pressure + 0.45 * max(0.0, current_demand_pressure - 0.65),
            "support_ecology": 1.15 * ecology_pressure + 0.35 * safe_divide(instream_today, flow_today + instream_today + 1.0),
            "pre_release_buffer": 1.25 * max(0.0, target_encroachment) + 0.50 * max(0.0, high_flow_pressure - 1.35),
            "conserve_storage": 1.10 * max(0.0, -target_surplus) + 0.55 * drought_pressure + 0.20 * uncertainty_pressure,
            "recover_targets": 1.40 * max(0.0, safe_divide(total_target_min - total_storage, total_capacity)),
        }
        primary = max(scores, key=scores.get)
        if scores[primary] < 0.18:
            primary = "balanced"

        obligations = {
            "shortage_support_cfs": forecast_summary["p90_shortage_pressure_cfs"],
            "ecology_support_cfs": current_ecology_shortage,
            "buffer_evacuate_acft": max(0.0, total_storage + p90_forecast_inflow_acft - total_target_max),
            "storage_recovery_acft": max(0.0, total_target_min - total_storage),
            "uncertainty_margin_cfs": forecast_summary["stream_uncertainty_width_cfs"],
        }
        evidence = {
            "dominant_causes": dominant_causes(primary, pressures, scores),
            "forecast_issue_date": forecast.issue_date,
            "horizon_days": forecast.horizon_days,
            "member_count": forecast.member_count,
            "fallback_used": forecast.fallback_used,
            "causal_graph": "forecast -> hydrologic pressure -> storage obligation -> intent -> constrained release",
        }
        return CausalIntent(primary, scores, pressures, obligations, evidence)

    def plan_releases(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast_summary: dict[str, float],
        reservoir_inflow: dict[str, dict[str, float]],
    ) -> dict[str, float]:
        date = env.current_date
        horizon = max(1, self.forecaster.horizon_days)
        current_inflow_cfs = env.estimate_reservoir_inflows_cfs(date)
        target_date = env.forcing_dates[min(len(env.forcing_dates) - 1, env.date_index + horizon - 1)]
        request = {}
        surplus_acft: dict[str, float] = {}
        total_surplus = 0.0

        for reservoir_id, spec in env.reservoir_specs.items():
            storage = env.storage_acft.get(reservoir_id, 0.0)
            forecast_inflow_acft = reservoir_inflow[reservoir_id]["mean_cfs_day"] * CFS_DAY_TO_ACFT
            forecast_p90_inflow_acft = reservoir_inflow[reservoir_id]["p90_cfs_day"] * CFS_DAY_TO_ACFT
            target_min = env.target_min(date, reservoir_id)
            target_max_future = env.target_max(target_date, reservoir_id)
            base_surplus = max(0.0, storage + 0.35 * forecast_inflow_acft - target_min)
            surplus_acft[reservoir_id] = base_surplus
            total_surplus += base_surplus

            buffer_release_cfs = max(0.0, storage + forecast_p90_inflow_acft - target_max_future) / CFS_DAY_TO_ACFT / horizon
            target_release_cfs = max(0.0, storage + current_inflow_cfs.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT - env.target_max(date, reservoir_id)) / CFS_DAY_TO_ACFT
            if intent.primary_intent == "pre_release_buffer":
                request[reservoir_id] = target_release_cfs + self.prerelease_fraction * buffer_release_cfs
            elif intent.primary_intent in {"conserve_storage", "recover_targets"}:
                request[reservoir_id] = 0.18 * target_release_cfs
            else:
                request[reservoir_id] = target_release_cfs

        support_budget = 0.0
        if intent.primary_intent == "support_downstream_demands":
            support_budget = self.shortage_support_fraction * max(
                forecast_summary["mean_shortage_pressure_cfs"],
                forecast_summary["p90_shortage_pressure_cfs"] * 0.55,
            )
        elif intent.primary_intent == "support_ecology":
            support_budget = self.ecology_support_fraction * max(
                intent.obligations["ecology_support_cfs"],
                forecast_summary["mean_instream_demand_cfs"] * 0.45,
            )
        elif intent.primary_intent == "balanced":
            support_budget = self.balanced_support_fraction * forecast_summary["mean_shortage_pressure_cfs"]

        if support_budget > 0 and total_surplus > 0:
            for reservoir_id, surplus in surplus_acft.items():
                request[reservoir_id] += support_budget * safe_divide(surplus, total_surplus)

        return env.project_releases(request, current_inflow_cfs)


def dominant_causes(primary: str, pressures: dict[str, float], scores: dict[str, float]) -> list[str]:
    cause_map = {
        "support_downstream_demands": [
            f"forecast_shortage_pressure={pressures['forecast_shortage_pressure']:.3f}",
            f"current_demand_pressure={pressures['current_demand_pressure']:.3f}",
            f"score={scores.get(primary, 0.0):.3f}",
        ],
        "support_ecology": [
            f"ecology_pressure={pressures['ecology_pressure']:.3f}",
            f"current_shortage_cfs={pressures['current_shortage_cfs']:.1f}",
            f"score={scores.get(primary, 0.0):.3f}",
        ],
        "pre_release_buffer": [
            f"target_encroachment_ratio={pressures['target_encroachment_ratio']:.3f}",
            f"high_flow_pressure={pressures['high_flow_pressure']:.3f}",
            f"score={scores.get(primary, 0.0):.3f}",
        ],
        "conserve_storage": [
            f"target_surplus_ratio={pressures['target_surplus_ratio']:.3f}",
            f"drought_pressure={pressures['drought_pressure']:.3f}",
            f"uncertainty={pressures['forecast_uncertainty_pressure']:.3f}",
        ],
        "recover_targets": [
            f"target_surplus_ratio={pressures['target_surplus_ratio']:.3f}",
            f"storage_ratio={pressures['storage_ratio']:.3f}",
            f"score={scores.get(primary, 0.0):.3f}",
        ],
        "balanced": [
            f"max_score={max(scores.values()) if scores else 0.0:.3f}",
            "no dominant pressure exceeded activation threshold",
        ],
    }
    return cause_map.get(primary, [])
