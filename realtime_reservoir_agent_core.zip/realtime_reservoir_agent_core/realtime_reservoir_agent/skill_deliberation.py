from __future__ import annotations

import json
import hashlib
import math
from dataclasses import dataclass
from statistics import mean
from typing import Any, Callable, Protocol

from .causal_intent_agent import CausalIntent
from .daily_environment import CFS_DAY_TO_ACFT, DailyReservoirEnvironment, clamp, safe_divide


@dataclass(frozen=True)
class SkillClaim:
    skill_name: str
    supported_intent: str
    priority: float
    confidence: float
    support_budget_cfs: float
    buffer_budget_cfs: float
    reserve_delta_acft: float
    risk_delta: float
    evidence: dict[str, float | str]
    rationale: str


@dataclass(frozen=True)
class ConflictEdge:
    source_skill: str
    target_skill: str
    conflict_type: str
    severity: float
    evidence: dict[str, float | str]


@dataclass(frozen=True)
class EvidenceCitation:
    skill_name: str
    evidence_keys: tuple[str, ...]


@dataclass(frozen=True)
class ConflictResolution:
    source_skill: str
    target_skill: str
    resolution: str
    controlling_skill: str


@dataclass(frozen=True)
class DecisionStep:
    stage: str
    conclusion: str
    cited_skills: tuple[str, ...]


@dataclass(frozen=True)
class SkillDeliberationResult:
    active_skills: tuple[str, ...]
    dominant_intent: str
    auxiliary_intents: tuple[str, ...]
    rejected_intents: tuple[str, ...]
    priority_order: tuple[str, ...]
    risk_posture: str
    support_budget_multiplier: float
    buffer_budget_multiplier: float
    reserve_floor_delta_acft: float
    risk_aversion_delta: float
    claims: tuple[SkillClaim, ...]
    conflicts: tuple[ConflictEdge, ...]
    backend_name: str
    schema_valid: bool
    evidence_bound: bool
    deliberation_trace: str
    event_triggered: bool = True
    trigger_score: float = 1.0
    trigger_reasons: tuple[str, ...] = ()
    contract_age_days: int = 0
    state_novelty: float = 1.0
    contract_reused: bool = False
    support_validity: float = 1.0
    semantic_state_hash: str = ""
    contract_schema_version: str = "2.0"
    evidence_citations: tuple[EvidenceCitation, ...] = ()
    conflict_resolutions: tuple[ConflictResolution, ...] = ()
    decision_steps: tuple[DecisionStep, ...] = ()
    watch_features: tuple[str, ...] = ()
    validity_radius: float = 0.16
    requested_max_age_days: int = 14
    safety_review_mode: str = "bidirectional"

    @property
    def conflict_count(self) -> int:
        return len(self.conflicts)

    @property
    def policy_contract(self) -> "DeliberationPolicyContract":
        return DeliberationPolicyContract(
            dominant_intent=self.dominant_intent,
            auxiliary_intents=self.auxiliary_intents,
            priority_order=self.priority_order,
            risk_posture=self.risk_posture,
            support_budget_multiplier=self.support_budget_multiplier,
            buffer_budget_multiplier=self.buffer_budget_multiplier,
            reserve_floor_delta_acft=self.reserve_floor_delta_acft,
            risk_aversion_delta=self.risk_aversion_delta,
            active_skills=self.active_skills,
            contract_schema_version=self.contract_schema_version,
            evidence_citations=self.evidence_citations,
            conflict_resolutions=self.conflict_resolutions,
            decision_steps=self.decision_steps,
            watch_features=self.watch_features,
            validity_radius=self.validity_radius,
            requested_max_age_days=self.requested_max_age_days,
            safety_review_mode=self.safety_review_mode,
        )


@dataclass(frozen=True)
class DeliberationPolicyContract:
    """Bounded semantic contract passed from deliberation to optimization."""

    dominant_intent: str
    auxiliary_intents: tuple[str, ...]
    priority_order: tuple[str, ...]
    risk_posture: str
    support_budget_multiplier: float
    buffer_budget_multiplier: float
    reserve_floor_delta_acft: float
    risk_aversion_delta: float
    active_skills: tuple[str, ...]
    contract_schema_version: str
    evidence_citations: tuple[EvidenceCitation, ...]
    conflict_resolutions: tuple[ConflictResolution, ...]
    decision_steps: tuple[DecisionStep, ...]
    watch_features: tuple[str, ...]
    validity_radius: float
    requested_max_age_days: int
    safety_review_mode: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "dominant_intent": self.dominant_intent,
            "auxiliary_intents": list(self.auxiliary_intents),
            "priority_order": list(self.priority_order),
            "risk_posture": self.risk_posture,
            "support_budget_multiplier": self.support_budget_multiplier,
            "buffer_budget_multiplier": self.buffer_budget_multiplier,
            "reserve_floor_delta_acft": self.reserve_floor_delta_acft,
            "risk_aversion_delta": self.risk_aversion_delta,
            "active_skills": list(self.active_skills),
            "contract_schema_version": self.contract_schema_version,
            "evidence_citations": [
                {
                    "skill_name": citation.skill_name,
                    "evidence_keys": list(citation.evidence_keys),
                }
                for citation in self.evidence_citations
            ],
            "conflict_resolutions": [
                {
                    "source_skill": resolution.source_skill,
                    "target_skill": resolution.target_skill,
                    "resolution": resolution.resolution,
                    "controlling_skill": resolution.controlling_skill,
                }
                for resolution in self.conflict_resolutions
            ],
            "decision_steps": [
                {
                    "stage": step.stage,
                    "conclusion": step.conclusion,
                    "cited_skills": list(step.cited_skills),
                }
                for step in self.decision_steps
            ],
            "validity_profile": {
                "watch_features": list(self.watch_features),
                "novelty_tolerance": self.validity_radius,
                "max_age_days": self.requested_max_age_days,
                "safety_review_mode": self.safety_review_mode,
            },
        }

    def stable_hash(self) -> str:
        payload = json.dumps(self.as_dict(), ensure_ascii=True, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class DeliberationBackend(Protocol):
    name: str

    def deliberate(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        claims: list[SkillClaim],
        conflicts: list[ConflictEdge],
    ) -> SkillDeliberationResult:
        ...


def backend_deliberate(
    backend: DeliberationBackend,
    env: DailyReservoirEnvironment,
    intent: CausalIntent,
    claims: list[SkillClaim],
    conflicts: list[ConflictEdge],
    certificate_feedback: dict[str, Any] | None = None,
    round_index: int = 0,
) -> SkillDeliberationResult:
    """Call a backend, using its feedback-aware method when available."""

    if certificate_feedback:
        method = getattr(backend, "deliberate_with_feedback", None)
        if callable(method):
            return method(
                env,
                intent,
                claims,
                conflicts,
                certificate_feedback,
                round_index,
            )
    return backend.deliberate(env, intent, claims, conflicts)


SEMANTIC_FEATURE_NAMES = (
    "storage_ratio",
    "target_surplus",
    "target_encroachment",
    "demand_pressure",
    "forecast_shortage",
    "ecology_pressure",
    "drought_pressure",
    "uncertainty_pressure",
    "high_flow_pressure",
    "max_claim_priority",
    "release_claim_share",
    "conservation_claim_share",
)


class MultiSkillDeliberationLayer:
    """Evidence-bound multi-skill deliberation before bilevel negotiation.

    Each skill makes a typed claim rather than a direct release decision. The
    deliberation backend then resolves conflicts into optimization-relevant
    modifiers. A real LLM can replace the backend as long as it returns the same
    schema; the default backend is deterministic for reproducible experiments.
    """

    def __init__(
        self,
        backend: DeliberationBackend | None = None,
        enable_conflict_graph: bool = True,
    ) -> None:
        self.backend = backend or EvidenceBoundedDeliberationBackend()
        self.enable_conflict_graph = enable_conflict_graph
        self.skills = (
            DemandSupportSkill(),
            EcologySupportSkill(),
            FloodBufferSkill(),
            DroughtHedgingSkill(),
            StorageRecoverySkill(),
            ForecastRobustnessSkill(),
        )

    def deliberate(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast_summary: dict[str, float],
        reservoir_inflow: dict[str, dict[str, float]],
        horizon_days: int,
    ) -> SkillDeliberationResult:
        _, claims, conflicts = self.claims_and_conflicts(
            env,
            intent,
            forecast_summary,
            reservoir_inflow,
            horizon_days,
        )
        return backend_deliberate(self.backend, env, intent, claims, conflicts)

    def deliberate_with_feedback(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast_summary: dict[str, float],
        reservoir_inflow: dict[str, dict[str, float]],
        horizon_days: int,
        certificate_feedback: dict[str, Any],
        round_index: int,
    ) -> SkillDeliberationResult:
        _, claims, conflicts = self.claims_and_conflicts(
            env,
            intent,
            forecast_summary,
            reservoir_inflow,
            horizon_days,
        )
        return backend_deliberate(
            self.backend,
            env,
            intent,
            claims,
            conflicts,
            certificate_feedback,
            round_index,
        )

    def claims_and_conflicts(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast_summary: dict[str, float],
        reservoir_inflow: dict[str, dict[str, float]],
        horizon_days: int,
    ) -> tuple[SkillContext, list[SkillClaim], list[ConflictEdge]]:
        context = SkillContext(
            env=env,
            intent=intent,
            forecast_summary=forecast_summary,
            reservoir_inflow=reservoir_inflow,
            horizon_days=horizon_days,
        )
        claims = [claim for skill in self.skills if (claim := skill.claim(context)) is not None]
        conflicts = conflict_matrix(claims) if self.enable_conflict_graph else []
        return context, claims, conflicts


@dataclass(frozen=True)
class SemanticStateSnapshot:
    date: str
    causal_intent: str
    features: dict[str, float]
    active_skills: tuple[str, ...]
    dominant_claim_intent: str
    mean_conflict_severity: float
    state_hash: str


class EventTriggeredMultiSkillDeliberationLayer(MultiSkillDeliberationLayer):
    """Persistent semantic contracts with evidence and safety invalidation.

    The expensive backend is called only when the current semantic state leaves
    the validity region of the accepted contract. Between events, the contract
    is revalidated against current claims and its numeric influence decays
    toward neutral values.
    """

    def __init__(
        self,
        backend: DeliberationBackend | None = None,
        novelty_threshold: float = 0.16,
        trigger_threshold: float = 0.22,
        max_contract_age_days: int = 14,
        minimum_support_validity: float = 0.55,
        conflict_escalation_threshold: float = 0.18,
        modifier_decay_rate: float = 0.0,
        safety_veto_streak_threshold: int = 3,
        safety_requery_cooldown_days: int = 7,
        safety_dual_drift_threshold: float = 0.15,
        enable_conflict_graph: bool = True,
    ) -> None:
        super().__init__(backend=backend, enable_conflict_graph=enable_conflict_graph)
        self.novelty_threshold = clamp(novelty_threshold, 0.01, 1.0)
        self.trigger_threshold = clamp(trigger_threshold, 0.01, 1.0)
        self.max_contract_age_days = max(1, max_contract_age_days)
        self.minimum_support_validity = clamp(minimum_support_validity, 0.0, 1.0)
        self.conflict_escalation_threshold = clamp(conflict_escalation_threshold, 0.0, 1.0)
        self.modifier_decay_rate = max(0.0, modifier_decay_rate)
        self.safety_veto_streak_threshold = max(1, safety_veto_streak_threshold)
        self.safety_requery_cooldown_days = max(1, safety_requery_cooldown_days)
        self.safety_dual_drift_threshold = clamp(
            safety_dual_drift_threshold,
            0.01,
            1.0,
        )
        self.last_result: SkillDeliberationResult | None = None
        self.accepted_result: SkillDeliberationResult | None = None
        self.issuance_snapshot: SemanticStateSnapshot | None = None
        self.previous_snapshot: SemanticStateSnapshot | None = None
        self.contract_age_days = 0
        self.safety_veto_streak = 0
        self.reserve_violation_streak = 0
        self.last_service_dual_weight = 1.0
        self.last_reserve_dual_weight = 1.0
        self.issuance_service_dual_weight = 1.0
        self.issuance_reserve_dual_weight = 1.0
        self.issuance_service_stress = False
        self.issuance_reserve_stress = False
        self.last_certificate_action = ""
        self.trigger_count = 0
        self.reuse_count = 0

    def snapshot_state(self) -> dict[str, Any]:
        return {
            "last_result": self.last_result,
            "accepted_result": self.accepted_result,
            "issuance_snapshot": self.issuance_snapshot,
            "previous_snapshot": self.previous_snapshot,
            "contract_age_days": self.contract_age_days,
            "safety_veto_streak": self.safety_veto_streak,
            "reserve_violation_streak": self.reserve_violation_streak,
            "last_service_dual_weight": self.last_service_dual_weight,
            "last_reserve_dual_weight": self.last_reserve_dual_weight,
            "issuance_service_dual_weight": self.issuance_service_dual_weight,
            "issuance_reserve_dual_weight": self.issuance_reserve_dual_weight,
            "issuance_service_stress": self.issuance_service_stress,
            "issuance_reserve_stress": self.issuance_reserve_stress,
            "last_certificate_action": self.last_certificate_action,
            "trigger_count": self.trigger_count,
            "reuse_count": self.reuse_count,
        }

    def restore_state(self, snapshot: dict[str, Any] | None) -> None:
        if not isinstance(snapshot, dict):
            return
        for name, value in snapshot.items():
            if hasattr(self, name):
                setattr(self, name, value)

    def deliberate(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast_summary: dict[str, float],
        reservoir_inflow: dict[str, dict[str, float]],
        horizon_days: int,
    ) -> SkillDeliberationResult:
        context, claims, conflicts = self.claims_and_conflicts(
            env,
            intent,
            forecast_summary,
            reservoir_inflow,
            horizon_days,
        )
        snapshot = semantic_state_snapshot(context, claims, conflicts)
        validity = self.contract_support_validity(claims)
        novelty = (
            semantic_state_distance(
                snapshot,
                self.issuance_snapshot,
                self.accepted_result.watch_features if self.accepted_result is not None else (),
            )
            if self.issuance_snapshot is not None
            else 1.0
        )
        conflict_escalation = max(
            0.0,
            snapshot.mean_conflict_severity
            - (
                self.issuance_snapshot.mean_conflict_severity
                if self.issuance_snapshot is not None
                else 0.0
            ),
        )
        causal_shift = (
            1.0
            if self.issuance_snapshot is not None
            and snapshot.causal_intent != self.issuance_snapshot.causal_intent
            else 0.0
        )
        service_misalignment, reserve_misalignment = self.directional_safety_misalignment()
        safety_signal = max(service_misalignment, reserve_misalignment)
        trigger_score = clamp(
            0.50 * novelty
            + 0.18 * conflict_escalation
            + 0.14 * causal_shift
            + 0.18 * safety_signal,
            0.0,
            1.0,
        )
        reasons = self.trigger_reasons(
            snapshot=snapshot,
            claims=claims,
            validity=validity,
            novelty=novelty,
            conflict_escalation=conflict_escalation,
            trigger_score=trigger_score,
        )

        if reasons:
            result = backend_deliberate(self.backend, env, intent, claims, conflicts)
            result = SkillDeliberationResult(
                **{
                    **result.__dict__,
                    "event_triggered": True,
                    "trigger_score": trigger_score,
                    "trigger_reasons": tuple(reasons),
                    "contract_age_days": 0,
                    "state_novelty": novelty,
                    "contract_reused": False,
                    "support_validity": validity,
                    "semantic_state_hash": snapshot.state_hash,
                    "deliberation_trace": (
                        f"event_trigger={','.join(reasons)};score={trigger_score:.3f};"
                        f"novelty={novelty:.3f};validity={validity:.3f} | "
                        f"{result.deliberation_trace}"
                    ),
                }
            )
            self.last_result = result
            self.accepted_result = result
            self.issuance_snapshot = snapshot
            self.contract_age_days = 0
            self.issuance_service_dual_weight = self.last_service_dual_weight
            self.issuance_reserve_dual_weight = self.last_reserve_dual_weight
            self.issuance_service_stress = (
                self.safety_veto_streak >= self.safety_veto_streak_threshold
            )
            self.issuance_reserve_stress = (
                self.reserve_violation_streak >= self.safety_veto_streak_threshold
            )
            if "service_safety_misalignment" in reasons:
                self.safety_veto_streak = 0
            if "reserve_safety_misalignment" in reasons:
                self.reserve_violation_streak = 0
            self.trigger_count += 1
        else:
            result = self.reuse_contract(intent, claims, conflicts, snapshot, novelty, validity, trigger_score)
            self.last_result = result
            self.contract_age_days += 1
            self.reuse_count += 1

        self.previous_snapshot = snapshot
        return result

    def deliberate_with_feedback(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast_summary: dict[str, float],
        reservoir_inflow: dict[str, dict[str, float]],
        horizon_days: int,
        certificate_feedback: dict[str, Any],
        round_index: int,
    ) -> SkillDeliberationResult:
        context, claims, conflicts = self.claims_and_conflicts(
            env,
            intent,
            forecast_summary,
            reservoir_inflow,
            horizon_days,
        )
        snapshot = semantic_state_snapshot(context, claims, conflicts)
        validity = self.contract_support_validity(claims)
        reasons = [
            "certificate_feedback",
            *[
                str(reason)
                for reason in certificate_feedback.get("requery_reasons", [])
                if str(reason)
            ],
        ]
        result = backend_deliberate(
            self.backend,
            env,
            intent,
            claims,
            conflicts,
            certificate_feedback,
            round_index,
        )
        result = SkillDeliberationResult(
            **{
                **result.__dict__,
                "event_triggered": True,
                "trigger_score": 1.0,
                "trigger_reasons": tuple(unique_strings(reasons)),
                "contract_age_days": 0,
                "state_novelty": 0.0,
                "contract_reused": False,
                "support_validity": validity,
                "semantic_state_hash": snapshot.state_hash,
                "deliberation_trace": (
                    f"certificate_feedback_round={round_index};"
                    f"reasons={','.join(unique_strings(reasons))} | "
                    f"{result.deliberation_trace}"
                ),
            }
        )
        self.last_result = result
        self.accepted_result = result
        self.issuance_snapshot = snapshot
        self.previous_snapshot = snapshot
        self.contract_age_days = 0
        self.issuance_service_dual_weight = self.last_service_dual_weight
        self.issuance_reserve_dual_weight = self.last_reserve_dual_weight
        self.issuance_service_stress = (
            self.safety_veto_streak >= self.safety_veto_streak_threshold
        )
        self.issuance_reserve_stress = (
            self.reserve_violation_streak >= self.safety_veto_streak_threshold
        )
        self.trigger_count += 1
        return result

    def trigger_reasons(
        self,
        snapshot: SemanticStateSnapshot,
        claims: list[SkillClaim],
        validity: float,
        novelty: float,
        conflict_escalation: float,
        trigger_score: float,
    ) -> list[str]:
        if self.accepted_result is None or self.issuance_snapshot is None:
            return ["initialize_contract"]
        reasons: list[str] = []
        allowed_intents = {claim.supported_intent for claim in claims}
        if self.accepted_result.dominant_intent not in allowed_intents:
            reasons.append("dominant_support_lost")
        if validity < self.minimum_support_validity:
            reasons.append("skill_support_degraded")
        contract_age_limit = min(
            self.max_contract_age_days,
            max(1, self.accepted_result.requested_max_age_days),
        )
        novelty_limit = clamp(
            self.accepted_result.validity_radius,
            0.05,
            self.novelty_threshold,
        )
        if self.contract_age_days >= contract_age_limit:
            reasons.append("contract_expired")
        if novelty >= novelty_limit:
            reasons.append("semantic_state_novelty")
        if conflict_escalation >= self.conflict_escalation_threshold:
            reasons.append("conflict_escalation")
        service_misalignment, reserve_misalignment = self.directional_safety_misalignment()
        if service_misalignment >= 0.50:
            reasons.append("service_safety_misalignment")
        if reserve_misalignment >= 0.50:
            reasons.append("reserve_safety_misalignment")
        if (
            snapshot.dominant_claim_intent != self.issuance_snapshot.dominant_claim_intent
            and trigger_score >= 0.75 * self.trigger_threshold
        ):
            reasons.append("dominant_claim_shift")
        if trigger_score >= self.trigger_threshold and not reasons:
            reasons.append("aggregate_trigger_score")
        return unique_strings(reasons)

    def contract_support_validity(self, claims: list[SkillClaim]) -> float:
        if self.accepted_result is None:
            return 1.0
        current_skills = {claim.skill_name for claim in claims}
        active = set(self.accepted_result.active_skills)
        skill_coverage = safe_divide(len(active & current_skills), max(1, len(active)))
        dominant_supported = any(
            claim.supported_intent == self.accepted_result.dominant_intent
            for claim in claims
        )
        return clamp(0.65 * skill_coverage + 0.35 * float(dominant_supported), 0.0, 1.0)

    def directional_safety_misalignment(self) -> tuple[float, float]:
        """Return bidirectional safety feedback only when semantics oppose the shield."""

        if self.accepted_result is None:
            return 0.0, 0.0
        contract = self.accepted_result
        review_mode = contract.safety_review_mode
        conservation_intents = {"conserve_storage", "recover_targets"}
        release_intents = {
            "support_downstream_demands",
            "support_ecology",
            "pre_release_buffer",
        }
        service_opposition = clamp(
            0.55 * float(contract.dominant_intent in conservation_intents)
            + 1.8 * max(0.0, 1.0 - contract.support_budget_multiplier)
            + safe_divide(contract.reserve_floor_delta_acft, 250000.0),
            0.0,
            1.0,
        )
        reserve_opposition = clamp(
            0.45 * float(contract.dominant_intent in release_intents)
            + 1.8 * max(0.0, contract.support_budget_multiplier - 1.0)
            + 0.8 * max(0.0, contract.buffer_budget_multiplier - 1.0),
            0.0,
            1.0,
        )
        service_stress = self.safety_veto_streak >= self.safety_veto_streak_threshold
        reserve_stress = self.reserve_violation_streak >= self.safety_veto_streak_threshold
        service_gate = self.safety_requery_gate(
            current_stress=service_stress,
            issuance_stress=self.issuance_service_stress,
            current_dual=self.last_service_dual_weight,
            issuance_dual=self.issuance_service_dual_weight,
        )
        reserve_gate = self.safety_requery_gate(
            current_stress=reserve_stress,
            issuance_stress=self.issuance_reserve_stress,
            current_dual=self.last_reserve_dual_weight,
            issuance_dual=self.issuance_reserve_dual_weight,
        )
        service_enabled = review_mode in {"bidirectional", "service_sensitive"}
        reserve_enabled = review_mode in {"bidirectional", "reserve_sensitive"}
        service_signal = clamp(
            float(service_enabled) * service_gate * service_opposition,
            0.0,
            1.0,
        )
        reserve_signal = clamp(
            float(reserve_enabled) * reserve_gate * reserve_opposition,
            0.0,
            1.0,
        )
        return service_signal, reserve_signal

    def safety_requery_gate(
        self,
        current_stress: bool,
        issuance_stress: bool,
        current_dual: float,
        issuance_dual: float,
    ) -> float:
        if not current_stress or self.contract_age_days < self.safety_requery_cooldown_days:
            return 0.0
        stress_onset = current_stress and not issuance_stress
        dual_drift = safe_divide(
            abs(current_dual - issuance_dual),
            max(1.0, issuance_dual),
        )
        if not stress_onset and dual_drift < self.safety_dual_drift_threshold:
            return 0.0
        return clamp(
            max(
                1.0 if stress_onset else 0.0,
                safe_divide(dual_drift, self.safety_dual_drift_threshold),
            ),
            0.0,
            1.0,
        )

    def reuse_contract(
        self,
        intent: CausalIntent,
        claims: list[SkillClaim],
        conflicts: list[ConflictEdge],
        snapshot: SemanticStateSnapshot,
        novelty: float,
        validity: float,
        trigger_score: float,
    ) -> SkillDeliberationResult:
        if self.accepted_result is None:
            raise RuntimeError("Cannot reuse a semantic contract before initialization.")
        previous = self.accepted_result
        claim_by_skill = {claim.skill_name: claim for claim in claims}
        allowed_intents = {claim.supported_intent for claim in claims} | {intent.primary_intent}
        active = [name for name in previous.active_skills if name in claim_by_skill]
        if not any(claim_by_skill[name].supported_intent == previous.dominant_intent for name in active):
            supporting = [
                claim.skill_name
                for claim in claims
                if claim.supported_intent == previous.dominant_intent
            ]
            if supporting:
                active.append(supporting[0])
        age = self.contract_age_days + 1
        decay = math.exp(-self.modifier_decay_rate * age)
        max_reserve = max(0.0, sum(claim.reserve_delta_acft for claim in claims))
        auxiliary = tuple(name for name in previous.auxiliary_intents if name in allowed_intents)
        rejected = tuple(name for name in previous.rejected_intents if name in allowed_intents)
        priority = [name for name in previous.priority_order if name in allowed_intents]
        if previous.dominant_intent not in priority:
            priority.insert(0, previous.dominant_intent)
        return SkillDeliberationResult(
            active_skills=tuple(unique_strings(active)),
            dominant_intent=previous.dominant_intent,
            auxiliary_intents=auxiliary,
            rejected_intents=rejected,
            priority_order=tuple(unique_strings(priority)),
            risk_posture=previous.risk_posture,
            support_budget_multiplier=1.0 + decay * (previous.support_budget_multiplier - 1.0),
            buffer_budget_multiplier=1.0 + decay * (previous.buffer_budget_multiplier - 1.0),
            reserve_floor_delta_acft=min(max_reserve, decay * previous.reserve_floor_delta_acft),
            risk_aversion_delta=decay * previous.risk_aversion_delta,
            claims=tuple(claims),
            conflicts=tuple(conflicts),
            backend_name=f"{base_backend_name(previous.backend_name)}:reused",
            schema_valid=previous.schema_valid,
            evidence_bound=all(bool(claim_by_skill[name].evidence) for name in active),
            deliberation_trace=(
                f"event_trigger=reuse;score={trigger_score:.3f};novelty={novelty:.3f};"
                f"validity={validity:.3f};age={age};decay={decay:.3f} | "
                f"contract={previous.policy_contract.stable_hash()}"
            ),
            event_triggered=False,
            trigger_score=trigger_score,
            trigger_reasons=("contract_reuse",),
            contract_age_days=age,
            state_novelty=novelty,
            contract_reused=True,
            support_validity=validity,
            semantic_state_hash=snapshot.state_hash,
            contract_schema_version=previous.contract_schema_version,
            evidence_citations=previous.evidence_citations,
            conflict_resolutions=previous.conflict_resolutions,
            decision_steps=previous.decision_steps,
            watch_features=previous.watch_features,
            validity_radius=previous.validity_radius,
            requested_max_age_days=previous.requested_max_age_days,
            safety_review_mode=previous.safety_review_mode,
        )

    def observe_outcome(self, diagnostics: dict[str, Any]) -> None:
        action = str(diagnostics.get("certificate_selected_action", ""))
        self.last_certificate_action = action
        if action == "service_override":
            self.safety_veto_streak += 1
        else:
            self.safety_veto_streak = 0
        reserve_violation = float(
            diagnostics.get("certificate_reserve_violation_acft", 0.0)
        )
        if reserve_violation > 1.0:
            self.reserve_violation_streak += 1
        else:
            self.reserve_violation_streak = 0
        self.last_service_dual_weight = float(
            diagnostics.get("certificate_service_dual_weight", 1.0)
        )
        self.last_reserve_dual_weight = float(
            diagnostics.get("certificate_reserve_dual_weight", 1.0)
        )


@dataclass(frozen=True)
class SkillContext:
    env: DailyReservoirEnvironment
    intent: CausalIntent
    forecast_summary: dict[str, float]
    reservoir_inflow: dict[str, dict[str, float]]
    horizon_days: int

    @property
    def date(self) -> str:
        return self.env.current_date

    @property
    def no_release(self) -> dict[str, float]:
        return self.env.route(self.date, {})

    @property
    def total_capacity_acft(self) -> float:
        return sum(spec.storage_max_acft for spec in self.env.reservoir_specs.values())

    @property
    def total_storage_acft(self) -> float:
        return sum(self.env.storage_acft.values())

    @property
    def total_target_min_acft(self) -> float:
        return sum(self.env.target_min(self.date, reservoir_id) for reservoir_id in self.env.reservoir_ids)

    @property
    def total_target_max_acft(self) -> float:
        return sum(self.env.target_max(self.date, reservoir_id) for reservoir_id in self.env.reservoir_ids)

    @property
    def p90_forecast_inflow_acft(self) -> float:
        return sum(item["p90_cfs_day"] for item in self.reservoir_inflow.values()) * CFS_DAY_TO_ACFT

    @property
    def storage_ratio(self) -> float:
        return safe_divide(self.total_storage_acft, self.total_capacity_acft)


class SchedulingSkill(Protocol):
    skill_name: str

    def claim(self, context: SkillContext) -> SkillClaim | None:
        ...


class DemandSupportSkill:
    skill_name = "demand_support"

    def claim(self, context: SkillContext) -> SkillClaim | None:
        shortage = context.no_release["diversion_shortage_before_release_cfs"]
        forecast_shortage = context.forecast_summary.get("p90_shortage_pressure_cfs", 0.0)
        demand_pressure = context.intent.pressures.get("current_demand_pressure", 0.0)
        priority = clamp(0.25 + 0.00055 * shortage + 0.35 * demand_pressure, 0.0, 1.0)
        if priority < 0.12 and forecast_shortage <= 0.0:
            return None
        support = max(shortage, 0.65 * forecast_shortage)
        return SkillClaim(
            skill_name=self.skill_name,
            supported_intent="support_downstream_demands",
            priority=priority,
            confidence=clamp(0.55 + 0.25 * safe_divide(shortage, support + 1.0), 0.0, 1.0),
            support_budget_cfs=support,
            buffer_budget_cfs=0.0,
            reserve_delta_acft=0.0,
            risk_delta=0.02,
            evidence={
                "current_diversion_shortage_cfs": shortage,
                "forecast_p90_shortage_cfs": forecast_shortage,
                "current_demand_pressure": demand_pressure,
            },
            rationale="Downstream demand shortage requires service-oriented support.",
        )


class EcologySupportSkill:
    skill_name = "ecology_support"

    def claim(self, context: SkillContext) -> SkillClaim | None:
        shortage = context.no_release["instream_shortage_before_release_cfs"]
        ecology_pressure = context.intent.pressures.get("ecology_pressure", 0.0)
        mean_instream = context.forecast_summary.get("mean_instream_demand_cfs", 0.0)
        priority = clamp(0.20 + 0.00075 * shortage + 0.45 * ecology_pressure, 0.0, 1.0)
        if priority < 0.12 and shortage <= 0.0:
            return None
        support = max(shortage, 0.45 * mean_instream)
        return SkillClaim(
            skill_name=self.skill_name,
            supported_intent="support_ecology",
            priority=priority,
            confidence=clamp(0.50 + 0.35 * safe_divide(shortage, support + 1.0), 0.0, 1.0),
            support_budget_cfs=support,
            buffer_budget_cfs=0.0,
            reserve_delta_acft=0.0,
            risk_delta=0.03,
            evidence={
                "current_instream_shortage_cfs": shortage,
                "ecology_pressure": ecology_pressure,
                "mean_instream_demand_cfs": mean_instream,
            },
            rationale="Ecological shortage creates a minimum flow-support obligation.",
        )


class FloodBufferSkill:
    skill_name = "flood_buffer"

    def claim(self, context: SkillContext) -> SkillClaim | None:
        encroachment = safe_divide(
            context.total_storage_acft + context.p90_forecast_inflow_acft - context.total_target_max_acft,
            context.total_capacity_acft,
        )
        high_flow = context.intent.pressures.get("high_flow_pressure", 0.0)
        priority = clamp(0.10 + 2.0 * max(0.0, encroachment) + 0.35 * max(0.0, high_flow - 1.10), 0.0, 1.0)
        if priority < 0.12:
            return None
        buffer_cfs = max(0.0, context.total_storage_acft + context.p90_forecast_inflow_acft - context.total_target_max_acft)
        buffer_cfs = buffer_cfs / CFS_DAY_TO_ACFT / max(1, context.horizon_days)
        return SkillClaim(
            skill_name=self.skill_name,
            supported_intent="pre_release_buffer",
            priority=priority,
            confidence=clamp(0.45 + 0.35 * priority, 0.0, 1.0),
            support_budget_cfs=0.15 * buffer_cfs,
            buffer_budget_cfs=buffer_cfs,
            reserve_delta_acft=0.0,
            risk_delta=0.08,
            evidence={
                "target_encroachment_ratio": encroachment,
                "high_flow_pressure": high_flow,
                "buffer_release_cfs": buffer_cfs,
            },
            rationale="High-flow and storage encroachment indicate need for buffer creation.",
        )


class DroughtHedgingSkill:
    skill_name = "drought_hedging"

    def claim(self, context: SkillContext) -> SkillClaim | None:
        drought = context.intent.pressures.get("drought_pressure", 0.0)
        uncertainty = context.intent.pressures.get("forecast_uncertainty_pressure", 0.0)
        surplus_ratio = context.intent.pressures.get("target_surplus_ratio", 0.0)
        priority = clamp(0.18 + 0.50 * drought + 0.25 * uncertainty + 0.60 * max(0.0, -surplus_ratio), 0.0, 1.0)
        if priority < 0.12:
            return None
        reserve = priority * 0.10 * context.total_capacity_acft
        return SkillClaim(
            skill_name=self.skill_name,
            supported_intent="conserve_storage",
            priority=priority,
            confidence=clamp(0.50 + 0.25 * drought + 0.15 * uncertainty, 0.0, 1.0),
            support_budget_cfs=0.0,
            buffer_budget_cfs=0.0,
            reserve_delta_acft=reserve,
            risk_delta=0.16 * priority,
            evidence={
                "drought_pressure": drought,
                "forecast_uncertainty_pressure": uncertainty,
                "target_surplus_ratio": surplus_ratio,
                "reserve_delta_acft": reserve,
            },
            rationale="Drought and uncertainty require a higher strategic storage reserve.",
        )


class StorageRecoverySkill:
    skill_name = "storage_recovery"

    def claim(self, context: SkillContext) -> SkillClaim | None:
        deficit = max(0.0, context.total_target_min_acft - context.total_storage_acft)
        priority = clamp(safe_divide(deficit, 0.08 * context.total_capacity_acft + 1.0), 0.0, 1.0)
        if priority < 0.08:
            return None
        return SkillClaim(
            skill_name=self.skill_name,
            supported_intent="recover_targets",
            priority=priority,
            confidence=clamp(0.60 + 0.25 * priority, 0.0, 1.0),
            support_budget_cfs=0.0,
            buffer_budget_cfs=0.0,
            reserve_delta_acft=0.65 * deficit,
            risk_delta=0.12 * priority,
            evidence={
                "storage_deficit_acft": deficit,
                "storage_ratio": context.storage_ratio,
            },
            rationale="Storage below target minimum requires recovery-oriented conservation.",
        )


class ForecastRobustnessSkill:
    skill_name = "forecast_robustness"

    def claim(self, context: SkillContext) -> SkillClaim | None:
        mean_flow = context.forecast_summary.get("mean_stream_flow_cfs", 0.0)
        uncertainty = safe_divide(context.forecast_summary.get("stream_uncertainty_width_cfs", 0.0), mean_flow + 1.0)
        priority = clamp(0.18 + 0.55 * uncertainty, 0.0, 1.0)
        if priority < 0.12:
            return None
        return SkillClaim(
            skill_name=self.skill_name,
            supported_intent=context.intent.primary_intent,
            priority=priority,
            confidence=clamp(0.55 + 0.30 * uncertainty, 0.0, 1.0),
            support_budget_cfs=0.0,
            buffer_budget_cfs=0.0,
            reserve_delta_acft=0.03 * priority * context.total_capacity_acft,
            risk_delta=0.18 * priority,
            evidence={
                "stream_uncertainty_width_cfs": context.forecast_summary.get("stream_uncertainty_width_cfs", 0.0),
                "mean_stream_flow_cfs": mean_flow,
                "uncertainty_ratio": uncertainty,
            },
            rationale="Forecast uncertainty requires tail-risk-aware planning.",
        )


class EvidenceBoundedDeliberationBackend:
    name = "deterministic_evidence_deliberation"

    def deliberate(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        claims: list[SkillClaim],
        conflicts: list[ConflictEdge],
    ) -> SkillDeliberationResult:
        if not claims:
            return SkillDeliberationResult(
                active_skills=(),
                dominant_intent=intent.primary_intent,
                auxiliary_intents=(),
                rejected_intents=(),
                priority_order=(intent.primary_intent,),
                risk_posture="neutral",
                support_budget_multiplier=1.0,
                buffer_budget_multiplier=1.0,
                reserve_floor_delta_acft=0.0,
                risk_aversion_delta=0.0,
                claims=(),
                conflicts=tuple(conflicts),
                backend_name=self.name,
                schema_valid=True,
                evidence_bound=True,
                deliberation_trace="No skill claim exceeded activation threshold; preserve causal intent.",
                contract_schema_version="3.0",
                decision_steps=(
                    DecisionStep(
                        "diagnosis",
                        "No scheduling skill exceeded its activation threshold.",
                        (),
                    ),
                    DecisionStep(
                        "conflict_resolution",
                        "No active skill conflict requires semantic arbitration.",
                        (),
                    ),
                    DecisionStep(
                        "policy_translation",
                        "Preserve the causal prior and neutral optimization modifiers.",
                        (),
                    ),
                ),
                watch_features=(
                    "storage_ratio",
                    "forecast_shortage",
                    "uncertainty_pressure",
                ),
                validity_radius=0.12,
                requested_max_age_days=7,
                safety_review_mode="bidirectional",
            )

        conflict_pressure = conflict_pressure_by_skill(conflicts)
        effective_weight = {
            claim.skill_name: claim.priority
            * claim.confidence
            * (1.0 - 0.35 * conflict_pressure.get(claim.skill_name, 0.0))
            for claim in claims
        }
        ordered = sorted(claims, key=lambda item: effective_weight[item.skill_name], reverse=True)
        dominant = ordered[0].supported_intent
        auxiliary = []
        rejected = []
        for claim in ordered[1:]:
            if claim.priority >= 0.30 and claim.supported_intent not in auxiliary and claim.supported_intent != dominant:
                auxiliary.append(claim.supported_intent)
            elif claim.supported_intent not in rejected and claim.supported_intent != dominant:
                rejected.append(claim.supported_intent)

        total_weight = sum(max(0.0, effective_weight[claim.skill_name]) for claim in claims)
        reserve_weighted = sum(claim.reserve_delta_acft * effective_weight[claim.skill_name] for claim in claims)
        risk_weighted = sum(claim.risk_delta * effective_weight[claim.skill_name] for claim in claims)
        release_intents = {"support_downstream_demands", "support_ecology", "pre_release_buffer"}
        conservation_intents = {"conserve_storage", "recover_targets"}
        release_drive = sum(
            effective_weight[claim.skill_name]
            for claim in claims
            if claim.supported_intent in release_intents
        )
        conservation_drive = sum(
            effective_weight[claim.skill_name]
            for claim in claims
            if claim.supported_intent in conservation_intents
        )
        flood_drive = sum(
            effective_weight[claim.skill_name]
            for claim in claims
            if claim.supported_intent == "pre_release_buffer"
        )
        support_multiplier = clamp(
            1.0 + 0.25 * safe_divide(release_drive - 0.90 * conservation_drive, total_weight),
            0.80,
            1.25,
        )
        buffer_multiplier = clamp(
            1.0 + 0.55 * safe_divide(flood_drive - 0.55 * conservation_drive, total_weight),
            0.75,
            1.50,
        )
        reserve_delta = safe_divide(reserve_weighted, total_weight)
        risk_delta = clamp(safe_divide(risk_weighted, total_weight), 0.0, 0.35)

        if risk_delta >= 0.18:
            posture = "conservative"
        elif support_multiplier >= 1.45 or buffer_multiplier >= 1.35:
            posture = "service_oriented"
        else:
            posture = "balanced"

        trace_parts = [
            f"{claim.skill_name}:{claim.supported_intent}:p={claim.priority:.3f}:c={claim.confidence:.3f}"
            for claim in ordered
        ]
        citations = tuple(
            EvidenceCitation(
                claim.skill_name,
                tuple(list(claim.evidence)[:2]),
            )
            for claim in ordered
            if claim.evidence
        )
        resolutions = deterministic_conflict_resolutions(
            conflicts,
            effective_weight,
        )
        watch_features, validity_radius, max_age_days, safety_review_mode = (
            deterministic_validity_profile(
                dominant,
                conflicts,
                intent,
            )
        )
        decision_steps = (
            DecisionStep(
                "diagnosis",
                f"{ordered[0].skill_name} provides the strongest evidence for {dominant}.",
                (ordered[0].skill_name,),
            ),
            DecisionStep(
                "conflict_resolution",
                (
                    "Resolve release-versus-storage claims using conflict-adjusted "
                    "priority and retain bounded countervailing modifiers."
                ),
                tuple(claim.skill_name for claim in ordered[: min(3, len(ordered))]),
            ),
            DecisionStep(
                "policy_translation",
                (
                    f"Translate {dominant} into support={support_multiplier:.3f}, "
                    f"buffer={buffer_multiplier:.3f}, reserve={reserve_delta:.1f}, "
                    f"risk={risk_delta:.3f}."
                ),
                (ordered[0].skill_name,),
            ),
        )
        return SkillDeliberationResult(
            active_skills=tuple(claim.skill_name for claim in ordered),
            dominant_intent=dominant,
            auxiliary_intents=tuple(auxiliary),
            rejected_intents=tuple(rejected),
            priority_order=tuple(claim.supported_intent for claim in ordered),
            risk_posture=posture,
            support_budget_multiplier=support_multiplier,
            buffer_budget_multiplier=buffer_multiplier,
            reserve_floor_delta_acft=reserve_delta,
            risk_aversion_delta=risk_delta,
            claims=tuple(claims),
            conflicts=tuple(conflicts),
            backend_name=self.name,
            schema_valid=True,
            evidence_bound=all(bool(claim.evidence) for claim in claims),
            deliberation_trace=" | ".join(trace_parts),
            contract_schema_version="3.0",
            evidence_citations=citations,
            conflict_resolutions=resolutions,
            decision_steps=decision_steps,
            watch_features=watch_features,
            validity_radius=validity_radius,
            requested_max_age_days=max_age_days,
            safety_review_mode=safety_review_mode,
        )

    def deliberate_with_feedback(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        claims: list[SkillClaim],
        conflicts: list[ConflictEdge],
        certificate_feedback: dict[str, Any],
        round_index: int,
    ) -> SkillDeliberationResult:
        result = self.deliberate(env, intent, claims, conflicts)
        return apply_certificate_feedback_adjustment(
            result,
            certificate_feedback,
            f"{self.name}:certificate_feedback",
            round_index,
        )


def apply_certificate_feedback_adjustment(
    result: SkillDeliberationResult,
    certificate_feedback: dict[str, Any],
    backend_name: str,
    round_index: int,
) -> SkillDeliberationResult:
    """Schema-preserving modifier update for certificate-triggered re-review."""

    reasons = {str(reason) for reason in certificate_feedback.get("requery_reasons", [])}
    selected_action = str(certificate_feedback.get("selected_action", ""))
    service_regret = float(certificate_feedback.get("service_regret_cfs", 0.0) or 0.0)
    reserve_violation = float(certificate_feedback.get("reserve_violation_acft", 0.0) or 0.0)
    override_margin = float(certificate_feedback.get("override_margin", 0.0) or 0.0)
    service_pressure = (
        selected_action == "service_override"
        or "certificate_action:service_override" in reasons
        or service_regret > 0.0
        or override_margin > 0.0
    )
    reserve_pressure = (
        "reserve_violation" in reasons
        or reserve_violation > 0.0
        or "viability_failure" in reasons
    )
    support = result.support_budget_multiplier
    buffer = result.buffer_budget_multiplier
    reserve_delta = result.reserve_floor_delta_acft
    risk_delta = result.risk_aversion_delta
    posture = result.risk_posture

    if service_pressure and not reserve_pressure:
        support = clamp(support + 0.08 + 0.04 * min(1.0, safe_divide(override_margin, 250.0)), 0.75, 1.30)
        reserve_delta = max(0.0, 0.82 * reserve_delta)
        risk_delta = clamp(0.90 * risk_delta, 0.0, 0.35)
        posture = "service_oriented" if support >= 1.08 else "balanced"
    elif reserve_pressure and not service_pressure:
        support = clamp(support - 0.06, 0.75, 1.30)
        buffer = clamp(buffer - 0.03, 0.70, 1.50)
        reserve_delta = max(reserve_delta, min(reserve_delta + 0.08 * reserve_violation, reserve_delta + 35000.0))
        risk_delta = clamp(risk_delta + 0.04, 0.0, 0.35)
        posture = "conservative"
    elif service_pressure and reserve_pressure:
        support = clamp(0.5 * support + 0.5 * min(1.10, support + 0.04), 0.75, 1.30)
        buffer = clamp(buffer, 0.70, 1.50)
        reserve_delta = max(reserve_delta, min(reserve_delta + 0.04 * reserve_violation, reserve_delta + 20000.0))
        risk_delta = clamp(risk_delta + 0.02, 0.0, 0.35)
        posture = "balanced"

    trace_note = (
        f"certificate_feedback_adjustment=round:{round_index};"
        f"selected_action:{selected_action};"
        f"service_regret:{service_regret:.3f};"
        f"reserve_violation:{reserve_violation:.3f};"
        f"reasons:{','.join(sorted(reasons)) or 'none'}"
    )
    return SkillDeliberationResult(
        **{
            **result.__dict__,
            "backend_name": backend_name,
            "risk_posture": posture,
            "support_budget_multiplier": support,
            "buffer_budget_multiplier": buffer,
            "reserve_floor_delta_acft": reserve_delta,
            "risk_aversion_delta": risk_delta,
            "deliberation_trace": f"{trace_note} | {result.deliberation_trace}",
        }
    )


class StructuredLlmDeliberationBackend:
    """Provider-neutral LLM backend with a hard evidence and schema envelope.

    `llm_call` receives a JSON-serializable request and must return either a
    dictionary or a JSON string. The LLM decides the deliberation, but it may
    only select active skills and intents supported by current claims. Numeric
    modifiers are bounded before they enter negotiation and MPC.
    """

    name = "structured_llm_deliberation"

    def __init__(
        self,
        llm_call: Callable[[dict[str, Any]], dict[str, Any] | str],
        fallback: DeliberationBackend | None = None,
    ) -> None:
        self.llm_call = llm_call
        self.fallback = fallback or EvidenceBoundedDeliberationBackend()

    def deliberate(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        claims: list[SkillClaim],
        conflicts: list[ConflictEdge],
    ) -> SkillDeliberationResult:
        return self._deliberate(env, intent, claims, conflicts, None, 0)

    def deliberate_with_feedback(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        claims: list[SkillClaim],
        conflicts: list[ConflictEdge],
        certificate_feedback: dict[str, Any],
        round_index: int,
    ) -> SkillDeliberationResult:
        return self._deliberate(
            env,
            intent,
            claims,
            conflicts,
            certificate_feedback,
            round_index,
        )

    def _deliberate(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        claims: list[SkillClaim],
        conflicts: list[ConflictEdge],
        certificate_feedback: dict[str, Any] | None,
        round_index: int,
    ) -> SkillDeliberationResult:
        if not claims:
            return self.fallback.deliberate(env, intent, claims, conflicts)
        request = build_llm_deliberation_request(
            env,
            intent,
            claims,
            conflicts,
            certificate_feedback=certificate_feedback,
            round_index=round_index,
        )
        try:
            raw = self.llm_call(request)
            payload = json.loads(raw) if isinstance(raw, str) else raw
            try:
                result = validate_llm_deliberation(payload, intent, claims, conflicts, self.name)
                self.record_validation_status("accepted")
                return result
            except ValueError as raw_error:
                projected, repair_actions = project_llm_deliberation_payload(
                    payload,
                    intent,
                    claims,
                    conflicts,
                )
                result = validate_llm_deliberation(
                    projected,
                    intent,
                    claims,
                    conflicts,
                    f"{self.name}:projected",
                )
                self.record_validation_status(
                    "projected",
                    raw_error=raw_error,
                    repair_actions=repair_actions,
                )
                return SkillDeliberationResult(
                    **{
                        **result.__dict__,
                        "schema_valid": False,
                        "deliberation_trace": (
                            f"contract_projection={','.join(repair_actions)} | "
                            f"{result.deliberation_trace}"
                        ),
                    }
                )
        except (KeyError, TypeError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
            events = getattr(self.llm_call, "events", None)
            if isinstance(events, list) and events:
                events[-1]["contract_validation_status"] = "rejected"
                events[-1]["contract_validation_error_type"] = type(exc).__name__
                events[-1]["contract_validation_error"] = str(exc)
            fallback = self.fallback.deliberate(env, intent, claims, conflicts)
            return SkillDeliberationResult(
                **{
                    **fallback.__dict__,
                    "backend_name": f"{self.name}:fallback",
                    "schema_valid": False,
                    "deliberation_trace": (
                        f"llm_contract_rejected={type(exc).__name__}:{exc} | "
                        f"{fallback.deliberation_trace}"
                    ),
                }
            )

    def record_validation_status(
        self,
        status: str,
        raw_error: Exception | None = None,
        repair_actions: list[str] | None = None,
    ) -> None:
        events = getattr(self.llm_call, "events", None)
        if not isinstance(events, list) or not events:
            return
        events[-1]["contract_validation_status"] = status
        if raw_error is not None:
            events[-1]["raw_contract_error_type"] = type(raw_error).__name__
            events[-1]["raw_contract_error"] = str(raw_error)
        if repair_actions:
            events[-1]["contract_repair_actions"] = list(repair_actions)


def conflict_matrix(claims: list[SkillClaim]) -> list[ConflictEdge]:
    conflicts: list[ConflictEdge] = []
    for source in claims:
        for target in claims:
            if source.skill_name == target.skill_name:
                continue
            conflict = pairwise_conflict(source, target)
            if conflict is not None:
                conflicts.append(conflict)
    return conflicts


def conflict_pressure_by_skill(conflicts: list[ConflictEdge]) -> dict[str, float]:
    pressure: dict[str, float] = {}
    counts: dict[str, int] = {}
    for conflict in conflicts:
        for skill_name in (conflict.source_skill, conflict.target_skill):
            pressure[skill_name] = pressure.get(skill_name, 0.0) + conflict.severity
            counts[skill_name] = counts.get(skill_name, 0) + 1
    return {
        skill_name: clamp(safe_divide(total, counts.get(skill_name, 1)), 0.0, 1.0)
        for skill_name, total in pressure.items()
    }


def build_llm_deliberation_request(
    env: DailyReservoirEnvironment,
    intent: CausalIntent,
    claims: list[SkillClaim],
    conflicts: list[ConflictEdge],
    certificate_feedback: dict[str, Any] | None = None,
    round_index: int = 0,
) -> dict[str, Any]:
    admissible_intents = sorted(
        {claim.supported_intent for claim in claims} | {intent.primary_intent}
    )
    intent_support_map = {
        intent_name: [
            claim.skill_name
            for claim in claims
            if claim.supported_intent == intent_name
        ]
        for intent_name in admissible_intents
    }
    request = {
        "contract_schema_version": "3.0",
        "deliberation_round": int(round_index),
        "task": (
            "Resolve multi-objective reservoir scheduling claims into a structured "
            "self-delimiting semantic contract. Do not output reservoir releases. "
            "Every intent, skill, evidence key, conflict resolution, and validity "
            "feature must come from admissible_choices. The contract must state why it "
            "is valid now and which observed features should trigger reconsideration. "
            "If certificate_feedback is present, revise only semantic priorities, "
            "budget multipliers, risk posture, and validity profile in response to "
            "the physical certificate; never override physical constraints."
        ),
        "state": {
            "date": env.current_date,
            "causal_primary_intent": intent.primary_intent,
            "causal_scores": intent.scores,
            "pressures": intent.pressures,
            "obligations": intent.obligations,
            "total_storage_acft": sum(env.storage_acft.values()),
            "total_capacity_acft": sum(spec.storage_max_acft for spec in env.reservoir_specs.values()),
        },
        "skill_claims": [
            {
                "skill_name": claim.skill_name,
                "supported_intent": claim.supported_intent,
                "priority": claim.priority,
                "confidence": claim.confidence,
                "support_budget_cfs": claim.support_budget_cfs,
                "buffer_budget_cfs": claim.buffer_budget_cfs,
                "reserve_delta_acft": claim.reserve_delta_acft,
                "risk_delta": claim.risk_delta,
                "evidence": claim.evidence,
                "rationale": claim.rationale,
            }
            for claim in claims
        ],
        "conflicts": [
            {
                "source_skill": conflict.source_skill,
                "target_skill": conflict.target_skill,
                "conflict_type": conflict.conflict_type,
                "severity": conflict.severity,
                "evidence": conflict.evidence,
            }
            for conflict in conflicts
        ],
        "admissible_choices": {
            "skills": [claim.skill_name for claim in claims],
            "intents": admissible_intents,
            "intent_support_map": intent_support_map,
            "evidence_keys_by_skill": {
                claim.skill_name: sorted(claim.evidence)
                for claim in claims
            },
            "semantic_watch_features": list(SEMANTIC_FEATURE_NAMES),
            "conflict_resolutions": [
                "favor_source",
                "favor_target",
                "bounded_compromise",
                "defer_to_physical_certificate",
            ],
            "decision_stages": [
                "diagnosis",
                "conflict_resolution",
                "policy_translation",
            ],
            "feedback_adaptations": [
                "increase_service_support",
                "increase_reserve_protection",
                "bounded_compromise_after_certificate",
                "keep_contract_unchanged_with_reason",
            ],
            "safety_review_modes": [
                "bidirectional",
                "service_sensitive",
                "reserve_sensitive",
            ],
        },
        "hard_rules": [
            "dominant_intent must be in admissible intents and supported by an active skill",
            "auxiliary_intents, rejected_intents, and priority_order may contain only admissible intents",
            "cited skills must be active skills",
            "evidence citations may use only evidence keys belonging to the cited skill",
            "conflict resolutions may reference only supplied directed conflict edges",
            "decision_steps must contain diagnosis, conflict_resolution, and policy_translation in that order",
            "watch_features must contain 3 to 6 admissible semantic features",
            "do not include candidate intents that are absent from admissible_choices",
            "certificate_feedback is advisory evidence for revising the contract, not permission to output releases",
        ],
        "output_schema": {
            "contract_schema_version": "exactly 3.0",
            "dominant_intent": "one intent supported by an active skill",
            "auxiliary_intents": ["zero or more supplied intents"],
            "rejected_intents": ["zero or more supplied intents"],
            "priority_order": ["ordered supplied intents"],
            "active_skills": ["one or more supplied skill names"],
            "evidence_citations": [
                {
                    "skill_name": "one active supplied skill",
                    "evidence_keys": ["one or more evidence keys owned by that skill"],
                }
            ],
            "conflict_resolutions": [
                {
                    "source_skill": "source of one supplied directed conflict",
                    "target_skill": "target of the same conflict",
                    "resolution": "one admissible conflict resolution",
                    "controlling_skill": "source_skill or target_skill",
                }
            ],
            "decision_steps": [
                {
                    "stage": "diagnosis | conflict_resolution | policy_translation",
                    "conclusion": "concise evidence-bound conclusion",
                    "cited_skills": ["active supplied skills supporting this step"],
                }
            ],
            "risk_posture": "conservative | balanced | service_oriented",
            "support_budget_multiplier": "number in [0.75, 1.30]",
            "buffer_budget_multiplier": "number in [0.70, 1.50]",
            "reserve_floor_delta_acft": "number in [0, sum of proposed reserve deltas]",
            "risk_aversion_delta": "number in [0, 0.35]",
            "validity_profile": {
                "watch_features": ["3 to 6 admissible semantic features"],
                "novelty_tolerance": "number in [0.08, 0.20]",
                "max_age_days": "integer in [7, 14]",
                "safety_review_mode": "one admissible safety review mode",
            },
            "reasoning_summary": "concise evidence-bound decision trace",
        },
    }
    if certificate_feedback is not None:
        request["certificate_feedback"] = sanitize_certificate_feedback(certificate_feedback)
    return request


def sanitize_certificate_feedback(feedback: dict[str, Any]) -> dict[str, Any]:
    allowed_keys = {
        "previous_round_index",
        "next_round_index",
        "requery_reasons",
        "selected_action",
        "mpc_shortage_after_cfs",
        "anchor_shortage_after_cfs",
        "raw_anchor_shortage_after_cfs",
        "selected_shortage_after_cfs",
        "service_gap_cfs",
        "service_regret_cfs",
        "reserve_violation_acft",
        "reserve_borrowing_acft",
        "selected_next_storage_acft",
        "hard_reserve_floor_acft",
        "viability_floor_acft",
        "maximum_reachable_storage_acft",
        "service_ledger_after",
        "reserve_ledger_after",
        "service_dual_weight",
        "reserve_dual_weight",
        "override_margin",
        "prior_contract_hash",
        "prior_dominant_intent",
        "prior_support_multiplier",
        "prior_buffer_multiplier",
        "prior_reserve_delta_acft",
        "instruction",
    }
    sanitized: dict[str, Any] = {}
    for key in allowed_keys:
        if key in feedback:
            value = feedback[key]
            if isinstance(value, (list, tuple)):
                sanitized[key] = [str(item) for item in value]
            elif isinstance(value, (int, float, str, bool)) or value is None:
                sanitized[key] = value
            else:
                sanitized[key] = str(value)
    return sanitized


def validate_llm_deliberation(
    payload: dict[str, Any],
    intent: CausalIntent,
    claims: list[SkillClaim],
    conflicts: list[ConflictEdge],
    backend_name: str,
) -> SkillDeliberationResult:
    if not isinstance(payload, dict):
        raise TypeError("LLM deliberation response must be an object.")
    required_fields = {
        "contract_schema_version",
        "dominant_intent",
        "auxiliary_intents",
        "rejected_intents",
        "priority_order",
        "active_skills",
        "evidence_citations",
        "conflict_resolutions",
        "decision_steps",
        "risk_posture",
        "support_budget_multiplier",
        "buffer_budget_multiplier",
        "reserve_floor_delta_acft",
        "risk_aversion_delta",
        "validity_profile",
        "reasoning_summary",
    }
    missing_fields = sorted(required_fields - set(payload))
    unknown_fields = sorted(set(payload) - required_fields)
    if missing_fields:
        raise ValueError(f"LLM contract is missing required fields: {missing_fields}")
    if unknown_fields:
        raise ValueError(f"LLM contract contains unauthorized fields: {unknown_fields}")
    schema_version = str(payload["contract_schema_version"])
    if schema_version != "3.0":
        raise ValueError("Unsupported LLM contract schema version.")
    claim_by_skill = {claim.skill_name: claim for claim in claims}
    allowed_skills = set(claim_by_skill)
    allowed_intents = {claim.supported_intent for claim in claims} | {intent.primary_intent}
    active_skills = tuple(unique_strings(payload["active_skills"]))
    dominant = str(payload["dominant_intent"])
    auxiliary = tuple(unique_strings(payload.get("auxiliary_intents", [])))
    rejected = tuple(unique_strings(payload.get("rejected_intents", [])))
    priority_order = tuple(unique_strings(payload.get("priority_order", [])))
    risk_posture = str(payload["risk_posture"])
    reasoning = str(payload["reasoning_summary"]).strip()

    if not active_skills or not set(active_skills) <= allowed_skills:
        raise ValueError("Active skills must be a non-empty subset of supplied claims.")
    if dominant not in allowed_intents:
        raise ValueError("Dominant intent is not supported by supplied evidence.")
    if not any(claim_by_skill[name].supported_intent == dominant for name in active_skills):
        raise ValueError("Dominant intent must be supported by an active skill.")
    if not set(auxiliary) <= allowed_intents or not set(rejected) <= allowed_intents:
        raise ValueError("Auxiliary and rejected intents must be supplied intents.")
    if priority_order and not set(priority_order) <= allowed_intents:
        raise ValueError("Priority order contains an unsupported intent.")
    if risk_posture not in {"conservative", "balanced", "service_oriented"}:
        raise ValueError("Invalid risk posture.")
    if not reasoning:
        raise ValueError("Reasoning summary is required.")

    evidence_citations = parse_evidence_citations(
        payload["evidence_citations"],
        claim_by_skill,
        set(active_skills),
    )
    cited_skills = tuple(citation.skill_name for citation in evidence_citations)
    if not any(
        claim_by_skill[name].supported_intent == dominant
        for name in cited_skills
    ):
        raise ValueError("Dominant intent must be justified by an evidence citation.")
    conflict_resolutions = parse_conflict_resolutions(
        payload["conflict_resolutions"],
        conflicts,
    )
    decision_steps = parse_decision_steps(
        payload["decision_steps"],
        set(active_skills),
    )
    validity_profile = payload["validity_profile"]
    if not isinstance(validity_profile, dict):
        raise TypeError("validity_profile must be an object.")
    watch_features = tuple(unique_strings(validity_profile["watch_features"]))
    if not 3 <= len(watch_features) <= 6:
        raise ValueError("validity_profile.watch_features must contain 3 to 6 features.")
    if not set(watch_features) <= set(SEMANTIC_FEATURE_NAMES):
        raise ValueError("validity_profile contains an unsupported watch feature.")
    validity_radius = clamp(float(validity_profile["novelty_tolerance"]), 0.08, 0.20)
    requested_max_age_days = int(validity_profile["max_age_days"])
    if not 7 <= requested_max_age_days <= 14:
        raise ValueError("validity_profile.max_age_days must be in [7, 14].")
    safety_review_mode = str(validity_profile["safety_review_mode"])
    if safety_review_mode not in {
        "bidirectional",
        "service_sensitive",
        "reserve_sensitive",
    }:
        raise ValueError("Invalid validity_profile.safety_review_mode.")

    max_reserve = max(0.0, sum(claim.reserve_delta_acft for claim in claims))
    support_multiplier = clamp(float(payload["support_budget_multiplier"]), 0.75, 1.30)
    buffer_multiplier = clamp(float(payload["buffer_budget_multiplier"]), 0.70, 1.50)
    reserve_delta = clamp(float(payload["reserve_floor_delta_acft"]), 0.0, max_reserve)
    risk_delta = clamp(float(payload["risk_aversion_delta"]), 0.0, 0.35)
    evidence_bound = all(bool(claim_by_skill[name].evidence) for name in cited_skills)
    if not evidence_bound:
        raise ValueError("Cited skills must contain numeric evidence.")

    return SkillDeliberationResult(
        active_skills=active_skills,
        dominant_intent=dominant,
        auxiliary_intents=auxiliary,
        rejected_intents=rejected,
        priority_order=priority_order or (dominant,),
        risk_posture=risk_posture,
        support_budget_multiplier=support_multiplier,
        buffer_budget_multiplier=buffer_multiplier,
        reserve_floor_delta_acft=reserve_delta,
        risk_aversion_delta=risk_delta,
        claims=tuple(claims),
        conflicts=tuple(conflicts),
        backend_name=backend_name,
        schema_valid=True,
        evidence_bound=True,
        deliberation_trace=f"cited={','.join(cited_skills)} | {reasoning}",
        contract_schema_version=schema_version,
        evidence_citations=evidence_citations,
        conflict_resolutions=conflict_resolutions,
        decision_steps=decision_steps,
        watch_features=watch_features,
        validity_radius=validity_radius,
        requested_max_age_days=requested_max_age_days,
        safety_review_mode=safety_review_mode,
    )


def parse_evidence_citations(
    raw: Any,
    claim_by_skill: dict[str, SkillClaim],
    active_skills: set[str],
) -> tuple[EvidenceCitation, ...]:
    if not isinstance(raw, list) or not raw:
        raise ValueError("evidence_citations must be a non-empty list.")
    citations: list[EvidenceCitation] = []
    for item in raw:
        if not isinstance(item, dict):
            raise TypeError("Each evidence citation must be an object.")
        skill_name = str(item["skill_name"])
        evidence_keys = tuple(unique_strings(item["evidence_keys"]))
        if skill_name not in active_skills:
            raise ValueError("Evidence citations may reference only active skills.")
        if not evidence_keys:
            raise ValueError("Each evidence citation requires at least one evidence key.")
        if not set(evidence_keys) <= set(claim_by_skill[skill_name].evidence):
            raise ValueError("Evidence citation contains a key not owned by the skill.")
        citations.append(EvidenceCitation(skill_name, evidence_keys))
    return tuple(citations)


def parse_conflict_resolutions(
    raw: Any,
    conflicts: list[ConflictEdge],
) -> tuple[ConflictResolution, ...]:
    if not isinstance(raw, list):
        raise TypeError("conflict_resolutions must be a list.")
    allowed_edges = {
        (conflict.source_skill, conflict.target_skill)
        for conflict in conflicts
    }
    allowed_modes = {
        "favor_source",
        "favor_target",
        "bounded_compromise",
        "defer_to_physical_certificate",
    }
    resolutions: list[ConflictResolution] = []
    for item in raw:
        if not isinstance(item, dict):
            raise TypeError("Each conflict resolution must be an object.")
        source = str(item["source_skill"])
        target = str(item["target_skill"])
        resolution = str(item["resolution"])
        controlling = str(item["controlling_skill"])
        if (source, target) not in allowed_edges:
            raise ValueError("Conflict resolution references an unsupplied edge.")
        if resolution not in allowed_modes:
            raise ValueError("Invalid conflict resolution mode.")
        if controlling not in {source, target}:
            raise ValueError("controlling_skill must be a member of the conflict edge.")
        resolutions.append(
            ConflictResolution(source, target, resolution, controlling)
        )
    if conflicts and not resolutions:
        raise ValueError("At least one supplied conflict must be explicitly resolved.")
    return tuple(resolutions)


def parse_decision_steps(
    raw: Any,
    active_skills: set[str],
) -> tuple[DecisionStep, ...]:
    if not isinstance(raw, list):
        raise TypeError("decision_steps must be a list.")
    required_stages = [
        "diagnosis",
        "conflict_resolution",
        "policy_translation",
    ]
    if [str(item.get("stage", "")) for item in raw if isinstance(item, dict)] != required_stages:
        raise ValueError("decision_steps must contain the three required stages in order.")
    steps: list[DecisionStep] = []
    for item in raw:
        if not isinstance(item, dict):
            raise TypeError("Each decision step must be an object.")
        conclusion = str(item["conclusion"]).strip()
        cited_skills = tuple(unique_strings(item["cited_skills"]))
        if not conclusion:
            raise ValueError("Each decision step requires a conclusion.")
        if not cited_skills or not set(cited_skills) <= active_skills:
            raise ValueError("Decision-step citations must be active supplied skills.")
        steps.append(
            DecisionStep(
                stage=str(item["stage"]),
                conclusion=conclusion,
                cited_skills=cited_skills,
            )
        )
    return tuple(steps)


def project_llm_deliberation_payload(
    payload: dict[str, Any],
    intent: CausalIntent,
    claims: list[SkillClaim],
    conflicts: list[ConflictEdge],
) -> tuple[dict[str, Any], list[str]]:
    """Minimally project non-authoritative categorical fields into their evidence set.

    The dominant intent remains strict: unsupported dominant decisions are
    rejected. Projection may only remove unsupported auxiliary metadata or add
    the supplied evidence skill required to support the dominant intent.
    """

    if not isinstance(payload, dict):
        raise TypeError("LLM deliberation response must be an object.")
    projected = dict(payload)
    claim_by_skill = {claim.skill_name: claim for claim in claims}
    allowed_skills = set(claim_by_skill)
    allowed_intents = {claim.supported_intent for claim in claims} | {intent.primary_intent}
    dominant = str(payload["dominant_intent"])
    if dominant not in allowed_intents:
        raise ValueError("Dominant intent is not supported by supplied evidence.")

    repairs: list[str] = []
    active = [name for name in unique_strings(payload["active_skills"]) if name in allowed_skills]
    if active != unique_strings(payload["active_skills"]):
        repairs.append("drop_unsupported_active_skills")
    if not any(claim_by_skill[name].supported_intent == dominant for name in active):
        supporting = [
            claim.skill_name
            for claim in claims
            if claim.supported_intent == dominant
        ]
        if not supporting:
            raise ValueError("Dominant intent has no supplied supporting skill.")
        active.append(supporting[0])
        repairs.append("activate_dominant_support_skill")
    projected["active_skills"] = active

    raw_citations = payload["evidence_citations"]
    if not isinstance(raw_citations, list):
        raise TypeError("evidence_citations must be a list.")
    citations: list[dict[str, Any]] = []
    for citation in raw_citations:
        if not isinstance(citation, dict):
            continue
        skill_name = str(citation.get("skill_name", ""))
        if skill_name not in set(active):
            repairs.append("drop_nonactive_citations")
            continue
        original_keys = unique_strings(citation.get("evidence_keys", []))
        allowed_keys = set(claim_by_skill[skill_name].evidence)
        evidence_keys = [key for key in original_keys if key in allowed_keys]
        if evidence_keys != original_keys:
            repairs.append("drop_unsupported_evidence_keys")
        if evidence_keys:
            citations.append(
                {
                    "skill_name": skill_name,
                    "evidence_keys": evidence_keys,
                }
            )
    if not citations:
        raise ValueError("No admissible evidence citation remains after projection.")
    projected["evidence_citations"] = citations

    for field in ("auxiliary_intents", "rejected_intents", "priority_order"):
        original = unique_strings(payload.get(field, []))
        filtered = [name for name in original if name in allowed_intents]
        if filtered != original:
            repairs.append(f"drop_unsupported_{field}")
        projected[field] = filtered

    supplied_edges = {
        (conflict.source_skill, conflict.target_skill)
        for conflict in conflicts
    }
    allowed_resolutions = {
        "favor_source",
        "favor_target",
        "bounded_compromise",
        "defer_to_physical_certificate",
    }
    projected_resolutions: list[dict[str, Any]] = []
    raw_resolutions = payload["conflict_resolutions"]
    if not isinstance(raw_resolutions, list):
        raise TypeError("conflict_resolutions must be a list.")
    for resolution in raw_resolutions:
        if not isinstance(resolution, dict):
            continue
        source = str(resolution.get("source_skill", ""))
        target = str(resolution.get("target_skill", ""))
        mode = str(resolution.get("resolution", ""))
        controlling = str(resolution.get("controlling_skill", ""))
        if (
            (source, target) not in supplied_edges
            or mode not in allowed_resolutions
            or controlling not in {source, target}
        ):
            repairs.append("drop_invalid_conflict_resolutions")
            continue
        projected_resolutions.append(dict(resolution))
    projected["conflict_resolutions"] = projected_resolutions

    profile = payload["validity_profile"]
    if not isinstance(profile, dict):
        raise TypeError("validity_profile must be an object.")
    original_watch = unique_strings(profile["watch_features"])
    filtered_watch = [
        feature
        for feature in original_watch
        if feature in SEMANTIC_FEATURE_NAMES
    ]
    if filtered_watch != original_watch:
        repairs.append("drop_unsupported_watch_features")
    projected["validity_profile"] = {
        **profile,
        "watch_features": filtered_watch,
    }

    if not repairs:
        raise ValueError("Contract is invalid and no admissible minimal projection was found.")
    return projected, repairs


def unique_strings(values: Any) -> list[str]:
    if not isinstance(values, (list, tuple)):
        raise TypeError("Expected a list of strings.")
    result: list[str] = []
    for value in values:
        text = str(value)
        if text not in result:
            result.append(text)
    return result


def deterministic_conflict_resolutions(
    conflicts: list[ConflictEdge],
    effective_weight: dict[str, float],
) -> tuple[ConflictResolution, ...]:
    resolutions: list[ConflictResolution] = []
    for conflict in conflicts:
        source_weight = effective_weight.get(conflict.source_skill, 0.0)
        target_weight = effective_weight.get(conflict.target_skill, 0.0)
        difference = source_weight - target_weight
        if abs(difference) <= 0.10:
            mode = "bounded_compromise"
        elif difference > 0.0:
            mode = "favor_source"
        else:
            mode = "favor_target"
        controlling = (
            conflict.source_skill
            if difference >= 0.0
            else conflict.target_skill
        )
        resolutions.append(
            ConflictResolution(
                source_skill=conflict.source_skill,
                target_skill=conflict.target_skill,
                resolution=mode,
                controlling_skill=controlling,
            )
        )
    return tuple(resolutions)


def deterministic_validity_profile(
    dominant_intent: str,
    conflicts: list[ConflictEdge],
    intent: CausalIntent,
) -> tuple[tuple[str, ...], float, int, str]:
    feature_map = {
        "support_downstream_demands": (
            "forecast_shortage",
            "demand_pressure",
            "storage_ratio",
            "release_claim_share",
        ),
        "support_ecology": (
            "ecology_pressure",
            "forecast_shortage",
            "storage_ratio",
            "release_claim_share",
        ),
        "pre_release_buffer": (
            "target_encroachment",
            "high_flow_pressure",
            "storage_ratio",
            "uncertainty_pressure",
        ),
        "conserve_storage": (
            "storage_ratio",
            "target_surplus",
            "drought_pressure",
            "uncertainty_pressure",
            "conservation_claim_share",
        ),
        "recover_targets": (
            "storage_ratio",
            "target_surplus",
            "forecast_shortage",
            "conservation_claim_share",
        ),
        "balanced": (
            "storage_ratio",
            "forecast_shortage",
            "ecology_pressure",
            "uncertainty_pressure",
        ),
    }
    mean_conflict = mean(conflict.severity for conflict in conflicts) if conflicts else 0.0
    uncertainty = bounded_pressure(
        intent.pressures.get("forecast_uncertainty_pressure", 0.0)
    )
    radius = clamp(0.18 - 0.06 * mean_conflict - 0.04 * uncertainty, 0.08, 0.18)
    max_age_days = 7 if max(mean_conflict, uncertainty) >= 0.45 else 14
    if dominant_intent in {"conserve_storage", "recover_targets"}:
        review_mode = "service_sensitive"
    elif dominant_intent in {
        "support_downstream_demands",
        "support_ecology",
        "pre_release_buffer",
    }:
        review_mode = "reserve_sensitive"
    else:
        review_mode = "bidirectional"
    return (
        feature_map.get(dominant_intent, feature_map["balanced"]),
        radius,
        max_age_days,
        review_mode,
    )


def semantic_state_snapshot(
    context: SkillContext,
    claims: list[SkillClaim],
    conflicts: list[ConflictEdge],
) -> SemanticStateSnapshot:
    """Map heterogeneous hydrologic evidence into a bounded semantic state."""

    pressures = context.intent.pressures
    claim_weights = {
        claim.skill_name: max(0.0, claim.priority * claim.confidence)
        for claim in claims
    }
    total_claim_weight = sum(claim_weights.values())
    release_intents = {"support_downstream_demands", "support_ecology", "pre_release_buffer"}
    conservation_intents = {"conserve_storage", "recover_targets"}
    release_drive = sum(
        claim_weights[claim.skill_name]
        for claim in claims
        if claim.supported_intent in release_intents
    )
    conservation_drive = sum(
        claim_weights[claim.skill_name]
        for claim in claims
        if claim.supported_intent in conservation_intents
    )
    mean_conflict = mean(conflict.severity for conflict in conflicts) if conflicts else 0.0
    dominant_claim = max(
        claims,
        key=lambda claim: claim_weights[claim.skill_name],
        default=None,
    )
    features = {
        "storage_ratio": clamp(context.storage_ratio, 0.0, 1.0),
        "target_surplus": clamp(
            (float(pressures.get("target_surplus_ratio", 0.0)) + 0.15) / 0.45,
            0.0,
            1.0,
        ),
        "target_encroachment": clamp(
            (float(pressures.get("target_encroachment_ratio", 0.0)) + 0.10) / 0.30,
            0.0,
            1.0,
        ),
        "demand_pressure": bounded_pressure(pressures.get("current_demand_pressure", 0.0)),
        "forecast_shortage": bounded_pressure(pressures.get("forecast_shortage_pressure", 0.0)),
        "ecology_pressure": bounded_pressure(pressures.get("ecology_pressure", 0.0)),
        "drought_pressure": bounded_pressure(pressures.get("drought_pressure", 0.0)),
        "uncertainty_pressure": bounded_pressure(
            pressures.get("forecast_uncertainty_pressure", 0.0)
        ),
        "high_flow_pressure": bounded_pressure(pressures.get("high_flow_pressure", 0.0)),
        "max_claim_priority": max((claim.priority for claim in claims), default=0.0),
        "release_claim_share": safe_divide(release_drive, total_claim_weight),
        "conservation_claim_share": safe_divide(conservation_drive, total_claim_weight),
    }
    active_skills = tuple(sorted(claim.skill_name for claim in claims))
    dominant_claim_intent = (
        dominant_claim.supported_intent
        if dominant_claim is not None
        else context.intent.primary_intent
    )
    hash_payload = {
        "causal_intent": context.intent.primary_intent,
        "features": {key: round(value, 6) for key, value in sorted(features.items())},
        "active_skills": active_skills,
        "dominant_claim_intent": dominant_claim_intent,
        "mean_conflict_severity": round(mean_conflict, 6),
    }
    encoded = json.dumps(
        hash_payload,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    )
    return SemanticStateSnapshot(
        date=context.date,
        causal_intent=context.intent.primary_intent,
        features=features,
        active_skills=active_skills,
        dominant_claim_intent=dominant_claim_intent,
        mean_conflict_severity=mean_conflict,
        state_hash=hashlib.sha256(encoded.encode("utf-8")).hexdigest(),
    )


def semantic_state_distance(
    current: SemanticStateSnapshot,
    reference: SemanticStateSnapshot,
    watch_features: tuple[str, ...] = (),
) -> float:
    """Weighted bounded distance defining the semantic contract validity region."""

    feature_weights = {
        "storage_ratio": 0.14,
        "target_surplus": 0.12,
        "target_encroachment": 0.10,
        "demand_pressure": 0.10,
        "forecast_shortage": 0.12,
        "ecology_pressure": 0.08,
        "drought_pressure": 0.08,
        "uncertainty_pressure": 0.06,
        "high_flow_pressure": 0.06,
        "max_claim_priority": 0.05,
        "release_claim_share": 0.05,
        "conservation_claim_share": 0.04,
    }
    selected = [
        name
        for name in watch_features
        if name in feature_weights
    ] or list(feature_weights)
    selected_weight = sum(feature_weights[name] for name in selected)
    feature_distance = sum(
        safe_divide(feature_weights[name], selected_weight)
        * abs(current.features.get(name, 0.0) - reference.features.get(name, 0.0))
        for name in selected
    )
    current_skills = set(current.active_skills)
    reference_skills = set(reference.active_skills)
    skill_union = current_skills | reference_skills
    skill_distance = (
        1.0 - safe_divide(len(current_skills & reference_skills), len(skill_union))
        if skill_union
        else 0.0
    )
    causal_distance = float(current.causal_intent != reference.causal_intent)
    dominant_distance = float(
        current.dominant_claim_intent != reference.dominant_claim_intent
    )
    conflict_distance = abs(
        current.mean_conflict_severity - reference.mean_conflict_severity
    )
    return clamp(
        0.66 * feature_distance
        + 0.12 * skill_distance
        + 0.10 * causal_distance
        + 0.07 * dominant_distance
        + 0.05 * conflict_distance,
        0.0,
        1.0,
    )


def bounded_pressure(value: float | str, scale: float = 1.0) -> float:
    numeric = max(0.0, float(value))
    return safe_divide(numeric, numeric + max(scale, 1e-9))


def base_backend_name(name: str) -> str:
    suffix = ":reused"
    result = name
    while result.endswith(suffix):
        result = result[: -len(suffix)]
    return result


def pairwise_conflict(source: SkillClaim, target: SkillClaim) -> ConflictEdge | None:
    release_intents = {"support_downstream_demands", "support_ecology", "pre_release_buffer"}
    conservation_intents = {"conserve_storage", "recover_targets"}
    if source.supported_intent in release_intents and target.supported_intent in conservation_intents:
        severity = clamp(
            0.55 * source.priority
            + 0.45 * target.priority
            + safe_divide(source.support_budget_cfs + source.buffer_budget_cfs, 4000.0),
            0.0,
            1.0,
        )
        return ConflictEdge(
            source_skill=source.skill_name,
            target_skill=target.skill_name,
            conflict_type="release_vs_storage_security",
            severity=severity,
            evidence={
                "source_support_cfs": source.support_budget_cfs,
                "source_buffer_cfs": source.buffer_budget_cfs,
                "target_reserve_delta_acft": target.reserve_delta_acft,
            },
        )
    if source.supported_intent == "pre_release_buffer" and target.supported_intent == "support_ecology":
        severity = clamp(0.35 * source.priority + 0.25 * target.priority, 0.0, 1.0)
        return ConflictEdge(
            source_skill=source.skill_name,
            target_skill=target.skill_name,
            conflict_type="timing_buffer_vs_ecology",
            severity=severity,
            evidence={
                "buffer_budget_cfs": source.buffer_budget_cfs,
                "ecology_support_cfs": target.support_budget_cfs,
            },
        )
    return None


def summarize_claims(claims: tuple[SkillClaim, ...]) -> dict[str, float]:
    if not claims:
        return {
            "claim_count": 0.0,
            "mean_priority": 0.0,
            "max_priority": 0.0,
            "mean_confidence": 0.0,
            "total_support_budget_cfs": 0.0,
            "total_reserve_delta_acft": 0.0,
        }
    return {
        "claim_count": float(len(claims)),
        "mean_priority": mean(claim.priority for claim in claims),
        "max_priority": max(claim.priority for claim in claims),
        "mean_confidence": mean(claim.confidence for claim in claims),
        "total_support_budget_cfs": sum(claim.support_budget_cfs for claim in claims),
        "total_reserve_delta_acft": sum(claim.reserve_delta_acft for claim in claims),
    }
