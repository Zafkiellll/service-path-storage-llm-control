from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, replace
from statistics import mean
from typing import Any

from .causal_intent_agent import CausalIntent, ForecastCausalIntentAgent
from .daily_environment import CFS_DAY_TO_ACFT, DailyReservoirEnvironment, ReservoirSpec, clamp, safe_divide
from .forecasting import EnsembleForecast, ForecastMember, SeasonalAnalogEnsembleForecaster, percentile
from .skill_deliberation import (
    MultiSkillDeliberationLayer,
    SkillDeliberationResult,
    summarize_claims,
    unique_strings,
)


@dataclass(frozen=True)
class PolicyCandidate:
    candidate_id: str
    target_tracking_weight: float
    support_weight: float
    buffer_weight: float
    conservation_weight: float
    smoothness_weight: float


@dataclass(frozen=True)
class CandidateEvaluation:
    candidate: PolicyCandidate
    mean_cost: float
    cvar_cost: float
    worst_cost: float
    robust_cost: float
    mean_shortage_cfs: float
    mean_terminal_deficit_acft: float
    mean_release_cfs: float


@dataclass(frozen=True)
class MpcDecision:
    intent: CausalIntent
    releases_cfs: dict[str, float]
    forecast: EnsembleForecast
    diagnostics: dict[str, Any]


@dataclass
class OnlineSafetyLedger:
    """Virtual queues for balancing service regret and reserve violations."""

    service_regret_cfs_days: float = 0.0
    reserve_debt_acft: float = 0.0
    last_reserve_violation_acft: float = 0.0
    service_override_days: int = 0


@dataclass
class PathViabilityAccount:
    """Causal memory of unresolved net demand on one controlled service path."""

    cumulative_net_deficit_acft: float = 0.0
    ewma_net_deficit_acft: float = 0.0
    observations: int = 0


@dataclass
class HydrologicRegretAccount:
    """Regime-local account for semantic admission against a shadow MPC."""

    observations: int = 0
    semantic_selected_days: int = 0
    shadow_selected_days: int = 0
    score_debt: float = 0.0
    score_credit: float = 0.0
    service_debt_cfs: float = 0.0
    reserve_debt_acft: float = 0.0


DEFAULT_SUPPLY_GUARANTEE_PRIORITY: dict[str, tuple[str, ...]] = {
    "3604684": ("3604512", "3603575", "3603570"),
    "5104700": ("5104055", "5103695", "5103710", "5103686"),
}


def unique_round_reasons(round_records: list[dict[str, Any]]) -> list[str]:
    reasons: list[str] = []
    for record in round_records:
        for reason in record.get("requery_reasons", []):
            if str(reason):
                reasons.append(str(reason))
    return unique_strings(reasons)


@dataclass(frozen=True)
class StrategicIntentProposal:
    primary_intent: str
    requested_support_cfs: float
    requested_buffer_cfs: float
    reserve_floor_acft: float
    hard_safety_floor_acft: float
    risk_aversion: float
    service_tolerance_cfs: float
    evidence: dict[str, float | str]


@dataclass(frozen=True)
class PhysicalFeasibilityCertificate:
    requested_support_cfs: float
    feasible_release_cfs: float
    effective_support_cfs: float
    routed_service_gain_cfs: float
    support_gap_cfs: float
    active_reservoir_count: int
    marginal_service_efficiency: float
    limiting_factor: str


@dataclass(frozen=True)
class NegotiationRound:
    round_index: int
    proposal: StrategicIntentProposal
    certificate: PhysicalFeasibilityCertificate
    status: str


@dataclass(frozen=True)
class NegotiationResult:
    initial_proposal: StrategicIntentProposal
    final_proposal: StrategicIntentProposal
    final_certificate: PhysicalFeasibilityCertificate
    rounds: tuple[NegotiationRound, ...]
    status: str

    @property
    def support_acceptance_ratio(self) -> float:
        return safe_divide(
            self.final_proposal.requested_support_cfs,
            self.initial_proposal.requested_support_cfs,
        )


class BilevelIntentNegotiator:
    """Upper-lower intent negotiation for realtime reservoir scheduling.

    The upper layer translates causal intent into a basin-level strategic
    budget. The lower layer answers with a physical feasibility certificate
    derived from current storage, release constraints, and exact topology
    routing. The final proposal is the negotiated intent budget consumed by
    robust MPC.
    """

    def __init__(self, max_rounds: int = 3, feasibility_tolerance_fraction: float = 0.04) -> None:
        self.max_rounds = max(1, max_rounds)
        self.feasibility_tolerance_fraction = feasibility_tolerance_fraction
        self._influence_cache: dict[int, dict[str, float]] = {}

    def negotiate(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast_summary: dict[str, float],
        reservoir_inflow: dict[str, dict[str, float]],
        horizon_days: int,
        deliberation: SkillDeliberationResult | None = None,
    ) -> NegotiationResult:
        proposal = self.strategic_proposal(env, intent, forecast_summary, reservoir_inflow, horizon_days, deliberation)
        initial = proposal
        rounds: list[NegotiationRound] = []
        status = "accepted"

        for round_index in range(1, self.max_rounds + 1):
            certificate = self.physical_certificate(env, proposal)
            tolerance = max(
                proposal.service_tolerance_cfs,
                self.feasibility_tolerance_fraction * max(proposal.requested_support_cfs, 1.0),
            )
            feasible = certificate.support_gap_cfs <= tolerance
            status = "accepted" if feasible else "revised"
            rounds.append(NegotiationRound(round_index, proposal, certificate, status))
            if feasible or proposal.requested_support_cfs <= 0.0:
                break
            proposal = self.revise_proposal(proposal, certificate, round_index)
        else:
            status = "bounded_by_physics"

        final_round = rounds[-1]
        if final_round.certificate.support_gap_cfs > max(
            final_round.proposal.service_tolerance_cfs,
            self.feasibility_tolerance_fraction * max(final_round.proposal.requested_support_cfs, 1.0),
        ):
            status = "bounded_by_physics"

        return NegotiationResult(
            initial_proposal=initial,
            final_proposal=final_round.proposal,
            final_certificate=final_round.certificate,
            rounds=tuple(rounds),
            status=status,
        )

    def strategic_proposal(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast_summary: dict[str, float],
        reservoir_inflow: dict[str, dict[str, float]],
        horizon_days: int,
        deliberation: SkillDeliberationResult | None = None,
    ) -> StrategicIntentProposal:
        horizon = max(1, horizon_days)
        no_release = env.route(env.current_date, {})
        total_capacity = sum(spec.storage_max_acft for spec in env.reservoir_specs.values())
        total_storage = sum(env.storage_acft.values())
        target_min = sum(env.target_min(env.current_date, reservoir_id) for reservoir_id in env.reservoir_ids)
        p90_inflow_acft = sum(item["p90_cfs_day"] for item in reservoir_inflow.values()) * CFS_DAY_TO_ACFT
        target_max = sum(env.target_max(env.current_date, reservoir_id) for reservoir_id in env.reservoir_ids)
        current_shortage = no_release["total_shortage_before_release_cfs"]
        current_ecology = no_release["instream_shortage_before_release_cfs"]
        forecast_shortage = forecast_summary.get("p90_shortage_pressure_cfs", 0.0)
        mean_shortage = forecast_summary.get("mean_shortage_pressure_cfs", 0.0)
        primary = deliberation.dominant_intent if deliberation is not None else intent.primary_intent

        if primary == "support_downstream_demands":
            support = max(current_shortage, 0.70 * forecast_shortage, mean_shortage)
        elif primary == "support_ecology":
            support = max(current_ecology, 0.50 * forecast_summary.get("mean_instream_demand_cfs", 0.0))
        elif primary == "balanced":
            support = max(0.35 * current_shortage, 0.45 * mean_shortage)
        elif primary == "pre_release_buffer":
            support = 0.18 * max(current_shortage, mean_shortage)
        else:
            support = 0.10 * max(current_shortage, mean_shortage)

        buffer = max(0.0, total_storage + p90_inflow_acft - target_max) / CFS_DAY_TO_ACFT / horizon
        if primary == "pre_release_buffer":
            support = max(support, 0.50 * buffer)
        storage_deficit = max(0.0, target_min - total_storage)
        uncertainty = safe_divide(
            forecast_summary.get("stream_uncertainty_width_cfs", 0.0),
            forecast_summary.get("mean_stream_flow_cfs", 0.0) + 1.0,
        )
        drought = intent.pressures.get("drought_pressure", 0.0)
        base_reserve_fraction = {
            "support_downstream_demands": 0.55,
            "support_ecology": 0.58,
            "balanced": 0.62,
            "pre_release_buffer": 0.45,
            "conserve_storage": 0.78,
            "recover_targets": 0.82,
        }.get(primary, 0.62)
        dynamic_reserve_fraction = clamp(
            base_reserve_fraction + 0.08 * drought + 0.05 * uncertainty,
            0.42,
            0.90,
        )
        hard_base_fraction = {
            "support_downstream_demands": 0.30,
            "support_ecology": 0.32,
            "balanced": 0.38,
            "pre_release_buffer": 0.22,
            "conserve_storage": 0.50,
            "recover_targets": 0.55,
        }.get(primary, 0.38)
        hard_safety_fraction = clamp(
            hard_base_fraction + 0.04 * drought + 0.02 * uncertainty,
            0.20,
            0.70,
        )
        reserve_floor = max(
            target_min + (0.35 if primary in {"conserve_storage", "recover_targets"} else 0.12) * storage_deficit,
            dynamic_reserve_fraction * target_max,
        )
        hard_safety_floor = max(target_min, hard_safety_fraction * target_max)
        risk_aversion = clamp(0.35 + 0.45 * uncertainty + 0.30 * intent.scores.get("conserve_storage", 0.0), 0.30, 1.0)
        tolerance = 5.0 + 0.015 * max(current_shortage, support)

        if deliberation is not None:
            support *= deliberation.support_budget_multiplier
            buffer *= deliberation.buffer_budget_multiplier
            reserve_floor += deliberation.reserve_floor_delta_acft
            hard_safety_floor += 0.50 * deliberation.reserve_floor_delta_acft
            risk_aversion = clamp(risk_aversion + deliberation.risk_aversion_delta, 0.30, 1.0)
            tolerance *= 1.0 + 0.15 * min(1.0, deliberation.conflict_count / 4.0)

        return StrategicIntentProposal(
            primary_intent=primary,
            requested_support_cfs=max(0.0, support),
            requested_buffer_cfs=max(0.0, buffer),
            reserve_floor_acft=min(total_capacity, max(0.0, reserve_floor)),
            hard_safety_floor_acft=min(total_capacity, max(0.0, hard_safety_floor)),
            risk_aversion=risk_aversion,
            service_tolerance_cfs=tolerance,
            evidence={
                "current_shortage_cfs": current_shortage,
                "current_ecology_shortage_cfs": current_ecology,
                "forecast_p90_shortage_cfs": forecast_shortage,
                "forecast_mean_shortage_cfs": mean_shortage,
                "buffer_release_cfs": buffer,
                "total_storage_acft": total_storage,
                "dynamic_reserve_fraction": dynamic_reserve_fraction,
                "hard_safety_fraction": hard_safety_fraction,
                "seasonal_target_max_acft": target_max,
                "deliberation_backend": deliberation.backend_name if deliberation is not None else "",
                "deliberation_risk_posture": deliberation.risk_posture if deliberation is not None else "",
            },
        )

    def physical_certificate(
        self,
        env: DailyReservoirEnvironment,
        proposal: StrategicIntentProposal,
    ) -> PhysicalFeasibilityCertificate:
        inflows = env.estimate_reservoir_inflows_cfs(env.current_date)
        influence = self.release_influence(env)
        total_storage = sum(env.storage_acft.values())
        total_target_min = sum(env.target_min(env.current_date, reservoir_id) for reservoir_id in env.reservoir_ids)
        reserve_extra = max(0.0, proposal.hard_safety_floor_acft - total_target_min)
        total_available_above_min = 0.0
        availability: dict[str, float] = {}

        for reservoir_id, spec in env.reservoir_specs.items():
            storage = env.storage_acft.get(reservoir_id, 0.0)
            inflow_acft = inflows.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT
            target_min = env.target_min(env.current_date, reservoir_id)
            above_min = max(0.0, storage + inflow_acft - target_min)
            total_available_above_min += above_min
            availability[reservoir_id] = above_min

        release_request = {}
        active = 0
        for reservoir_id, available_acft in availability.items():
            reserve_share = reserve_extra * safe_divide(available_acft, total_available_above_min)
            available_cfs = max(0.0, available_acft - reserve_share) / CFS_DAY_TO_ACFT
            influence_weight = max(0.05, influence.get(reservoir_id, 0.0))
            release_request[reservoir_id] = available_cfs * influence_weight
            active += int(available_cfs > 0.0)

        projected = project_releases_for_storage(env, release_request, dict(env.storage_acft), inflows)
        no_release = env.route(env.current_date, {})
        routed = env.route(env.current_date, projected)
        service_gain = max(
            0.0,
            no_release["total_shortage_after_release_cfs"] - routed["total_shortage_after_release_cfs"],
        )
        release_total = sum(projected.values())
        effective_support = sum(projected.get(reservoir_id, 0.0) * influence.get(reservoir_id, 0.0) for reservoir_id in env.reservoir_ids)
        gap = max(0.0, proposal.requested_support_cfs - service_gain)
        if total_storage <= proposal.hard_safety_floor_acft and release_total <= 0.0:
            limiting = "strategic_reserve_floor"
        elif active == 0:
            limiting = "no_releasable_storage"
        elif service_gain < min(proposal.requested_support_cfs, effective_support) * 0.35:
            limiting = "topology_or_no_current_shortage"
        elif gap > 0.0:
            limiting = "release_capacity"
        else:
            limiting = "feasible"

        return PhysicalFeasibilityCertificate(
            requested_support_cfs=proposal.requested_support_cfs,
            feasible_release_cfs=release_total,
            effective_support_cfs=effective_support,
            routed_service_gain_cfs=service_gain,
            support_gap_cfs=gap,
            active_reservoir_count=active,
            marginal_service_efficiency=safe_divide(service_gain, release_total),
            limiting_factor=limiting,
        )

    def release_influence(self, env: DailyReservoirEnvironment) -> dict[str, float]:
        cache_key = id(env)
        cached = self._influence_cache.get(cache_key)
        if cached is not None:
            return cached
        influence = compute_release_influence(env)
        self._influence_cache[cache_key] = influence
        return influence

    def revise_proposal(
        self,
        proposal: StrategicIntentProposal,
        certificate: PhysicalFeasibilityCertificate,
        round_index: int,
    ) -> StrategicIntentProposal:
        accepted_support = max(
            0.0,
            certificate.routed_service_gain_cfs + proposal.service_tolerance_cfs,
        )
        blend = 0.65 if round_index == 1 else 0.85
        revised_support = (
            (1.0 - blend) * proposal.requested_support_cfs
            + blend * min(proposal.requested_support_cfs, accepted_support)
        )
        return StrategicIntentProposal(
            primary_intent=proposal.primary_intent,
            requested_support_cfs=revised_support,
            requested_buffer_cfs=proposal.requested_buffer_cfs,
            reserve_floor_acft=proposal.reserve_floor_acft,
            hard_safety_floor_acft=proposal.hard_safety_floor_acft,
            risk_aversion=min(1.0, proposal.risk_aversion + 0.08),
            service_tolerance_cfs=proposal.service_tolerance_cfs,
            evidence={**proposal.evidence, "revision_reason": certificate.limiting_factor},
        )


class ForecastCausalRobustMpcAgent:
    """Final forecast-causal-intent agent with robust rolling planning.

    The architecture is intentionally modular:

    - `SeasonalAnalogEnsembleForecaster` supplies realtime-compatible ensemble
      forecast members.
    - `ForecastCausalIntentAgent` forms a structured intent and causal
      evidence chain.
    - `MultiSkillDeliberationLayer` converts competing evidence-bound skill
      claims into a hashed semantic policy contract. A validated LLM backend
      may author this contract without directly controlling releases.
    - `BilevelIntentNegotiator` converts the semantic contract into a
      physically feasible basin budget and strategic storage floor.
    - `RobustIntentMpcPlanner` selects an intent-conditioned release policy by
      minimizing ensemble mean plus tail-risk cost over a finite horizon, then
      certifies the first-day action against the causal-intent anchor by exact
      current-day topology routing.

    The selected policy is executed in receding-horizon fashion: only the first
    certified daily release vector is applied, then intent and plan are
    recomputed on the next day.
    """

    def __init__(
        self,
        forecaster: SeasonalAnalogEnsembleForecaster,
        planner: "RobustIntentMpcPlanner | None" = None,
        causal_layer: ForecastCausalIntentAgent | None = None,
        negotiator: BilevelIntentNegotiator | None = None,
        deliberation_layer: MultiSkillDeliberationLayer | None = None,
        enable_deliberation: bool = True,
        enable_negotiation: bool = True,
        max_deliberation_rounds: int = 1,
        certificate_requery_service_regret_cfs: float = 75.0,
        certificate_requery_reserve_violation_acft: float = 50000.0,
        certificate_requery_actions: tuple[str, ...] = ("service_override",),
        redeliberation_acceptance_mode: str = "last",
        redeliberation_score_tolerance: float = 0.0,
        shadow_baseline_mode: str = "disabled",
        shadow_score_tolerance: float = 0.0,
        hydrologic_supervisor_decay: float = 0.985,
        hydrologic_supervisor_score_limit: float = 45.0,
        hydrologic_supervisor_service_limit_cfs: float = 55.0,
        hydrologic_supervisor_reserve_limit_acft: float = 60000.0,
        hydrologic_admissibility_policy: dict[str, Any] | None = None,
    ) -> None:
        self.forecaster = forecaster
        self.causal_layer = causal_layer or ForecastCausalIntentAgent(forecaster)
        self.planner = planner or RobustIntentMpcPlanner()
        self.negotiator = negotiator or BilevelIntentNegotiator()
        self.deliberation_layer = deliberation_layer or MultiSkillDeliberationLayer()
        self.enable_deliberation = enable_deliberation
        self.enable_negotiation = enable_negotiation
        self.max_deliberation_rounds = max(1, max_deliberation_rounds)
        self.certificate_requery_service_regret_cfs = max(0.0, certificate_requery_service_regret_cfs)
        self.certificate_requery_reserve_violation_acft = max(0.0, certificate_requery_reserve_violation_acft)
        self.certificate_requery_actions = tuple(certificate_requery_actions)
        allowed_acceptance_modes = {"last", "certificate_score"}
        if redeliberation_acceptance_mode not in allowed_acceptance_modes:
            raise ValueError(
                f"redeliberation_acceptance_mode must be one of {sorted(allowed_acceptance_modes)}"
            )
        self.redeliberation_acceptance_mode = redeliberation_acceptance_mode
        self.redeliberation_score_tolerance = max(0.0, redeliberation_score_tolerance)
        allowed_shadow_modes = {
            "disabled",
            "certificate_score",
            "hydrologic_regret",
            "trained_admissibility",
        }
        if shadow_baseline_mode not in allowed_shadow_modes:
            raise ValueError(f"shadow_baseline_mode must be one of {sorted(allowed_shadow_modes)}")
        self.shadow_baseline_mode = shadow_baseline_mode
        self.shadow_score_tolerance = max(0.0, shadow_score_tolerance)
        self.hydrologic_supervisor_decay = clamp(hydrologic_supervisor_decay, 0.0, 1.0)
        self.hydrologic_supervisor_score_limit = max(0.0, hydrologic_supervisor_score_limit)
        self.hydrologic_supervisor_service_limit_cfs = max(0.0, hydrologic_supervisor_service_limit_cfs)
        self.hydrologic_supervisor_reserve_limit_acft = max(0.0, hydrologic_supervisor_reserve_limit_acft)
        self.hydrologic_admissibility_policy = hydrologic_admissibility_policy or {}
        self.hydrologic_regret_accounts: dict[str, HydrologicRegretAccount] = {}

    def decide(self, env: DailyReservoirEnvironment) -> MpcDecision:
        forecast = self.forecaster.forecast(env.date_index)
        forecast_summary = self.forecaster.summarize(forecast)
        reservoir_inflow = self.forecaster.reservoir_inflow_summary(forecast)
        intent = self.causal_layer.form_intent(env, forecast, forecast_summary, reservoir_inflow)
        deliberation = None
        if self.enable_deliberation:
            deliberation = self.deliberation_layer.deliberate(
                env,
                intent,
                forecast_summary,
                reservoir_inflow,
                forecast.horizon_days,
            )
        causal_anchor_releases = self.causal_layer.plan_releases(env, intent, forecast_summary, reservoir_inflow)
        initial_planner_state = self.planner.snapshot_state()
        round_records: list[dict[str, Any]] = []
        releases: dict[str, float] = {}
        diagnostics: dict[str, Any] = {}
        negotiation: NegotiationResult | None = None
        final_round_index = 0
        redeliberation_triggered = False
        feedback: dict[str, Any] | None = None
        round_attempts: list[dict[str, Any]] = []
        for round_index in range(self.max_deliberation_rounds):
            if round_index > 0 and self.enable_deliberation and feedback is not None:
                method = getattr(self.deliberation_layer, "deliberate_with_feedback", None)
                if callable(method):
                    deliberation = method(
                        env,
                        intent,
                        forecast_summary,
                        reservoir_inflow,
                        forecast.horizon_days,
                        feedback,
                        round_index,
                    )
            deliberation_state = self.snapshot_deliberation_layer_state()
            negotiation = (
                self.negotiator.negotiate(
                    env,
                    intent,
                    forecast_summary,
                    reservoir_inflow,
                    forecast.horizon_days,
                    deliberation,
                )
                if self.enable_negotiation
                else None
            )
            planner_state = self.planner.snapshot_state()
            releases, diagnostics = self.planner.plan(
                env,
                intent,
                forecast,
                forecast_summary,
                causal_anchor_releases,
                negotiation,
                deliberation,
            )
            requery, reasons = self.should_requery_after_certificate(diagnostics)
            round_record = self.round_record(round_index, deliberation, negotiation, diagnostics, reasons)
            round_record["certificate_round_score"] = self.certificate_round_score(diagnostics)
            round_records.append(round_record)
            round_attempts.append(
                {
                    "round_index": round_index,
                    "planner_state_before": planner_state,
                    "deliberation_layer_state": deliberation_state,
                    "releases": dict(releases),
                    "diagnostics": dict(diagnostics),
                    "deliberation": deliberation,
                    "negotiation": negotiation,
                }
            )
            final_round_index = round_index
            if (
                self.enable_deliberation
                and requery
                and round_index + 1 < self.max_deliberation_rounds
            ):
                self.planner.restore_state(planner_state)
                redeliberation_triggered = True
                feedback = self.build_certificate_feedback(
                    diagnostics,
                    deliberation,
                    round_index,
                    round_index + 1,
                    reasons,
                )
                continue
            break
        accepted_round_index = self.accepted_round_index(round_attempts)
        if round_attempts and accepted_round_index != len(round_attempts) - 1:
            accepted = round_attempts[accepted_round_index]
            self.planner.restore_state(accepted["planner_state_before"])
            self.planner.apply_certificate_diagnostics(accepted["diagnostics"])
            self.restore_deliberation_layer_state(accepted["deliberation_layer_state"])
            releases = dict(accepted["releases"])
            diagnostics = dict(accepted["diagnostics"])
            deliberation = accepted["deliberation"]
            negotiation = accepted["negotiation"]
            final_round_index = int(accepted["round_index"])
        for index, record in enumerate(round_records):
            record["accepted_round"] = index == accepted_round_index
        diagnostics.update(
            {
                "llm_deliberation_round_count": float(final_round_index + 1),
                "llm_redeliberation_triggered": 1.0 if redeliberation_triggered else 0.0,
                "llm_final_round_index": float(final_round_index),
                "llm_accepted_round_index": float(accepted_round_index),
                "llm_round_acceptance_mode": self.redeliberation_acceptance_mode,
                "llm_round_score_reverted": (
                    1.0
                    if round_attempts and accepted_round_index != len(round_attempts) - 1
                    else 0.0
                ),
                "llm_accepted_round_score": (
                    self.certificate_round_score(diagnostics) if diagnostics else 0.0
                ),
                "llm_redeliberation_reasons": ",".join(
                    unique_round_reasons(round_records)
                ),
                "llm_rounds_json": round_records,
            }
        )
        if self.shadow_baseline_mode != "disabled":
            semantic_releases = dict(releases)
            semantic_diagnostics = dict(diagnostics)
            self.planner.restore_state(initial_planner_state)
            shadow_negotiation = (
                self.negotiator.negotiate(
                    env,
                    intent,
                    forecast_summary,
                    reservoir_inflow,
                    forecast.horizon_days,
                    None,
                )
                if self.enable_negotiation
                else None
            )
            shadow_releases, shadow_diagnostics = self.planner.plan(
                env,
                intent,
                forecast,
                forecast_summary,
                causal_anchor_releases,
                shadow_negotiation,
                None,
            )
            semantic_score = self.certificate_round_score(semantic_diagnostics)
            shadow_score = self.certificate_round_score(shadow_diagnostics)
            selected_source, supervisor_details = self.shadow_supervisor_selection(
                env,
                forecast_summary,
                intent,
                semantic_diagnostics,
                shadow_diagnostics,
                semantic_score,
                shadow_score,
            )
            choose_shadow = selected_source == "shadow_baseline"
            if choose_shadow:
                releases = shadow_releases
                diagnostics = self.merge_shadow_diagnostics(
                    semantic_diagnostics,
                    shadow_diagnostics,
                    semantic_score,
                    shadow_score,
                    selected_source,
                    supervisor_details,
                )
                negotiation = shadow_negotiation
            else:
                self.planner.restore_state(initial_planner_state)
                self.planner.apply_certificate_diagnostics(semantic_diagnostics)
                releases = semantic_releases
                diagnostics = self.merge_shadow_diagnostics(
                    semantic_diagnostics,
                    semantic_diagnostics,
                    semantic_score,
                    shadow_score,
                    selected_source,
                    supervisor_details,
                )
        outcome_observer = getattr(self.deliberation_layer, "observe_outcome", None)
        if self.enable_deliberation and callable(outcome_observer):
            outcome_observer(diagnostics)
        return MpcDecision(intent=intent, releases_cfs=releases, forecast=forecast, diagnostics=diagnostics)

    def shadow_supervisor_selection(
        self,
        env: DailyReservoirEnvironment,
        forecast_summary: dict[str, float],
        intent: CausalIntent,
        semantic_diagnostics: dict[str, Any],
        shadow_diagnostics: dict[str, Any],
        semantic_score: float,
        shadow_score: float,
    ) -> tuple[str, dict[str, Any]]:
        score_delta = semantic_score - shadow_score
        semantic_shortage = float(
            semantic_diagnostics.get("certificate_selected_shortage_after_cfs", 0.0) or 0.0
        )
        shadow_shortage = float(
            shadow_diagnostics.get("certificate_selected_shortage_after_cfs", 0.0) or 0.0
        )
        semantic_reserve = float(
            semantic_diagnostics.get("certificate_reserve_violation_acft", 0.0) or 0.0
        )
        shadow_reserve = float(
            shadow_diagnostics.get("certificate_reserve_violation_acft", 0.0) or 0.0
        )
        semantic_next_storage = float(
            semantic_diagnostics.get("certificate_selected_next_storage_acft", 0.0) or 0.0
        )
        shadow_next_storage = float(
            shadow_diagnostics.get("certificate_selected_next_storage_acft", 0.0) or 0.0
        )
        service_delta = semantic_shortage - shadow_shortage
        reserve_delta = semantic_reserve - shadow_reserve
        next_storage_delta = semantic_next_storage - shadow_next_storage
        regime = self.hydrologic_supervisor_regime(env, forecast_summary, intent)
        details: dict[str, Any] = {
            "hydrologic_supervisor_mode": self.shadow_baseline_mode,
            "hydrologic_supervisor_regime_key": regime["key"],
            "hydrologic_supervisor_season": regime["season"],
            "hydrologic_supervisor_storage_regime": regime["storage_regime"],
            "hydrologic_supervisor_shortage_regime": regime["shortage_regime"],
            "hydrologic_supervisor_ecology_regime": regime["ecology_regime"],
            "hydrologic_supervisor_wetness_regime": regime["wetness_regime"],
            "hydrologic_supervisor_score_delta": score_delta,
            "hydrologic_supervisor_service_delta_cfs": service_delta,
            "hydrologic_supervisor_reserve_delta_acft": reserve_delta,
            "hydrologic_supervisor_next_storage_delta_acft": next_storage_delta,
            "hydrologic_supervisor_semantic_next_storage_acft": semantic_next_storage,
            "hydrologic_supervisor_shadow_next_storage_acft": shadow_next_storage,
            "hydrologic_supervisor_score_debt_before": 0.0,
            "hydrologic_supervisor_score_debt_after": 0.0,
            "hydrologic_supervisor_score_credit_after": 0.0,
            "hydrologic_supervisor_service_debt_after_cfs": 0.0,
            "hydrologic_supervisor_reserve_debt_after_acft": 0.0,
            "hydrologic_supervisor_score_limit": 0.0,
            "hydrologic_supervisor_service_limit_cfs": 0.0,
            "hydrologic_supervisor_reserve_limit_acft": 0.0,
            "hydrologic_supervisor_regime_observations": 0.0,
            "hydrologic_supervisor_admission_rule": "certificate_score",
        }
        if self.shadow_baseline_mode == "certificate_score":
            selected = (
                "shadow_baseline"
                if shadow_score + self.shadow_score_tolerance < semantic_score
                else "semantic_contract"
            )
            details["hydrologic_supervisor_admission_rule"] = (
                "lower_certificate_score" if selected == "shadow_baseline" else "semantic_noninferior"
            )
            return selected, details

        if self.shadow_baseline_mode == "trained_admissibility":
            return self.trained_admissibility_selection(
                env=env,
                forecast_summary=forecast_summary,
                intent=intent,
                regime=regime,
                details=details,
                score_delta=score_delta,
                service_delta=service_delta,
                reserve_delta=reserve_delta,
                next_storage_delta=next_storage_delta,
            )

        if self.shadow_baseline_mode != "hydrologic_regret":
            details["hydrologic_supervisor_admission_rule"] = "disabled"
            return "semantic_contract", details

        account = self.hydrologic_regret_accounts.setdefault(regime["key"], HydrologicRegretAccount())
        score_limit = self.hydrologic_score_limit(regime)
        service_limit = self.hydrologic_service_limit(regime)
        reserve_limit = self.hydrologic_reserve_limit(regime)
        projected_score_debt = (
            self.hydrologic_supervisor_decay * account.score_debt + max(0.0, score_delta)
        )
        projected_service_debt = (
            self.hydrologic_supervisor_decay * account.service_debt_cfs + max(0.0, service_delta)
        )
        projected_reserve_debt = (
            self.hydrologic_supervisor_decay * account.reserve_debt_acft + max(0.0, reserve_delta)
        )
        certificate_noninferior = score_delta <= self.shadow_score_tolerance
        semantic_service_gain = service_delta < -1e-9
        reserve_admissible = reserve_delta <= 0.0 or projected_reserve_debt <= reserve_limit
        regime_debt_admissible = (
            projected_score_debt <= score_limit and projected_service_debt <= service_limit
        )
        storage_recovery = next_storage_delta >= 0.0
        bounded_storage_recovery = (
            storage_recovery
            and regime["storage_regime"] in {"below_target_min", "low_recovery"}
            and score_delta <= 0.25 * score_limit
            and service_delta <= 0.20 * service_limit
            and reserve_delta <= 0.0
        )
        seasonal_recovery_window = (
            storage_recovery
            and regime["season"] in {"recharge_transition_OND", "winter_baseflow_JFM"}
            and regime["storage_regime"] in {"low_recovery", "target_band"}
            and regime["shortage_regime"] != "high"
            and score_delta <= 0.50 * score_limit
            and service_delta <= min(20.0, 0.40 * service_limit)
            and reserve_delta <= 0.0
            and projected_score_debt <= score_limit
            and projected_service_debt <= service_limit
        )
        if certificate_noninferior:
            selected = "semantic_contract"
            rule = "semantic_certificate_noninferior"
        elif semantic_service_gain and reserve_admissible and regime_debt_admissible:
            selected = "semantic_contract"
            rule = "hydrologic_service_gain_with_regime_budget"
        elif seasonal_recovery_window:
            selected = "semantic_contract"
            rule = "seasonal_storage_recovery_budget"
        elif bounded_storage_recovery:
            selected = "semantic_contract"
            rule = "low_storage_recovery_preference"
        else:
            selected = "shadow_baseline"
            rule = "regime_regret_shadow_fallback"

        score_debt_before = account.score_debt
        account.observations += 1
        account.score_debt *= self.hydrologic_supervisor_decay
        account.score_credit *= self.hydrologic_supervisor_decay
        account.service_debt_cfs *= self.hydrologic_supervisor_decay
        account.reserve_debt_acft *= self.hydrologic_supervisor_decay
        if selected == "semantic_contract":
            account.semantic_selected_days += 1
            account.score_debt += max(0.0, score_delta)
            account.score_credit += max(0.0, -score_delta)
            account.service_debt_cfs += max(0.0, service_delta)
            account.reserve_debt_acft += max(0.0, reserve_delta)
        else:
            account.shadow_selected_days += 1
            account.score_credit += max(0.0, -score_delta)

        details.update(
            {
                "hydrologic_supervisor_score_debt_before": score_debt_before,
                "hydrologic_supervisor_score_debt_after": account.score_debt,
                "hydrologic_supervisor_score_credit_after": account.score_credit,
                "hydrologic_supervisor_service_debt_after_cfs": account.service_debt_cfs,
                "hydrologic_supervisor_reserve_debt_after_acft": account.reserve_debt_acft,
                "hydrologic_supervisor_score_limit": score_limit,
                "hydrologic_supervisor_service_limit_cfs": service_limit,
                "hydrologic_supervisor_reserve_limit_acft": reserve_limit,
                "hydrologic_supervisor_regime_observations": float(account.observations),
                "hydrologic_supervisor_semantic_selected_days": float(account.semantic_selected_days),
                "hydrologic_supervisor_shadow_selected_days": float(account.shadow_selected_days),
                "hydrologic_supervisor_admission_rule": rule,
            }
        )
        return selected, details

    def hydrologic_supervisor_regime(
        self,
        env: DailyReservoirEnvironment,
        forecast_summary: dict[str, float],
        intent: CausalIntent,
    ) -> dict[str, str]:
        month = int(env.current_date[5:7])
        if month in {10, 11, 12}:
            season = "recharge_transition_OND"
        elif month in {1, 2, 3}:
            season = "winter_baseflow_JFM"
        elif month in {4, 5, 6}:
            season = "snowmelt_refill_AMJ"
        else:
            season = "late_summer_drawdown_JAS"
        total_storage = sum(env.storage_acft.values())
        target_min = sum(env.target_min(env.current_date, reservoir_id) for reservoir_id in env.reservoir_ids)
        target_max = sum(env.target_max(env.current_date, reservoir_id) for reservoir_id in env.reservoir_ids)
        storage_position = safe_divide(total_storage - target_min, max(1.0, target_max - target_min))
        if storage_position < 0.0:
            storage_regime = "below_target_min"
        elif storage_position < 0.45:
            storage_regime = "low_recovery"
        elif storage_position <= 1.05:
            storage_regime = "target_band"
        else:
            storage_regime = "above_target"
        no_release = env.route(env.current_date, {})
        shortage_pressure = max(
            no_release["total_shortage_before_release_cfs"],
            forecast_summary.get("p90_shortage_pressure_cfs", 0.0),
        )
        shortage_regime = self.pressure_regime(shortage_pressure, 750.0, 1500.0)
        ecology_pressure = max(
            no_release["instream_shortage_before_release_cfs"],
            intent.pressures.get("ecology_pressure", 0.0) * max(env.total_stream_flow(env.current_date), 1.0),
        )
        ecology_regime = self.pressure_regime(ecology_pressure, 250.0, 700.0)
        current_stream = env.total_stream_flow(env.current_date)
        wetness = safe_divide(forecast_summary.get("mean_stream_flow_cfs", 0.0), current_stream + 1.0)
        if wetness < 0.85:
            wetness_regime = "drying"
        elif wetness > 1.25:
            wetness_regime = "wetting"
        else:
            wetness_regime = "persistent"
        key = "|".join((season, storage_regime, shortage_regime, ecology_regime, wetness_regime))
        return {
            "key": key,
            "season": season,
            "storage_regime": storage_regime,
            "shortage_regime": shortage_regime,
            "ecology_regime": ecology_regime,
            "wetness_regime": wetness_regime,
        }

    def trained_admissibility_selection(
        self,
        env: DailyReservoirEnvironment,
        forecast_summary: dict[str, float],
        intent: CausalIntent,
        regime: dict[str, str],
        details: dict[str, Any],
        score_delta: float,
        service_delta: float,
        reserve_delta: float,
        next_storage_delta: float,
    ) -> tuple[str, dict[str, Any]]:
        trained_state = self.trained_admissibility_state(env, forecast_summary, intent)
        matched_rules = self.match_trained_admissibility_rules(trained_state)
        benefit_rules = [rule for rule in matched_rules if rule.get("direction") == "benefit"]
        fragile_rules = [rule for rule in matched_rules if rule.get("direction") == "fragile"]
        strongest_benefit = max(
            (abs(float(rule.get("mean_shortage_delta_cfs", 0.0) or 0.0)) for rule in benefit_rules),
            default=0.0,
        )
        strongest_fragility = max(
            (abs(float(rule.get("mean_shortage_delta_cfs", 0.0) or 0.0)) for rule in fragile_rules),
            default=0.0,
        )
        label = "unclassified"
        if benefit_rules and fragile_rules:
            label = "conflict"
        elif benefit_rules:
            label = "benefit"
        elif fragile_rules:
            label = "fragile"

        certificate_noninferior = score_delta <= self.shadow_score_tolerance
        score_limit = self.hydrologic_score_limit(regime)
        service_limit = self.hydrologic_service_limit(regime)
        reserve_limit = self.hydrologic_reserve_limit(regime)
        reserve_admissible = reserve_delta <= 0.0 or reserve_delta <= 0.50 * reserve_limit
        service_gain = service_delta <= 0.0
        storage_safe = next_storage_delta >= 0.0 and reserve_delta <= 0.0

        if label == "fragile":
            selected = "shadow_baseline"
            rule = "trained_fragile_veto"
        elif label == "conflict":
            selected = "shadow_baseline"
            rule = "trained_conflict_shadow_fallback"
        elif label == "benefit" and certificate_noninferior:
            selected = "semantic_contract"
            rule = "trained_benefit_certificate_noninferior"
        elif label == "benefit" and service_gain and reserve_admissible:
            selected = "semantic_contract"
            rule = "trained_benefit_service_gain"
        elif (
            label == "benefit"
            and storage_safe
            and service_delta <= min(20.0, 0.25 * service_limit)
            and score_delta <= max(10.0, 0.50 * score_limit)
        ):
            selected = "semantic_contract"
            rule = "trained_benefit_storage_safe"
        elif certificate_noninferior:
            selected = "semantic_contract"
            rule = "trained_unclassified_certificate_noninferior"
        else:
            selected = "shadow_baseline"
            rule = "trained_unclassified_shadow_fallback"

        details.update(
            {
                "hydrologic_supervisor_admission_rule": rule,
                "hydrologic_supervisor_regime_label": label,
                "hydrologic_supervisor_score_limit": score_limit,
                "hydrologic_supervisor_service_limit_cfs": service_limit,
                "hydrologic_supervisor_reserve_limit_acft": reserve_limit,
                "trained_admissibility_policy_id": str(
                    self.hydrologic_admissibility_policy.get("policy_id", "")
                ),
                "trained_admissibility_training_end_date": str(
                    self.hydrologic_admissibility_policy.get("training_end_date", "")
                ),
                "trained_admissibility_test_start_date": str(
                    self.hydrologic_admissibility_policy.get("test_start_date", "")
                ),
                "trained_admissibility_state_key": trained_state["state_key"],
                "trained_admissibility_matched_rule_count": float(len(matched_rules)),
                "trained_admissibility_benefit_rule_count": float(len(benefit_rules)),
                "trained_admissibility_fragile_rule_count": float(len(fragile_rules)),
                "trained_admissibility_strongest_benefit_cfs": strongest_benefit,
                "trained_admissibility_strongest_fragility_cfs": strongest_fragility,
                "trained_admissibility_matched_rules_json": [
                    {
                        "family": rule.get("family", ""),
                        "regime_key": rule.get("regime_key", ""),
                        "direction": rule.get("direction", ""),
                        "mean_shortage_delta_cfs": rule.get("mean_shortage_delta_cfs", 0.0),
                        "consistent_year_fraction": rule.get("consistent_year_fraction", 0.0),
                    }
                    for rule in matched_rules
                ],
            }
        )
        return selected, details

    def trained_admissibility_state(
        self,
        env: DailyReservoirEnvironment,
        forecast_summary: dict[str, float],
        intent: CausalIntent,
    ) -> dict[str, str]:
        thresholds = self.hydrologic_admissibility_policy.get("feature_thresholds", {})
        no_release = env.route(env.current_date, {})
        month = int(env.current_date[5:7])
        if month in {10, 11, 12}:
            season = "OND"
        elif month in {1, 2, 3}:
            season = "JFM"
        elif month in {4, 5, 6}:
            season = "AMJ"
        else:
            season = "JAS"
        values = {
            "storage": float(intent.pressures.get("storage_ratio", 0.0) or 0.0),
            "shortage": float(no_release.get("total_shortage_before_release_cfs", 0.0) or 0.0),
            "ecology": float(intent.pressures.get("ecology_pressure", 0.0) or 0.0),
            "drought": float(intent.pressures.get("drought_pressure", 0.0) or 0.0),
            "forecast_shortage": float(intent.pressures.get("forecast_shortage_pressure", 0.0) or 0.0),
        }
        bins = {
            key: self.trained_admissibility_bin(values[key], thresholds.get(key, (0.33, 0.67)))
            for key in values
        }
        state = {
            "season": season,
            **bins,
        }
        state["state_key"] = "|".join(
            (
                state["season"],
                state["storage"],
                state["shortage"],
                state["ecology"],
                state["drought"],
                state["forecast_shortage"],
            )
        )
        return state

    def match_trained_admissibility_rules(self, state: dict[str, str]) -> list[dict[str, Any]]:
        matched: list[dict[str, Any]] = []
        for rule in self.hydrologic_admissibility_policy.get("regime_rules", []):
            family_keys = rule.get("keys", [])
            if not isinstance(family_keys, list) or not family_keys:
                family_keys = str(rule.get("family", "")).split("_")
            key = "|".join(state.get(str(item), "") for item in family_keys)
            if key == str(rule.get("regime_key", "")):
                matched.append(rule)
        return matched

    @staticmethod
    def trained_admissibility_bin(value: float, thresholds: Any) -> str:
        try:
            low = float(thresholds[0])
            high = float(thresholds[1])
        except (TypeError, ValueError, IndexError, KeyError):
            low = 0.33
            high = 0.67
        if value < low:
            return "low"
        if value < high:
            return "middle"
        return "high"

    @staticmethod
    def pressure_regime(value: float, low_threshold: float, high_threshold: float) -> str:
        if value < low_threshold:
            return "low"
        if value < high_threshold:
            return "middle"
        return "high"

    def hydrologic_score_limit(self, regime: dict[str, str]) -> float:
        multiplier = 1.0
        if regime["storage_regime"] in {"below_target_min", "low_recovery"}:
            multiplier *= 0.70
        if regime["season"] == "late_summer_drawdown_JAS":
            multiplier *= 0.80
        if regime["shortage_regime"] == "high":
            multiplier *= 1.20
        if regime["wetness_regime"] == "drying":
            multiplier *= 0.85
        return self.hydrologic_supervisor_score_limit * multiplier

    def hydrologic_service_limit(self, regime: dict[str, str]) -> float:
        multiplier = 1.0
        if regime["shortage_regime"] == "high":
            multiplier *= 1.25
        if regime["storage_regime"] in {"below_target_min", "low_recovery"}:
            multiplier *= 0.80
        return self.hydrologic_supervisor_service_limit_cfs * multiplier

    def hydrologic_reserve_limit(self, regime: dict[str, str]) -> float:
        multiplier = 1.0
        if regime["storage_regime"] in {"below_target_min", "low_recovery"}:
            multiplier *= 0.50
        if regime["season"] in {"snowmelt_refill_AMJ", "recharge_transition_OND"}:
            multiplier *= 1.25
        if regime["wetness_regime"] == "drying":
            multiplier *= 0.75
        return self.hydrologic_supervisor_reserve_limit_acft * multiplier

    def merge_shadow_diagnostics(
        self,
        semantic_diagnostics: dict[str, Any],
        selected_diagnostics: dict[str, Any],
        semantic_score: float,
        shadow_score: float,
        selected_source: str,
        supervisor_details: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        merged = dict(selected_diagnostics)
        for key, value in semantic_diagnostics.items():
            if key.startswith("deliberation_") or key.startswith("llm_"):
                merged[key] = value
        merged.update(
            {
                "shadow_supervisor_mode": self.shadow_baseline_mode,
                "shadow_supervisor_selected_source": selected_source,
                "shadow_supervisor_selected_shadow": 1.0 if selected_source == "shadow_baseline" else 0.0,
                "shadow_supervisor_semantic_score": semantic_score,
                "shadow_supervisor_shadow_score": shadow_score,
                "shadow_supervisor_score_delta": semantic_score - shadow_score,
                "shadow_semantic_selected_action": semantic_diagnostics.get("certificate_selected_action", ""),
                "shadow_semantic_shortage_after_cfs": semantic_diagnostics.get(
                    "certificate_selected_shortage_after_cfs", 0.0
                ),
                "shadow_semantic_reserve_violation_acft": semantic_diagnostics.get(
                    "certificate_reserve_violation_acft", 0.0
                ),
            }
        )
        if supervisor_details:
            merged.update(supervisor_details)
        return merged

    def snapshot_deliberation_layer_state(self) -> dict[str, Any] | None:
        method = getattr(self.deliberation_layer, "snapshot_state", None)
        if callable(method):
            return method()
        return None

    def restore_deliberation_layer_state(self, snapshot: dict[str, Any] | None) -> None:
        method = getattr(self.deliberation_layer, "restore_state", None)
        if callable(method):
            method(snapshot)

    def certificate_round_score(self, diagnostics: dict[str, Any]) -> float:
        service_weight = float(diagnostics.get("certificate_service_dual_weight", 1.0) or 1.0)
        reserve_weight = float(diagnostics.get("certificate_reserve_dual_weight", 1.0) or 1.0)
        shortage = float(diagnostics.get("certificate_selected_shortage_after_cfs", 0.0) or 0.0)
        reserve_violation = float(diagnostics.get("certificate_reserve_violation_acft", 0.0) or 0.0)
        return service_weight * shortage + reserve_weight * reserve_violation / CFS_DAY_TO_ACFT

    def accepted_round_index(self, round_attempts: list[dict[str, Any]]) -> int:
        if not round_attempts:
            return 0
        if self.redeliberation_acceptance_mode == "last":
            return len(round_attempts) - 1
        best_index = 0
        best_score = self.certificate_round_score(round_attempts[0]["diagnostics"])
        for index, attempt in enumerate(round_attempts[1:], start=1):
            score = self.certificate_round_score(attempt["diagnostics"])
            if score + self.redeliberation_score_tolerance < best_score:
                best_index = index
                best_score = score
        return best_index

    def should_requery_after_certificate(self, diagnostics: dict[str, Any]) -> tuple[bool, list[str]]:
        reasons: list[str] = []
        action = str(diagnostics.get("certificate_selected_action", ""))
        if action in self.certificate_requery_actions:
            reasons.append(f"certificate_action:{action}")
        service_regret = float(diagnostics.get("certificate_service_regret_cfs", 0.0) or 0.0)
        if (
            self.certificate_requery_service_regret_cfs > 0.0
            and service_regret >= self.certificate_requery_service_regret_cfs
        ):
            reasons.append("service_regret")
        reserve_violation = float(diagnostics.get("certificate_reserve_violation_acft", 0.0) or 0.0)
        if (
            self.certificate_requery_reserve_violation_acft > 0.0
            and reserve_violation >= self.certificate_requery_reserve_violation_acft
        ):
            reasons.append("reserve_violation")
        selected_storage = float(diagnostics.get("certificate_selected_next_storage_acft", 0.0) or 0.0)
        viability_floor = float(diagnostics.get("certificate_viability_floor_acft", 0.0) or 0.0)
        if selected_storage + 1e-6 < viability_floor:
            reasons.append("viability_failure")
        return bool(reasons), unique_strings(reasons)

    def build_certificate_feedback(
        self,
        diagnostics: dict[str, Any],
        deliberation: SkillDeliberationResult | None,
        previous_round_index: int,
        next_round_index: int,
        reasons: list[str],
    ) -> dict[str, Any]:
        contract_hash = (
            deliberation.policy_contract.stable_hash()
            if deliberation is not None
            else ""
        )
        return {
            "previous_round_index": previous_round_index,
            "next_round_index": next_round_index,
            "requery_reasons": list(reasons),
            "selected_action": diagnostics.get("certificate_selected_action", ""),
            "mpc_shortage_after_cfs": diagnostics.get("certificate_mpc_shortage_after_cfs", 0.0),
            "anchor_shortage_after_cfs": diagnostics.get("certificate_anchor_shortage_after_cfs", 0.0),
            "raw_anchor_shortage_after_cfs": diagnostics.get("certificate_raw_anchor_shortage_after_cfs", 0.0),
            "selected_shortage_after_cfs": diagnostics.get("certificate_selected_shortage_after_cfs", 0.0),
            "service_gap_cfs": diagnostics.get("certificate_service_gap_cfs", 0.0),
            "service_regret_cfs": diagnostics.get("certificate_service_regret_cfs", 0.0),
            "reserve_violation_acft": diagnostics.get("certificate_reserve_violation_acft", 0.0),
            "reserve_borrowing_acft": diagnostics.get("certificate_reserve_borrowing_acft", 0.0),
            "selected_next_storage_acft": diagnostics.get("certificate_selected_next_storage_acft", 0.0),
            "hard_reserve_floor_acft": diagnostics.get("certificate_hard_reserve_floor_acft", 0.0),
            "viability_floor_acft": diagnostics.get("certificate_viability_floor_acft", 0.0),
            "maximum_reachable_storage_acft": diagnostics.get("certificate_maximum_reachable_storage_acft", 0.0),
            "service_ledger_after": diagnostics.get("certificate_service_ledger_after", 0.0),
            "reserve_ledger_after": diagnostics.get("certificate_reserve_ledger_after", 0.0),
            "service_dual_weight": diagnostics.get("certificate_service_dual_weight", 1.0),
            "reserve_dual_weight": diagnostics.get("certificate_reserve_dual_weight", 1.0),
            "override_margin": diagnostics.get("certificate_override_margin", 0.0),
            "prior_contract_hash": contract_hash,
            "prior_dominant_intent": deliberation.dominant_intent if deliberation is not None else "",
            "prior_support_multiplier": (
                deliberation.support_budget_multiplier if deliberation is not None else 1.0
            ),
            "prior_buffer_multiplier": (
                deliberation.buffer_budget_multiplier if deliberation is not None else 1.0
            ),
            "prior_reserve_delta_acft": (
                deliberation.reserve_floor_delta_acft if deliberation is not None else 0.0
            ),
            "instruction": (
                "Revise the semantic contract only if the certificate shows that the "
                "previous intent budget conflicts with service, reserve, or viability "
                "requirements. Do not output reservoir releases."
            ),
        }

    def round_record(
        self,
        round_index: int,
        deliberation: SkillDeliberationResult | None,
        negotiation: NegotiationResult | None,
        diagnostics: dict[str, Any],
        requery_reasons: list[str],
    ) -> dict[str, Any]:
        return {
            "round_index": round_index,
            "backend": deliberation.backend_name if deliberation is not None else "disabled",
            "dominant_intent": deliberation.dominant_intent if deliberation is not None else "",
            "contract_hash": (
                deliberation.policy_contract.stable_hash()
                if deliberation is not None
                else ""
            ),
            "support_multiplier": (
                deliberation.support_budget_multiplier if deliberation is not None else 1.0
            ),
            "buffer_multiplier": (
                deliberation.buffer_budget_multiplier if deliberation is not None else 1.0
            ),
            "reserve_delta_acft": (
                deliberation.reserve_floor_delta_acft if deliberation is not None else 0.0
            ),
            "risk_aversion_delta": (
                deliberation.risk_aversion_delta if deliberation is not None else 0.0
            ),
            "negotiation_status": negotiation.status if negotiation is not None else "disabled",
            "certificate_selected_action": diagnostics.get("certificate_selected_action", ""),
            "certificate_service_regret_cfs": diagnostics.get("certificate_service_regret_cfs", 0.0),
            "certificate_reserve_violation_acft": diagnostics.get("certificate_reserve_violation_acft", 0.0),
            "certificate_selected_shortage_after_cfs": diagnostics.get(
                "certificate_selected_shortage_after_cfs", 0.0
            ),
            "requery_reasons": list(requery_reasons),
        }


class RobustIntentMpcPlanner:
    """Intent-conditioned robust MPC over transparent policy candidates.

    This is the final planner layer rather than a decorative wrapper around the
    intent rule. It performs three auditable operations every day:

    1. evaluate intent-specific release-policy candidates over an analog
       ensemble horizon with mean, CVaR, and worst-member costs;
    2. turn the best horizon policy into a release vector under reservoir
       storage/release constraints;
    3. compare that vector with the causal-intent anchor through exact
       current-day topology routing before execution.
    """

    def __init__(
        self,
        risk_weight: float = 0.55,
        worst_weight: float = 0.10,
        discount: float = 0.97,
        cvar_quantile: float = 0.80,
        certificate_storage_tolerance_acft: float = 250.0,
        strategic_reserve_weight: float = 6.0,
        viability_floor_fraction: float = 0.25,
        service_ledger_scale_cfs_days: float = 1000.0,
        reserve_ledger_scale_acft: float = 100000.0,
        ledger_decay: float = 0.995,
        reserve_repayment_fraction: float = 0.08,
        ledger_recovery_fraction: float = 0.20,
        certificate_mode: str = "full",
        supply_guarantee_fraction: float = 0.0,
        supply_guarantee_nodes: tuple[str, ...] = (),
        supply_guarantee_priority_reservoirs: dict[str, tuple[str, ...]] | None = None,
        enable_supply_reserve_guard: bool = True,
        supply_reserve_guard_mode: str = "always",
        supply_reserve_guard_min_demand_cfs: float = 0.0,
        supply_reserve_guard_local_storage_fraction: float = 0.0,
        supply_path_viability_mode: str = "disabled",
        supply_path_viability_base_fraction: float = 0.35,
        supply_path_viability_max_fraction: float = 0.75,
        supply_path_viability_memory_days: float = 180.0,
        supply_path_viability_demand_lookahead_days: int = 180,
        supply_path_viability_demand_reserve_fraction: float = 0.35,
        supply_path_viability_forecast_multiplier: float = 1.0,
    ) -> None:
        allowed_certificate_modes = {
            "full",
            "mpc_only",
            "no_service_override",
            "no_ledger",
            "no_viability_boundary",
        }
        if certificate_mode not in allowed_certificate_modes:
            raise ValueError(
                f"certificate_mode must be one of {sorted(allowed_certificate_modes)}"
            )
        self.risk_weight = risk_weight
        self.worst_weight = worst_weight
        self.discount = discount
        self.cvar_quantile = cvar_quantile
        self.certificate_storage_tolerance_acft = certificate_storage_tolerance_acft
        self.strategic_reserve_weight = strategic_reserve_weight
        self.viability_floor_fraction = clamp(viability_floor_fraction, 0.05, 0.95)
        self.service_ledger_scale_cfs_days = max(1.0, service_ledger_scale_cfs_days)
        self.reserve_ledger_scale_acft = max(1.0, reserve_ledger_scale_acft)
        self.ledger_decay = clamp(ledger_decay, 0.0, 1.0)
        self.reserve_repayment_fraction = clamp(reserve_repayment_fraction, 0.0, 1.0)
        self.ledger_recovery_fraction = clamp(ledger_recovery_fraction, 0.0, 1.0)
        self.certificate_mode = certificate_mode
        self.supply_guarantee_fraction = clamp(supply_guarantee_fraction, 0.0, 1.0)
        self.supply_guarantee_nodes = tuple(str(node_id) for node_id in supply_guarantee_nodes if str(node_id))
        self.supply_guarantee_priority_reservoirs = (
            {
                str(node_id): tuple(str(reservoir_id) for reservoir_id in reservoirs)
                for node_id, reservoirs in supply_guarantee_priority_reservoirs.items()
            }
            if supply_guarantee_priority_reservoirs is not None
            else dict(DEFAULT_SUPPLY_GUARANTEE_PRIORITY)
        )
        self.enable_supply_reserve_guard = enable_supply_reserve_guard
        allowed_guard_modes = {"always", "forecast_risk", "forecast_risk_or_local_storage"}
        if supply_reserve_guard_mode not in allowed_guard_modes:
            raise ValueError(
                f"supply_reserve_guard_mode must be one of {sorted(allowed_guard_modes)}"
            )
        self.supply_reserve_guard_mode = supply_reserve_guard_mode
        self.supply_reserve_guard_min_demand_cfs = max(0.0, supply_reserve_guard_min_demand_cfs)
        self.supply_reserve_guard_local_storage_fraction = clamp(
            supply_reserve_guard_local_storage_fraction,
            0.0,
            1.0,
        )
        allowed_path_viability_modes = {"disabled", "adaptive_envelope"}
        if supply_path_viability_mode not in allowed_path_viability_modes:
            raise ValueError(
                "supply_path_viability_mode must be one of "
                f"{sorted(allowed_path_viability_modes)}"
            )
        self.supply_path_viability_mode = supply_path_viability_mode
        self.supply_path_viability_base_fraction = clamp(
            supply_path_viability_base_fraction,
            0.0,
            1.0,
        )
        self.supply_path_viability_max_fraction = clamp(
            max(supply_path_viability_max_fraction, self.supply_path_viability_base_fraction),
            0.0,
            1.0,
        )
        self.supply_path_viability_memory_days = max(1.0, supply_path_viability_memory_days)
        self.supply_path_viability_demand_lookahead_days = max(
            1,
            int(supply_path_viability_demand_lookahead_days),
        )
        self.supply_path_viability_demand_reserve_fraction = clamp(
            supply_path_viability_demand_reserve_fraction,
            0.0,
            1.0,
        )
        self.supply_path_viability_forecast_multiplier = max(
            0.0,
            supply_path_viability_forecast_multiplier,
        )
        self.safety_ledger = OnlineSafetyLedger()
        self.path_viability_accounts: dict[str, PathViabilityAccount] = {}
        self._influence_cache: dict[int, dict[str, float]] = {}

    def snapshot_state(self) -> dict[str, Any]:
        return {
            "safety_ledger": replace(self.safety_ledger),
            "path_viability_accounts": {
                node_id: replace(account)
                for node_id, account in self.path_viability_accounts.items()
            },
            "influence_cache": {
                key: dict(value)
                for key, value in self._influence_cache.items()
            },
        }

    def restore_state(self, snapshot: dict[str, Any]) -> None:
        ledger = snapshot.get("safety_ledger")
        if isinstance(ledger, OnlineSafetyLedger):
            self.safety_ledger = replace(ledger)
        accounts = snapshot.get("path_viability_accounts", {})
        if isinstance(accounts, dict):
            self.path_viability_accounts = {
                str(node_id): replace(account)
                for node_id, account in accounts.items()
                if isinstance(account, PathViabilityAccount)
            }
        influence_cache = snapshot.get("influence_cache", {})
        if isinstance(influence_cache, dict):
            self._influence_cache = {
                int(key): dict(value)
                for key, value in influence_cache.items()
                if isinstance(value, dict)
            }

    def apply_certificate_diagnostics(self, diagnostics: dict[str, Any]) -> None:
        self.safety_ledger.service_regret_cfs_days = float(
            diagnostics.get("certificate_service_ledger_after", 0.0) or 0.0
        )
        self.safety_ledger.reserve_debt_acft = float(
            diagnostics.get("certificate_reserve_ledger_after", 0.0) or 0.0
        )
        self.safety_ledger.last_reserve_violation_acft = float(
            diagnostics.get("certificate_reserve_violation_acft", 0.0) or 0.0
        )
        self.safety_ledger.service_override_days = int(
            float(diagnostics.get("certificate_service_override_days", 0.0) or 0.0)
        )
        path_details = diagnostics.get("certificate_path_viability_details_json", [])
        if isinstance(path_details, list):
            for item in path_details:
                if not isinstance(item, dict):
                    continue
                node_id = str(item.get("node_id", ""))
                if not node_id:
                    continue
                self.path_viability_accounts[node_id] = PathViabilityAccount(
                    cumulative_net_deficit_acft=max(
                        0.0,
                        float(item.get("cumulative_net_deficit_after_acft", 0.0) or 0.0),
                    ),
                    ewma_net_deficit_acft=max(
                        0.0,
                        float(item.get("ewma_net_deficit_after_acft", 0.0) or 0.0),
                    ),
                    observations=max(0, int(float(item.get("observations_after", 0) or 0))),
                )

    def plan(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast: EnsembleForecast,
        forecast_summary: dict[str, float],
        causal_anchor_releases: dict[str, float] | None = None,
        negotiation: NegotiationResult | None = None,
        deliberation: SkillDeliberationResult | None = None,
    ) -> tuple[dict[str, float], dict[str, Any]]:
        if causal_anchor_releases is None:
            causal_anchor_releases = {}
        planning_intent = self.planning_primary_intent(intent, negotiation, deliberation)
        candidates = self.intent_candidates(planning_intent)
        evaluations = [
            self.evaluate_candidate(env, intent, forecast, candidate, negotiation, deliberation)
            for candidate in candidates
        ]
        evaluations.sort(key=lambda item: item.robust_cost)
        best = evaluations[0]
        current_values = env.forcing_row(env.current_date)
        mpc_releases = self.policy_release_for_values(
            env=env,
            intent=intent,
            candidate=best.candidate,
            date=env.current_date,
            values=current_values,
            storage_acft=dict(env.storage_acft),
            previous_releases_cfs={reservoir_id: 0.0 for reservoir_id in env.reservoir_ids},
            negotiation=negotiation,
            deliberation=deliberation,
        )
        releases, certificate = self.certified_current_day_choice(
            env=env,
            intent=intent,
            forecast=forecast,
            mpc_releases=mpc_releases,
            causal_anchor_releases=causal_anchor_releases,
            negotiation=negotiation,
        )
        diagnostics = {
            "mpc_candidate_id": best.candidate.candidate_id,
            "mpc_planning_intent": planning_intent,
            "mpc_robust_cost": best.robust_cost,
            "mpc_mean_cost": best.mean_cost,
            "mpc_cvar_cost": best.cvar_cost,
            "mpc_worst_cost": best.worst_cost,
            "mpc_mean_shortage_cfs": best.mean_shortage_cfs,
            "mpc_mean_terminal_deficit_acft": best.mean_terminal_deficit_acft,
            "mpc_mean_release_cfs": best.mean_release_cfs,
            "mpc_candidate_count": float(len(evaluations)),
            "mpc_risk_weight": self.risk_weight,
            "mpc_worst_weight": self.worst_weight,
            "mpc_strategic_reserve_weight": self.strategic_reserve_weight,
            "mpc_top_candidates": [
                {
                    "candidate_id": evaluation.candidate.candidate_id,
                    "robust_cost": evaluation.robust_cost,
                    "mean_cost": evaluation.mean_cost,
                    "cvar_cost": evaluation.cvar_cost,
                }
                for evaluation in evaluations[:5]
            ],
            "forecast_mean_shortage_pressure_cfs": forecast_summary.get("mean_shortage_pressure_cfs", 0.0),
            "forecast_p90_shortage_pressure_cfs": forecast_summary.get("p90_shortage_pressure_cfs", 0.0),
            **self.deliberation_diagnostics(intent, deliberation),
            **self.negotiation_diagnostics(negotiation),
            **certificate,
        }
        return releases, diagnostics

    def planning_primary_intent(
        self,
        intent: CausalIntent,
        negotiation: NegotiationResult | None,
        deliberation: SkillDeliberationResult | None,
    ) -> str:
        if negotiation is not None:
            return negotiation.final_proposal.primary_intent
        if deliberation is not None:
            return deliberation.dominant_intent
        return intent.primary_intent

    def deliberation_diagnostics(
        self,
        intent: CausalIntent,
        deliberation: SkillDeliberationResult | None,
    ) -> dict[str, Any]:
        if deliberation is None:
            return {
                "deliberation_backend": "disabled",
                "deliberation_active_skill_count": 0.0,
                "deliberation_active_skills": "",
                "deliberation_conflict_count": 0.0,
                "deliberation_dominant_intent": "",
                "deliberation_auxiliary_intents": "",
                "deliberation_rejected_intents": "",
                "deliberation_priority_order": "",
                "deliberation_risk_posture": "",
                "deliberation_support_multiplier": 1.0,
                "deliberation_buffer_multiplier": 1.0,
                "deliberation_reserve_delta_acft": 0.0,
                "deliberation_risk_aversion_delta": 0.0,
                "deliberation_schema_valid": 0.0,
                "deliberation_evidence_bound": 0.0,
                "deliberation_mean_claim_priority": 0.0,
                "deliberation_max_claim_priority": 0.0,
                "deliberation_total_claim_support_cfs": 0.0,
                "deliberation_total_claim_reserve_acft": 0.0,
                "deliberation_policy_contract_hash": "",
                "deliberation_influence_score": 0.0,
                "deliberation_event_triggered": 0.0,
                "deliberation_trigger_score": 0.0,
                "deliberation_trigger_reasons": "",
                "deliberation_contract_age_days": 0.0,
                "deliberation_state_novelty": 0.0,
                "deliberation_contract_reused": 0.0,
                "deliberation_support_validity": 0.0,
                "deliberation_semantic_state_hash": "",
                "deliberation_contract_schema_version": "",
                "deliberation_watch_features": "",
                "deliberation_validity_radius": 0.0,
                "deliberation_requested_max_age_days": 0.0,
                "deliberation_safety_review_mode": "",
                "deliberation_evidence_citations": [],
                "deliberation_conflict_resolutions": [],
                "deliberation_decision_steps": [],
                "deliberation_trace": "",
                "deliberation_claims": [],
                "deliberation_conflicts": [],
            }
        claim_summary = summarize_claims(deliberation.claims)
        return {
            "deliberation_backend": deliberation.backend_name,
            "deliberation_active_skill_count": float(len(deliberation.active_skills)),
            "deliberation_active_skills": ",".join(deliberation.active_skills),
            "deliberation_conflict_count": float(deliberation.conflict_count),
            "deliberation_dominant_intent": deliberation.dominant_intent,
            "deliberation_auxiliary_intents": ",".join(deliberation.auxiliary_intents),
            "deliberation_rejected_intents": ",".join(deliberation.rejected_intents),
            "deliberation_priority_order": ",".join(deliberation.priority_order),
            "deliberation_risk_posture": deliberation.risk_posture,
            "deliberation_support_multiplier": deliberation.support_budget_multiplier,
            "deliberation_buffer_multiplier": deliberation.buffer_budget_multiplier,
            "deliberation_reserve_delta_acft": deliberation.reserve_floor_delta_acft,
            "deliberation_risk_aversion_delta": deliberation.risk_aversion_delta,
            "deliberation_schema_valid": 1.0 if deliberation.schema_valid else 0.0,
            "deliberation_evidence_bound": 1.0 if deliberation.evidence_bound else 0.0,
            "deliberation_mean_claim_priority": claim_summary["mean_priority"],
            "deliberation_max_claim_priority": claim_summary["max_priority"],
            "deliberation_total_claim_support_cfs": claim_summary["total_support_budget_cfs"],
            "deliberation_total_claim_reserve_acft": claim_summary["total_reserve_delta_acft"],
            "deliberation_policy_contract_hash": deliberation.policy_contract.stable_hash(),
            "deliberation_influence_score": self.deliberation_influence_score(intent, deliberation),
            "deliberation_event_triggered": 1.0 if deliberation.event_triggered else 0.0,
            "deliberation_trigger_score": deliberation.trigger_score,
            "deliberation_trigger_reasons": ",".join(deliberation.trigger_reasons),
            "deliberation_contract_age_days": float(deliberation.contract_age_days),
            "deliberation_state_novelty": deliberation.state_novelty,
            "deliberation_contract_reused": 1.0 if deliberation.contract_reused else 0.0,
            "deliberation_support_validity": deliberation.support_validity,
            "deliberation_semantic_state_hash": deliberation.semantic_state_hash,
            "deliberation_contract_schema_version": deliberation.contract_schema_version,
            "deliberation_watch_features": ",".join(deliberation.watch_features),
            "deliberation_validity_radius": deliberation.validity_radius,
            "deliberation_requested_max_age_days": float(
                deliberation.requested_max_age_days
            ),
            "deliberation_safety_review_mode": deliberation.safety_review_mode,
            "deliberation_evidence_citations": [
                {
                    "skill_name": citation.skill_name,
                    "evidence_keys": list(citation.evidence_keys),
                }
                for citation in deliberation.evidence_citations
            ],
            "deliberation_conflict_resolutions": [
                {
                    "source_skill": resolution.source_skill,
                    "target_skill": resolution.target_skill,
                    "resolution": resolution.resolution,
                    "controlling_skill": resolution.controlling_skill,
                }
                for resolution in deliberation.conflict_resolutions
            ],
            "deliberation_decision_steps": [
                {
                    "stage": step.stage,
                    "conclusion": step.conclusion,
                    "cited_skills": list(step.cited_skills),
                }
                for step in deliberation.decision_steps
            ],
            "deliberation_trace": deliberation.deliberation_trace,
            "deliberation_claims": [
                {
                    "skill_name": claim.skill_name,
                    "supported_intent": claim.supported_intent,
                    "priority": claim.priority,
                    "confidence": claim.confidence,
                    "support_budget_cfs": claim.support_budget_cfs,
                    "buffer_budget_cfs": claim.buffer_budget_cfs,
                    "reserve_delta_acft": claim.reserve_delta_acft,
                    "risk_delta": claim.risk_delta,
                    "rationale": claim.rationale,
                    "evidence": claim.evidence,
                }
                for claim in deliberation.claims
            ],
            "deliberation_conflicts": [
                {
                    "source_skill": conflict.source_skill,
                    "target_skill": conflict.target_skill,
                    "conflict_type": conflict.conflict_type,
                    "severity": conflict.severity,
                    "evidence": conflict.evidence,
                }
                for conflict in deliberation.conflicts
            ],
        }

    def deliberation_influence_score(
        self,
        intent: CausalIntent,
        deliberation: SkillDeliberationResult,
    ) -> float:
        intent_shift = 1.0 if deliberation.dominant_intent != intent.primary_intent else 0.0
        support_shift = min(1.0, abs(deliberation.support_budget_multiplier - 1.0) / 0.50)
        buffer_shift = min(1.0, abs(deliberation.buffer_budget_multiplier - 1.0) / 0.50)
        risk_shift = min(1.0, deliberation.risk_aversion_delta / 0.35)
        conflict_signal = min(1.0, deliberation.conflict_count / 6.0)
        return (
            0.30 * intent_shift
            + 0.25 * support_shift
            + 0.10 * buffer_shift
            + 0.20 * risk_shift
            + 0.15 * conflict_signal
        )

    def negotiation_diagnostics(self, negotiation: NegotiationResult | None) -> dict[str, Any]:
        if negotiation is None:
            return {
                "negotiation_status": "disabled",
                "negotiation_rounds": 0.0,
                "negotiation_initial_support_cfs": 0.0,
                "negotiation_final_support_cfs": 0.0,
                "negotiation_requested_buffer_cfs": 0.0,
                "negotiation_reserve_target_acft": 0.0,
                "negotiation_hard_safety_floor_acft": 0.0,
                "negotiation_support_acceptance_ratio": 0.0,
                "negotiation_risk_aversion": 0.0,
                "negotiation_routed_service_gain_cfs": 0.0,
                "negotiation_support_gap_cfs": 0.0,
                "negotiation_feasible_release_cfs": 0.0,
                "negotiation_marginal_service_efficiency": 0.0,
                "negotiation_limiting_factor": "",
            }
        certificate = negotiation.final_certificate
        return {
            "negotiation_status": negotiation.status,
            "negotiation_rounds": float(len(negotiation.rounds)),
            "negotiation_initial_support_cfs": negotiation.initial_proposal.requested_support_cfs,
            "negotiation_final_support_cfs": negotiation.final_proposal.requested_support_cfs,
            "negotiation_requested_buffer_cfs": negotiation.final_proposal.requested_buffer_cfs,
            "negotiation_reserve_target_acft": negotiation.final_proposal.reserve_floor_acft,
            "negotiation_hard_safety_floor_acft": negotiation.final_proposal.hard_safety_floor_acft,
            "negotiation_support_acceptance_ratio": negotiation.support_acceptance_ratio,
            "negotiation_risk_aversion": negotiation.final_proposal.risk_aversion,
            "negotiation_routed_service_gain_cfs": certificate.routed_service_gain_cfs,
            "negotiation_support_gap_cfs": certificate.support_gap_cfs,
            "negotiation_feasible_release_cfs": certificate.feasible_release_cfs,
            "negotiation_marginal_service_efficiency": certificate.marginal_service_efficiency,
            "negotiation_limiting_factor": certificate.limiting_factor,
        }

    def supply_guarantee_active(self) -> bool:
        return bool(self.supply_guarantee_nodes) and self.supply_guarantee_fraction > 0.0

    def node_service_results(
        self,
        env: DailyReservoirEnvironment,
        date: str,
        routed_releases_cfs: dict[str, float],
        monitored_nodes: tuple[str, ...],
    ) -> dict[str, dict[str, float | str]]:
        monitored = set(monitored_nodes)
        out: dict[str, dict[str, float | str]] = {
            node_id: {
                "node_id": node_id,
                "service_type": "none",
                "demand_cfs": 0.0,
                "shortage_after_cfs": 0.0,
                "satisfaction": 1.0,
            }
            for node_id in monitored_nodes
        }
        base_arrival: dict[str, float] = defaultdict(float)
        release_arrival: dict[str, float] = defaultdict(float)
        stream_values = env.stream_flow_by_node(date)
        diversion_values = env.diversion_demand_by_node(date)
        instream_values = env.instream_demand_by_node(date)

        for node_id in env.topological_order:
            base = max(base_arrival[node_id], stream_values.get(node_id, 0.0))
            release = release_arrival[node_id] + max(0.0, routed_releases_cfs.get(node_id, 0.0))

            instream_req = instream_values.get(node_id, 0.0)
            if instream_req > 0.0:
                after = max(0.0, instream_req - base - release)
                if node_id in monitored:
                    out[node_id] = {
                        "node_id": node_id,
                        "service_type": "instream",
                        "demand_cfs": instream_req,
                        "shortage_after_cfs": after,
                        "satisfaction": max(0.0, 1.0 - safe_divide(after, instream_req)),
                    }

            diversion_req = diversion_values.get(node_id, 0.0)
            if diversion_req > 0.0:
                met_base = min(base, diversion_req)
                base -= met_base
                remaining = diversion_req - met_base
                met_release = min(release, remaining)
                release -= met_release
                after = remaining - met_release
                if node_id in monitored:
                    out[node_id] = {
                        "node_id": node_id,
                        "service_type": "diversion",
                        "demand_cfs": diversion_req,
                        "shortage_after_cfs": after,
                        "satisfaction": max(0.0, 1.0 - safe_divide(after, diversion_req)),
                    }

            for downstream in env.adj.get(node_id, []):
                base_arrival[downstream] += base
                release_arrival[downstream] += release
        return out

    def supply_guarantee_summary(
        self,
        env: DailyReservoirEnvironment,
        releases_cfs: dict[str, float],
        inflow_cfs: dict[str, float],
    ) -> dict[str, Any]:
        if not self.supply_guarantee_active():
            return {
                "demand_cfs": 0.0,
                "shortage_after_cfs": 0.0,
                "guarantee_shortfall_cfs": 0.0,
                "worst_satisfaction": 1.0,
                "below_count": 0.0,
                "details": [],
            }
        _, spill = next_storage_from_release(env, dict(env.storage_acft), inflow_cfs, releases_cfs)
        routed_releases = {
            reservoir_id: releases_cfs.get(reservoir_id, 0.0) + spill.get(reservoir_id, 0.0)
            for reservoir_id in env.reservoir_ids
        }
        node_results = self.node_service_results(
            env,
            env.current_date,
            routed_releases,
            self.supply_guarantee_nodes,
        )
        details = []
        total_demand = 0.0
        total_shortage_after = 0.0
        total_guarantee_shortfall = 0.0
        active_satisfaction = []
        below_count = 0
        allowable_shortage_fraction = 1.0 - self.supply_guarantee_fraction
        for node_id in self.supply_guarantee_nodes:
            item = node_results[node_id]
            demand = float(item["demand_cfs"])
            after = float(item["shortage_after_cfs"])
            satisfaction = float(item["satisfaction"])
            guarantee_shortfall = max(0.0, after - allowable_shortage_fraction * demand)
            if demand > 0.0:
                active_satisfaction.append(satisfaction)
                if guarantee_shortfall > 1e-9:
                    below_count += 1
            total_demand += demand
            total_shortage_after += after
            total_guarantee_shortfall += guarantee_shortfall
            details.append(
                {
                    "node_id": node_id,
                    "service_type": str(item["service_type"]),
                    "demand_cfs": demand,
                    "shortage_after_cfs": after,
                    "satisfaction": satisfaction,
                    "guarantee_shortfall_cfs": guarantee_shortfall,
                }
            )
        return {
            "demand_cfs": total_demand,
            "shortage_after_cfs": total_shortage_after,
            "guarantee_shortfall_cfs": total_guarantee_shortfall,
            "worst_satisfaction": min(active_satisfaction) if active_satisfaction else 1.0,
            "below_count": float(below_count),
            "details": details,
        }

    def available_extra_release_for_supply_cfs(
        self,
        env: DailyReservoirEnvironment,
        node_id: str,
        reservoir_id: str,
        trial_releases_cfs: dict[str, float],
        inflow_cfs: dict[str, float],
        viability_floor_acft: float,
        path_viability_floor_acft: float = 0.0,
    ) -> float:
        spec = env.reservoir_specs.get(reservoir_id)
        if spec is None:
            return 0.0
        current_release = max(0.0, trial_releases_cfs.get(reservoir_id, 0.0))
        cap_remaining = max(0.0, spec.effective_release_max_cfs - current_release)
        storage_available = max(
            0.0,
            env.storage_acft.get(reservoir_id, 0.0)
            + inflow_cfs.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT
            - current_release * CFS_DAY_TO_ACFT
            - spec.storage_min_acft,
        ) / CFS_DAY_TO_ACFT
        next_storage, _ = next_storage_from_release(
            env,
            dict(env.storage_acft),
            inflow_cfs,
            trial_releases_cfs,
        )
        if self.certificate_mode == "no_viability_boundary":
            viability_available = storage_available
        else:
            viability_available = max(
                0.0,
                sum(next_storage.values()) - viability_floor_acft,
            ) / CFS_DAY_TO_ACFT
        path_available = storage_available
        if path_viability_floor_acft > 0.0:
            path_reservoirs = self.supply_guarantee_priority_reservoirs.get(node_id, ())
            path_next_storage = sum(
                max(
                    0.0,
                    next_storage.get(path_reservoir_id, 0.0)
                    - env.reservoir_specs[path_reservoir_id].storage_min_acft,
                )
                for path_reservoir_id in path_reservoirs
                if path_reservoir_id in env.reservoir_specs
            )
            path_available = max(
                0.0,
                path_next_storage - path_viability_floor_acft,
            ) / CFS_DAY_TO_ACFT
        return min(cap_remaining, storage_available, viability_available, path_available)

    def apply_supply_reserve_guard(
        self,
        env: DailyReservoirEnvironment,
        releases_cfs: dict[str, float],
        inflow_cfs: dict[str, float],
    ) -> tuple[dict[str, float], dict[str, Any]]:
        diagnostics: dict[str, Any] = {
            "certificate_supply_reserve_guard_enabled": (
                1.0
                if self.supply_guarantee_active() and self.enable_supply_reserve_guard
                else 0.0
            ),
            "certificate_supply_reserve_guard_applied": 0.0,
            "certificate_supply_reserve_guard_reduction_cfs": 0.0,
            "certificate_supply_reserve_guard_target_release_cfs": 0.0,
            "certificate_supply_reserve_guard_mode": self.supply_reserve_guard_mode,
            "certificate_supply_reserve_guard_min_demand_cfs": self.supply_reserve_guard_min_demand_cfs,
            "certificate_supply_reserve_guard_local_storage_fraction": (
                self.supply_reserve_guard_local_storage_fraction
            ),
        }
        if (
            not self.supply_guarantee_active()
            or not self.enable_supply_reserve_guard
            or self.certificate_mode in {"mpc_only", "no_service_override"}
        ):
            return dict(releases_cfs), diagnostics

        guarded = dict(releases_cfs)
        total_reduction = 0.0
        total_target_release = 0.0
        for node_id in self.supply_guarantee_nodes:
            if not self.supply_reserve_guard_node_active(env, node_id):
                continue
            reservoirs = self.supply_guarantee_priority_reservoirs.get(node_id, ())
            if not reservoirs:
                continue
            for reservoir_id in reservoirs:
                spec = env.reservoir_specs.get(reservoir_id)
                if spec is None:
                    continue
                current_release = max(0.0, guarded.get(reservoir_id, 0.0))
                storage_plus_inflow = (
                    env.storage_acft.get(reservoir_id, 0.0)
                    + inflow_cfs.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT
                )
                target_excess_release = max(
                    0.0,
                    storage_plus_inflow - env.target_max(env.current_date, reservoir_id),
                ) / CFS_DAY_TO_ACFT
                target_excess_release = min(
                    target_excess_release,
                    spec.effective_release_max_cfs,
                    max(0.0, storage_plus_inflow - spec.storage_min_acft) / CFS_DAY_TO_ACFT,
                )
                guarded_release = min(current_release, target_excess_release)
                total_target_release += guarded_release
                total_reduction += max(0.0, current_release - guarded_release)
                guarded[reservoir_id] = guarded_release
        if total_reduction > 1e-9:
            diagnostics.update(
                {
                    "certificate_supply_reserve_guard_applied": 1.0,
                    "certificate_supply_reserve_guard_reduction_cfs": total_reduction,
                    "certificate_supply_reserve_guard_target_release_cfs": total_target_release,
                }
            )
        return guarded, diagnostics

    def supply_reserve_guard_node_active(
        self,
        env: DailyReservoirEnvironment,
        node_id: str,
    ) -> bool:
        if self.supply_reserve_guard_mode == "always":
            return True
        if (
            self.supply_reserve_guard_mode == "forecast_risk_or_local_storage"
            and self.supply_reserve_guard_local_storage_fraction > 0.0
            and self.supply_node_local_storage_fraction(env, node_id)
            <= self.supply_reserve_guard_local_storage_fraction
        ):
            return True
        end_index = min(
            len(env.forcing_dates),
            env.date_index + max(1, env.forecast_horizon_days),
        )
        for lead_index in range(env.date_index, end_index):
            date = env.forcing_dates[lead_index]
            demand = env.diversion_demand_by_node(date).get(node_id, 0.0)
            if demand < self.supply_reserve_guard_min_demand_cfs:
                continue
            natural_service = self.node_service_results(env, date, {}, (node_id,))
            item = natural_service[node_id]
            if float(item["satisfaction"]) + 1e-9 < self.supply_guarantee_fraction:
                return True
        return False

    def supply_node_local_storage_fraction(
        self,
        env: DailyReservoirEnvironment,
        node_id: str,
    ) -> float:
        reservoirs = self.supply_guarantee_priority_reservoirs.get(node_id, ())
        storage = 0.0
        capacity = 0.0
        for reservoir_id in reservoirs:
            spec = env.reservoir_specs.get(reservoir_id)
            if spec is None:
                continue
            storage += max(0.0, env.storage_acft.get(reservoir_id, 0.0) - spec.storage_min_acft)
            capacity += max(0.0, spec.storage_max_acft - spec.storage_min_acft)
        if capacity <= 0.0:
            return 1.0
        return clamp(storage / capacity, 0.0, 1.0)

    def node_service_results_for_values(
        self,
        env: DailyReservoirEnvironment,
        values: dict[str, float],
        monitored_nodes: tuple[str, ...],
    ) -> dict[str, dict[str, float | str]]:
        """Route one forecast member without reading future observed forcing."""

        monitored = set(monitored_nodes)
        out: dict[str, dict[str, float | str]] = {
            node_id: {
                "node_id": node_id,
                "service_type": "none",
                "demand_cfs": 0.0,
                "shortage_after_cfs": 0.0,
                "satisfaction": 1.0,
            }
            for node_id in monitored_nodes
        }
        base_arrival: dict[str, float] = defaultdict(float)
        stream_values = node_values(values, env.stream_columns)
        diversion_values = node_values(values, env.diversion_columns)
        instream_values = node_values(values, env.instream_columns)
        for routed_node_id in env.topological_order:
            base = max(base_arrival[routed_node_id], stream_values.get(routed_node_id, 0.0))
            instream_req = instream_values.get(routed_node_id, 0.0)
            if instream_req > 0.0 and routed_node_id in monitored:
                after = max(0.0, instream_req - base)
                out[routed_node_id] = {
                    "node_id": routed_node_id,
                    "service_type": "instream",
                    "demand_cfs": instream_req,
                    "shortage_after_cfs": after,
                    "satisfaction": max(0.0, 1.0 - safe_divide(after, instream_req)),
                }
            diversion_req = diversion_values.get(routed_node_id, 0.0)
            if diversion_req > 0.0:
                met_base = min(base, diversion_req)
                base -= met_base
                after = diversion_req - met_base
                if routed_node_id in monitored:
                    out[routed_node_id] = {
                        "node_id": routed_node_id,
                        "service_type": "diversion",
                        "demand_cfs": diversion_req,
                        "shortage_after_cfs": after,
                        "satisfaction": max(0.0, 1.0 - safe_divide(after, diversion_req)),
                    }
            for downstream in env.adj.get(routed_node_id, []):
                base_arrival[downstream] += base
        return out

    def forecast_path_net_deficit_requirements(
        self,
        env: DailyReservoirEnvironment,
        forecast: EnsembleForecast,
        node_id: str,
        reservoirs: tuple[str, ...],
    ) -> tuple[float, float]:
        scenario_requirements: list[float] = []
        allowable_shortage_fraction = 1.0 - self.supply_guarantee_fraction
        for member in forecast.members:
            cumulative = 0.0
            maximum_cumulative = 0.0
            for values in member.values_by_lead:
                item = self.node_service_results_for_values(env, values, (node_id,))[node_id]
                demand = float(item["demand_cfs"])
                shortage = float(item["shortage_after_cfs"])
                guarantee_shortfall = max(
                    0.0,
                    shortage - allowable_shortage_fraction * demand,
                )
                inflows = estimate_reservoir_inflows_from_values(env, values)
                local_inflow = sum(inflows.get(reservoir_id, 0.0) for reservoir_id in reservoirs)
                cumulative = max(
                    0.0,
                    cumulative + (guarantee_shortfall - local_inflow) * CFS_DAY_TO_ACFT,
                )
                maximum_cumulative = max(maximum_cumulative, cumulative)
            scenario_requirements.append(maximum_cumulative)
        if not scenario_requirements:
            return 0.0, 0.0
        threshold = percentile(scenario_requirements, 0.80)
        tail = [value for value in scenario_requirements if value + 1e-9 >= threshold]
        return percentile(scenario_requirements, 0.50), mean(tail) if tail else threshold

    def known_path_demand_reserve_acft(
        self,
        env: DailyReservoirEnvironment,
        node_id: str,
    ) -> float:
        end_index = min(
            len(env.forcing_dates),
            env.date_index + self.supply_path_viability_demand_lookahead_days,
        )
        scheduled_volume = 0.0
        for index in range(env.date_index, end_index):
            date = env.forcing_dates[index]
            demand = env.diversion_demand_by_node(date).get(node_id, 0.0)
            scheduled_volume += self.supply_guarantee_fraction * demand * CFS_DAY_TO_ACFT
        return self.supply_path_viability_demand_reserve_fraction * scheduled_volume

    def path_viability_boundaries(
        self,
        env: DailyReservoirEnvironment,
        forecast: EnsembleForecast,
        inflow_cfs: dict[str, float],
    ) -> tuple[dict[str, float], list[dict[str, float | str]]]:
        if self.supply_path_viability_mode == "disabled" or not self.supply_guarantee_active():
            return {}, []

        no_release_storage, _ = next_storage_from_release(
            env,
            dict(env.storage_acft),
            inflow_cfs,
            {},
        )
        floors: dict[str, float] = {}
        details: list[dict[str, float | str]] = []
        memory_decay = max(0.0, 1.0 - 1.0 / self.supply_path_viability_memory_days)
        allowable_shortage_fraction = 1.0 - self.supply_guarantee_fraction
        current_service = self.node_service_results(
            env,
            env.current_date,
            {},
            self.supply_guarantee_nodes,
        )
        for node_id in self.supply_guarantee_nodes:
            reservoirs = tuple(
                reservoir_id
                for reservoir_id in self.supply_guarantee_priority_reservoirs.get(node_id, ())
                if reservoir_id in env.reservoir_specs
            )
            capacity = sum(
                max(
                    0.0,
                    env.reservoir_specs[reservoir_id].storage_max_acft
                    - env.reservoir_specs[reservoir_id].storage_min_acft,
                )
                for reservoir_id in reservoirs
            )
            if capacity <= 0.0:
                continue
            current_storage = sum(
                max(
                    0.0,
                    env.storage_acft.get(reservoir_id, 0.0)
                    - env.reservoir_specs[reservoir_id].storage_min_acft,
                )
                for reservoir_id in reservoirs
            )
            maximum_reachable = sum(
                max(
                    0.0,
                    no_release_storage.get(reservoir_id, 0.0)
                    - env.reservoir_specs[reservoir_id].storage_min_acft,
                )
                for reservoir_id in reservoirs
            )
            service_item = current_service[node_id]
            demand = float(service_item["demand_cfs"])
            shortage = float(service_item["shortage_after_cfs"])
            guarantee_shortfall = max(
                0.0,
                shortage - allowable_shortage_fraction * demand,
            )
            local_inflow = sum(inflow_cfs.get(reservoir_id, 0.0) for reservoir_id in reservoirs)
            current_net_deficit = (guarantee_shortfall - local_inflow) * CFS_DAY_TO_ACFT
            account = self.path_viability_accounts.get(node_id, PathViabilityAccount())
            cumulative_after = max(
                0.0,
                memory_decay * account.cumulative_net_deficit_acft + current_net_deficit,
            )
            ewma_after = max(
                0.0,
                memory_decay * account.ewma_net_deficit_acft
                + (1.0 - memory_decay) * max(0.0, current_net_deficit),
            )
            memory_reserve = max(
                cumulative_after,
                self.supply_path_viability_memory_days * ewma_after,
            )
            forecast_median, forecast_cvar = self.forecast_path_net_deficit_requirements(
                env,
                forecast,
                node_id,
                reservoirs,
            )
            scheduled_reserve = self.known_path_demand_reserve_acft(env, node_id)
            requested_floor = min(
                self.supply_path_viability_max_fraction * capacity,
                self.supply_path_viability_base_fraction * capacity
                + max(
                    scheduled_reserve,
                    memory_reserve
                    + self.supply_path_viability_forecast_multiplier * forecast_cvar,
                ),
            )
            applied_floor = min(requested_floor, maximum_reachable)
            floors[node_id] = applied_floor
            details.append(
                {
                    "node_id": node_id,
                    "capacity_acft": capacity,
                    "current_storage_acft": current_storage,
                    "requested_floor_acft": requested_floor,
                    "applied_floor_acft": applied_floor,
                    "maximum_reachable_acft": maximum_reachable,
                    "scheduled_demand_reserve_acft": scheduled_reserve,
                    "forecast_median_net_deficit_acft": forecast_median,
                    "forecast_cvar_net_deficit_acft": forecast_cvar,
                    "current_net_deficit_acft": current_net_deficit,
                    "cumulative_net_deficit_before_acft": account.cumulative_net_deficit_acft,
                    "cumulative_net_deficit_after_acft": cumulative_after,
                    "ewma_net_deficit_before_acft": account.ewma_net_deficit_acft,
                    "ewma_net_deficit_after_acft": ewma_after,
                    "observations_after": float(account.observations + 1),
                }
            )
        return floors, details

    def apply_supply_path_viability_guard(
        self,
        env: DailyReservoirEnvironment,
        releases_cfs: dict[str, float],
        inflow_cfs: dict[str, float],
        floors: dict[str, float],
        boundary_details: list[dict[str, float | str]],
    ) -> tuple[dict[str, float], dict[str, Any]]:
        diagnostics: dict[str, Any] = {
            "certificate_path_viability_mode": self.supply_path_viability_mode,
            "certificate_path_viability_enabled": 1.0 if floors else 0.0,
            "certificate_path_viability_applied": 0.0,
            "certificate_path_viability_reduction_cfs": 0.0,
            "certificate_path_viability_min_margin_acft": 0.0,
            "certificate_path_viability_details_json": boundary_details,
        }
        if not floors or self.certificate_mode in {"mpc_only", "no_service_override"}:
            return dict(releases_cfs), diagnostics

        guarded = dict(releases_cfs)
        total_reduction = 0.0
        minimum_margin: float | None = None
        detail_by_node = {
            str(item.get("node_id", "")): item
            for item in boundary_details
        }
        for node_id, floor in floors.items():
            reservoirs = tuple(
                reservoir_id
                for reservoir_id in self.supply_guarantee_priority_reservoirs.get(node_id, ())
                if reservoir_id in env.reservoir_specs
            )
            if not reservoirs:
                continue
            next_storage, _ = next_storage_from_release(
                env,
                dict(env.storage_acft),
                inflow_cfs,
                guarded,
            )
            before_storage = sum(
                max(
                    0.0,
                    next_storage.get(reservoir_id, 0.0)
                    - env.reservoir_specs[reservoir_id].storage_min_acft,
                )
                for reservoir_id in reservoirs
            )
            path_releases = {
                reservoir_id: max(0.0, guarded.get(reservoir_id, 0.0))
                for reservoir_id in reservoirs
            }
            path_release = sum(path_releases.values())
            reduction = 0.0
            scale = 1.0
            if before_storage + 1e-8 < floor and path_release > 0.0:
                # Storage response is piecewise linear because reservoirs can spill or
                # reach their operating minima. Solve the terminal projection directly
                # instead of assuming that every unit of curtailed release is retained.
                lower_scale = 0.0
                upper_scale = 1.0
                for _ in range(64):
                    candidate_scale = 0.5 * (lower_scale + upper_scale)
                    candidate = dict(guarded)
                    for reservoir_id, release in path_releases.items():
                        candidate[reservoir_id] = release * candidate_scale
                    candidate_storage_state, _ = next_storage_from_release(
                        env,
                        dict(env.storage_acft),
                        inflow_cfs,
                        candidate,
                    )
                    candidate_storage = sum(
                        max(
                            0.0,
                            candidate_storage_state.get(reservoir_id, 0.0)
                            - env.reservoir_specs[reservoir_id].storage_min_acft,
                        )
                        for reservoir_id in reservoirs
                    )
                    if candidate_storage + 1e-10 >= floor:
                        lower_scale = candidate_scale
                    else:
                        upper_scale = candidate_scale
                scale = lower_scale
                for reservoir_id, release in path_releases.items():
                    guarded[reservoir_id] = release * scale
                reduction = path_release * (1.0 - scale)
                total_reduction += reduction
            after_storage_state, _ = next_storage_from_release(
                env,
                dict(env.storage_acft),
                inflow_cfs,
                guarded,
            )
            after_storage = sum(
                max(
                    0.0,
                    after_storage_state.get(reservoir_id, 0.0)
                    - env.reservoir_specs[reservoir_id].storage_min_acft,
                )
                for reservoir_id in reservoirs
            )
            margin = after_storage - floor
            if margin < -1e-6:
                raise RuntimeError(
                    f"Path viability projection failed for node {node_id}: "
                    f"margin={margin:.12f} acre-ft"
                )
            minimum_margin = margin if minimum_margin is None else min(minimum_margin, margin)
            detail = detail_by_node.get(node_id)
            if detail is not None:
                detail["selected_next_storage_before_guard_acft"] = before_storage
                detail["selected_next_storage_after_guard_acft"] = after_storage
                detail["guard_reduction_cfs"] = reduction
                detail["guard_release_scale"] = scale
                detail["floor_margin_after_guard_acft"] = margin
        diagnostics.update(
            {
                "certificate_path_viability_applied": 1.0 if total_reduction > 1e-9 else 0.0,
                "certificate_path_viability_reduction_cfs": total_reduction,
                "certificate_path_viability_min_margin_acft": minimum_margin or 0.0,
            }
        )
        return guarded, diagnostics

    def apply_supply_guarantee_certificate(
        self,
        env: DailyReservoirEnvironment,
        releases_cfs: dict[str, float],
        inflow_cfs: dict[str, float],
        viability_floor_acft: float,
        path_viability_floors_acft: dict[str, float] | None = None,
    ) -> tuple[dict[str, float], dict[str, Any]]:
        path_viability_floors_acft = path_viability_floors_acft or {}
        before = self.supply_guarantee_summary(env, releases_cfs, inflow_cfs)
        diagnostics: dict[str, Any] = {
            "certificate_supply_guarantee_enabled": 1.0 if self.supply_guarantee_active() else 0.0,
            "certificate_supply_guarantee_fraction": self.supply_guarantee_fraction,
            "certificate_supply_guarantee_nodes": ",".join(self.supply_guarantee_nodes),
            "certificate_supply_guarantee_applied": 0.0,
            "certificate_supply_guarantee_extra_release_cfs": 0.0,
            "certificate_supply_guarantee_shortfall_before_cfs": before["guarantee_shortfall_cfs"],
            "certificate_supply_guarantee_shortfall_after_cfs": before["guarantee_shortfall_cfs"],
            "certificate_supply_guarantee_worst_satisfaction_before": before["worst_satisfaction"],
            "certificate_supply_guarantee_worst_satisfaction_after": before["worst_satisfaction"],
            "certificate_supply_guarantee_nodes_below_before": before["below_count"],
            "certificate_supply_guarantee_nodes_below_after": before["below_count"],
            "certificate_supply_guarantee_node_details_json": before["details"],
        }
        if (
            not self.supply_guarantee_active()
            or self.certificate_mode in {"mpc_only", "no_service_override"}
            or before["guarantee_shortfall_cfs"] <= 1e-9
        ):
            return dict(releases_cfs), diagnostics

        trial = dict(releases_cfs)
        total_extra_release = 0.0
        for node_id in self.supply_guarantee_nodes:
            reservoirs = self.supply_guarantee_priority_reservoirs.get(node_id, ())
            if not reservoirs:
                continue
            current = self.supply_guarantee_summary(env, trial, inflow_cfs)
            node_details = {
                item["node_id"]: item
                for item in current["details"]
            }
            node_item = node_details.get(node_id)
            if node_item is None:
                continue
            node_shortfall = float(node_item["guarantee_shortfall_cfs"])
            if node_shortfall <= 1e-9:
                continue
            for reservoir_id in reservoirs:
                available = self.available_extra_release_for_supply_cfs(
                    env,
                    node_id,
                    reservoir_id,
                    trial,
                    inflow_cfs,
                    viability_floor_acft,
                    path_viability_floors_acft.get(node_id, 0.0),
                )
                if available <= 1e-9:
                    continue
                add = min(node_shortfall, available)
                trial[reservoir_id] = trial.get(reservoir_id, 0.0) + add
                total_extra_release += add
                updated = self.supply_guarantee_summary(env, trial, inflow_cfs)
                updated_details = {
                    item["node_id"]: item
                    for item in updated["details"]
                }
                node_shortfall = float(
                    updated_details.get(node_id, {}).get("guarantee_shortfall_cfs", 0.0)
                )
                if node_shortfall <= 1e-9:
                    break

        after = self.supply_guarantee_summary(env, trial, inflow_cfs)
        diagnostics.update(
            {
                "certificate_supply_guarantee_applied": 1.0 if total_extra_release > 1e-9 else 0.0,
                "certificate_supply_guarantee_extra_release_cfs": total_extra_release,
                "certificate_supply_guarantee_shortfall_after_cfs": after["guarantee_shortfall_cfs"],
                "certificate_supply_guarantee_worst_satisfaction_after": after["worst_satisfaction"],
                "certificate_supply_guarantee_nodes_below_after": after["below_count"],
                "certificate_supply_guarantee_node_details_json": after["details"],
            }
        )
        return trial, diagnostics

    def certified_current_day_choice(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast: EnsembleForecast,
        mpc_releases: dict[str, float],
        causal_anchor_releases: dict[str, float],
        negotiation: NegotiationResult | None = None,
    ) -> tuple[dict[str, float], dict[str, Any]]:
        """Arbitrate actions with topology proofs and online primal-dual debt.

        Three actions are compared: hard-floor MPC, hard-floor causal anchor,
        and the original causal service anchor. Virtual queues prevent either
        service regret or reserve violations from accumulating without bound,
        while an absolute viability floor remains non-penetrable.
        """

        current_inflows = env.estimate_reservoir_inflows_cfs(env.current_date)
        raw_anchor = env.project_releases(causal_anchor_releases, current_inflows)
        if negotiation is not None:
            reserve_floor = negotiation.final_proposal.hard_safety_floor_acft
            safe_anchor = project_releases_for_operating_floor(
                env,
                causal_anchor_releases,
                dict(env.storage_acft),
                current_inflows,
                env.current_date,
                reserve_floor,
            )
            mpc = project_releases_for_operating_floor(
                env,
                mpc_releases,
                dict(env.storage_acft),
                current_inflows,
                env.current_date,
                reserve_floor,
            )
        else:
            reserve_floor = sum(env.target_min(env.current_date, reservoir_id) for reservoir_id in env.reservoir_ids)
            safe_anchor = raw_anchor
            mpc = env.project_releases(mpc_releases, current_inflows)
        raw_anchor_cert = self.current_day_certificate(env, intent, raw_anchor, current_inflows)
        safe_anchor_cert = self.current_day_certificate(env, intent, safe_anchor, current_inflows)
        mpc_cert = self.current_day_certificate(env, intent, mpc, current_inflows)

        selected = mpc
        selected_label = "mpc"
        selected_cert = mpc_cert
        service_gap = mpc_cert["shortage_after_cfs"] - safe_anchor_cert["shortage_after_cfs"]
        storage_gain = safe_anchor_cert["target_deficit_acft"] - mpc_cert["target_deficit_acft"]
        mpc_has_storage_case = (
            storage_gain > self.certificate_storage_tolerance_acft
            and service_gap <= max(8.0, 0.015 * max(safe_anchor_cert["shortage_after_cfs"], 1.0))
        )
        if safe_anchor_cert["shortage_after_cfs"] + 1e-9 < mpc_cert["shortage_after_cfs"] and not mpc_has_storage_case:
            selected = safe_anchor
            selected_label = "causal_anchor"
            selected_cert = safe_anchor_cert
        elif abs(service_gap) <= 1e-9 and safe_anchor_cert["certificate_cost"] < mpc_cert["certificate_cost"]:
            selected = safe_anchor
            selected_label = "causal_anchor"
            selected_cert = safe_anchor_cert
        if self.certificate_mode == "mpc_only":
            selected = mpc
            selected_label = "mpc_only"
            selected_cert = mpc_cert

        total_min_storage = sum(spec.storage_min_acft for spec in env.reservoir_specs.values())
        nominal_viability_floor = total_min_storage + self.viability_floor_fraction * max(
            0.0,
            reserve_floor - total_min_storage,
        )
        no_release_storage, _ = next_storage_from_release(
            env,
            dict(env.storage_acft),
            current_inflows,
            {},
        )
        maximum_reachable_storage = sum(no_release_storage.values())
        viability_floor = (
            0.0
            if self.certificate_mode == "no_viability_boundary"
            else min(nominal_viability_floor, maximum_reachable_storage)
        )
        viability_recovery_gap = max(0.0, nominal_viability_floor - viability_floor)
        if self.certificate_mode == "no_ledger":
            service_weight = 1.0
            reserve_weight = 1.0
        else:
            service_weight = 1.0 + safe_divide(
                self.safety_ledger.service_regret_cfs_days,
                self.service_ledger_scale_cfs_days,
            )
            reserve_weight = 1.0 + safe_divide(
                self.safety_ledger.reserve_debt_acft,
                self.reserve_ledger_scale_acft,
            )
        raw_reserve_violation = max(
            0.0,
            reserve_floor - raw_anchor_cert["next_storage_total_acft"],
        )
        selected_reserve_violation = max(
            0.0,
            reserve_floor - selected_cert["next_storage_total_acft"],
        )
        selected_primal_dual_cost = (
            service_weight * selected_cert["shortage_after_cfs"]
            + reserve_weight * selected_reserve_violation / CFS_DAY_TO_ACFT
        )
        raw_primal_dual_cost = (
            service_weight * raw_anchor_cert["shortage_after_cfs"]
            + reserve_weight * raw_reserve_violation / CFS_DAY_TO_ACFT
        )
        raw_anchor_viable = (
            True
            if self.certificate_mode == "no_viability_boundary"
            else raw_anchor_cert["next_storage_total_acft"] + 1e-9 >= viability_floor
        )
        override_margin = selected_primal_dual_cost - raw_primal_dual_cost
        if (
            self.certificate_mode not in {"mpc_only", "no_service_override"}
            and
            raw_anchor_viable
            and raw_anchor_cert["shortage_after_cfs"] + 1e-9 < selected_cert["shortage_after_cfs"]
            and override_margin > 0.0
        ):
            selected = raw_anchor
            selected_label = "service_override"
            selected_cert = raw_anchor_cert
            self.safety_ledger.service_override_days += 1

        reserve_guarded, reserve_guard_certificate = self.apply_supply_reserve_guard(
            env,
            selected,
            current_inflows,
        )
        if reserve_guard_certificate["certificate_supply_reserve_guard_applied"] > 0.5:
            selected = reserve_guarded
            selected_label = "supply_reserve_guard"
            selected_cert = self.current_day_certificate(env, intent, selected, current_inflows)

        path_viability_floors, path_boundary_details = self.path_viability_boundaries(
            env,
            forecast,
            current_inflows,
        )
        path_guarded, path_viability_certificate = self.apply_supply_path_viability_guard(
            env,
            selected,
            current_inflows,
            path_viability_floors,
            path_boundary_details,
        )
        if path_viability_certificate["certificate_path_viability_applied"] > 0.5:
            selected = path_guarded
            selected_label = "path_viability_guard"
            selected_cert = self.current_day_certificate(env, intent, selected, current_inflows)

        pre_supply_selected_label = selected_label
        supply_adjusted, supply_certificate = self.apply_supply_guarantee_certificate(
            env,
            selected,
            current_inflows,
            viability_floor,
            path_viability_floors,
        )
        if supply_certificate["certificate_supply_guarantee_applied"] > 0.5:
            selected = supply_adjusted
            selected_label = "supply_guarantee_override"
            selected_cert = self.current_day_certificate(env, intent, selected, current_inflows)

        if path_viability_floors and self.certificate_mode not in {"mpc_only", "no_service_override"}:
            final_path_storage_state, _ = next_storage_from_release(
                env,
                dict(env.storage_acft),
                current_inflows,
                selected,
            )
            final_path_margins = []
            path_detail_by_node = {
                str(item.get("node_id", "")): item
                for item in path_boundary_details
            }
            for node_id, floor in path_viability_floors.items():
                reservoirs = tuple(
                    reservoir_id
                    for reservoir_id in self.supply_guarantee_priority_reservoirs.get(node_id, ())
                    if reservoir_id in env.reservoir_specs
                )
                final_path_storage = sum(
                    max(
                        0.0,
                        final_path_storage_state.get(reservoir_id, 0.0)
                        - env.reservoir_specs[reservoir_id].storage_min_acft,
                    )
                    for reservoir_id in reservoirs
                )
                final_margin = final_path_storage - floor
                if final_margin < -1e-6:
                    raise RuntimeError(
                        f"Supply guarantee penetrated the path viability floor for node {node_id}: "
                        f"margin={final_margin:.12f} acre-ft"
                    )
                final_path_margins.append(final_margin)
                detail = path_detail_by_node.get(node_id)
                if detail is not None:
                    detail["selected_next_storage_final_acft"] = final_path_storage
                    detail["final_floor_margin_acft"] = final_margin
            path_viability_certificate["certificate_path_viability_min_margin_acft"] = (
                min(final_path_margins) if final_path_margins else 0.0
            )

        service_regret = max(
            0.0,
            selected_cert["shortage_after_cfs"] - raw_anchor_cert["shortage_after_cfs"],
        )
        reserve_violation = max(
            0.0,
            reserve_floor - selected_cert["next_storage_total_acft"],
        )
        reserve_surplus = max(
            0.0,
            selected_cert["next_storage_total_acft"] - reserve_floor,
        )
        service_debt_before = self.safety_ledger.service_regret_cfs_days
        reserve_debt_before = self.safety_ledger.reserve_debt_acft
        previous_reserve_violation = self.safety_ledger.last_reserve_violation_acft
        reserve_borrowing = max(0.0, reserve_violation - previous_reserve_violation)
        reserve_gap_repayment = max(0.0, previous_reserve_violation - reserve_violation)
        requested_repayment = reserve_gap_repayment + self.reserve_repayment_fraction * reserve_surplus
        if self.certificate_mode in {"mpc_only", "no_ledger"}:
            reserve_repayment = 0.0
        else:
            self.safety_ledger.service_regret_cfs_days = max(
                0.0,
                self.ledger_decay * service_debt_before + service_regret,
            )
            reserve_debt_before_repayment = self.ledger_decay * reserve_debt_before + reserve_borrowing
            reserve_repayment = min(reserve_debt_before_repayment, requested_repayment)
            self.safety_ledger.reserve_debt_acft = max(0.0, reserve_debt_before_repayment - reserve_repayment)
            self.safety_ledger.last_reserve_violation_acft = reserve_violation

        certificate = {
            "certificate_mode": self.certificate_mode,
            "certificate_selected_action": selected_label,
            "certificate_pre_supply_selected_action": pre_supply_selected_label,
            "certificate_mpc_shortage_after_cfs": mpc_cert["shortage_after_cfs"],
            "certificate_anchor_shortage_after_cfs": safe_anchor_cert["shortage_after_cfs"],
            "certificate_raw_anchor_shortage_after_cfs": raw_anchor_cert["shortage_after_cfs"],
            "certificate_mpc_target_deficit_acft": mpc_cert["target_deficit_acft"],
            "certificate_anchor_target_deficit_acft": safe_anchor_cert["target_deficit_acft"],
            "certificate_mpc_release_cfs": mpc_cert["release_cfs"],
            "certificate_anchor_release_cfs": safe_anchor_cert["release_cfs"],
            "certificate_service_gap_cfs": service_gap,
            "certificate_storage_gain_acft": storage_gain,
            "certificate_selected_shortage_after_cfs": selected_cert["shortage_after_cfs"],
            "certificate_selected_next_storage_acft": selected_cert["next_storage_total_acft"],
            "certificate_hard_reserve_floor_acft": reserve_floor,
            "certificate_nominal_viability_floor_acft": nominal_viability_floor,
            "certificate_viability_floor_acft": viability_floor,
            "certificate_viability_recovery_gap_acft": viability_recovery_gap,
            "certificate_maximum_reachable_storage_acft": maximum_reachable_storage,
            "certificate_raw_anchor_viable": 1.0 if raw_anchor_viable else 0.0,
            "certificate_service_regret_cfs": service_regret,
            "certificate_reserve_violation_acft": reserve_violation,
            "certificate_reserve_borrowing_acft": reserve_borrowing,
            "certificate_reserve_repayment_acft": reserve_repayment,
            "certificate_service_ledger_before": service_debt_before,
            "certificate_service_ledger_after": self.safety_ledger.service_regret_cfs_days,
            "certificate_reserve_ledger_before": reserve_debt_before,
            "certificate_reserve_ledger_after": self.safety_ledger.reserve_debt_acft,
            "certificate_service_dual_weight": service_weight,
            "certificate_reserve_dual_weight": reserve_weight,
            "certificate_override_margin": override_margin,
            "certificate_service_override_days": float(self.safety_ledger.service_override_days),
            **reserve_guard_certificate,
            **path_viability_certificate,
            **supply_certificate,
        }
        return selected, certificate

    def current_day_certificate(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        releases_cfs: dict[str, float],
        inflow_cfs: dict[str, float],
    ) -> dict[str, float]:
        next_storage, spill = next_storage_from_release(env, dict(env.storage_acft), inflow_cfs, releases_cfs)
        routed_releases = {
            reservoir_id: releases_cfs.get(reservoir_id, 0.0) + spill.get(reservoir_id, 0.0)
            for reservoir_id in env.reservoir_ids
        }
        routing = env.route(env.current_date, routed_releases)
        weights = intent_weights(intent.primary_intent)
        target_deficit = 0.0
        target_excess = 0.0
        depletion = 0.0
        for reservoir_id, spec in env.reservoir_specs.items():
            storage = next_storage[reservoir_id]
            target_deficit += max(0.0, env.target_min(env.current_date, reservoir_id) - storage)
            target_excess += max(0.0, storage - env.target_max(env.current_date, reservoir_id))
            depletion += max(0.0, 0.25 * spec.storage_max_acft - storage)
        release_total = sum(releases_cfs.values())
        supply_summary = self.supply_guarantee_summary(env, releases_cfs, inflow_cfs)
        cost = (
            weights["shortage"] * routing["diversion_shortage_after_release_cfs"]
            + weights["ecology"] * routing["instream_shortage_after_release_cfs"]
            + 3.0 * supply_summary["guarantee_shortfall_cfs"]
            + weights["target_deficit"] * target_deficit / 1000.0
            + weights["target_excess"] * target_excess / 1000.0
            + weights["depletion"] * depletion / 1000.0
            + weights["release"] * release_total
            + weights["spill"] * sum(spill.values())
        )
        return {
            "shortage_after_cfs": routing["total_shortage_after_release_cfs"],
            "diversion_shortage_after_cfs": routing["diversion_shortage_after_release_cfs"],
            "instream_shortage_after_cfs": routing["instream_shortage_after_release_cfs"],
            "target_deficit_acft": target_deficit,
            "target_excess_acft": target_excess,
            "next_storage_total_acft": sum(next_storage.values()),
            "release_cfs": release_total,
            "supply_guarantee_demand_cfs": supply_summary["demand_cfs"],
            "supply_guarantee_shortage_after_cfs": supply_summary["shortage_after_cfs"],
            "supply_guarantee_shortfall_cfs": supply_summary["guarantee_shortfall_cfs"],
            "supply_guarantee_worst_satisfaction": supply_summary["worst_satisfaction"],
            "supply_guarantee_nodes_below": supply_summary["below_count"],
            "certificate_cost": cost,
        }

    def evaluate_candidate(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast: EnsembleForecast,
        candidate: PolicyCandidate,
        negotiation: NegotiationResult | None = None,
        deliberation: SkillDeliberationResult | None = None,
    ) -> CandidateEvaluation:
        member_costs = []
        member_shortages = []
        member_terminal_deficits = []
        member_releases = []
        current_values = env.forcing_row(env.current_date)
        current_influence = self.release_influence(env)
        first_day_releases = self.policy_release_for_values(
            env=env,
            intent=intent,
            candidate=candidate,
            date=env.current_date,
            values=current_values,
            storage_acft=dict(env.storage_acft),
            previous_releases_cfs={reservoir_id: 0.0 for reservoir_id in env.reservoir_ids},
            negotiation=negotiation,
            deliberation=deliberation,
        )
        for member in forecast.members:
            result = self.simulate_member_fast(
                env,
                intent,
                forecast,
                candidate,
                member,
                first_day_releases,
                current_influence,
                negotiation,
                deliberation,
            )
            member_costs.append(result["cost"])
            member_shortages.append(result["mean_shortage_cfs"])
            member_terminal_deficits.append(result["terminal_deficit_acft"])
            member_releases.append(result["mean_release_cfs"])
        mean_cost = mean(member_costs) if member_costs else 0.0
        cvar_cost = tail_mean(member_costs, self.cvar_quantile)
        worst_cost = max(member_costs) if member_costs else 0.0
        robust_cost = mean_cost + self.risk_weight * cvar_cost + self.worst_weight * worst_cost
        return CandidateEvaluation(
            candidate=candidate,
            mean_cost=mean_cost,
            cvar_cost=cvar_cost,
            worst_cost=worst_cost,
            robust_cost=robust_cost,
            mean_shortage_cfs=mean(member_shortages) if member_shortages else 0.0,
            mean_terminal_deficit_acft=mean(member_terminal_deficits) if member_terminal_deficits else 0.0,
            mean_release_cfs=mean(member_releases) if member_releases else 0.0,
        )

    def simulate_member_fast(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast: EnsembleForecast,
        candidate: PolicyCandidate,
        member: ForecastMember,
        first_day_releases: dict[str, float],
        influence: dict[str, float],
        negotiation: NegotiationResult | None = None,
        deliberation: SkillDeliberationResult | None = None,
    ) -> dict[str, float]:
        horizon = max(1, forecast.horizon_days)
        stream_total = 0.0
        diversion_total = 0.0
        instream_total = 0.0
        inflow_totals = {reservoir_id: 0.0 for reservoir_id in env.reservoir_ids}
        grouped_capacity = capacity_by_proxy(env)

        for values in member.values_by_lead:
            stream_total += sum(values.get(column, 0.0) for column in env.stream_columns)
            diversion_total += sum(values.get(column, 0.0) for column in env.diversion_columns)
            instream_total += sum(values.get(column, 0.0) for column in env.instream_columns)
            stream_by_node = node_values(values, env.stream_columns)
            for reservoir_id, mapping in env.inflow_proxy.items():
                proxy_node = str(mapping["proxy_node_id"])
                spec = env.reservoir_specs[reservoir_id]
                share = safe_divide(spec.storage_max_acft, grouped_capacity.get(proxy_node, 0.0))
                inflow_totals[reservoir_id] += stream_by_node.get(proxy_node, 0.0) * share * env.inflow_capture_factor

        effective_release_total = horizon * sum(
            first_day_releases.get(reservoir_id, 0.0) * influence.get(reservoir_id, 0.0)
            for reservoir_id in env.reservoir_ids
        )
        instream_shortage_before = max(0.0, instream_total - 0.18 * stream_total)
        instream_relief = min(instream_shortage_before, 0.35 * effective_release_total)
        diversion_shortage_before = max(0.0, diversion_total + max(0.0, instream_total - instream_shortage_before) - stream_total)
        diversion_relief = min(diversion_shortage_before, max(0.0, effective_release_total - instream_relief))
        instream_after = instream_shortage_before - instream_relief
        diversion_after = diversion_shortage_before - diversion_relief
        terminal_date = env.forcing_dates[min(len(env.forcing_dates) - 1, env.date_index + horizon - 1)]
        terminal_deficit = 0.0
        terminal_excess = 0.0
        depletion = 0.0
        terminal_storage_total = 0.0
        for reservoir_id, spec in env.reservoir_specs.items():
            terminal_storage = (
                env.storage_acft.get(reservoir_id, 0.0)
                + inflow_totals[reservoir_id] * CFS_DAY_TO_ACFT
                - first_day_releases.get(reservoir_id, 0.0) * horizon * CFS_DAY_TO_ACFT
            )
            terminal_storage_total += terminal_storage
            terminal_deficit += max(0.0, env.target_min(terminal_date, reservoir_id) - terminal_storage)
            terminal_excess += max(0.0, terminal_storage - env.target_max(terminal_date, reservoir_id))
            depletion += max(0.0, 0.25 * spec.storage_max_acft - terminal_storage)

        weights = intent_weights(self.planning_primary_intent(intent, negotiation, deliberation))
        if negotiation is not None:
            weights = self.negotiated_objective_weights(weights, negotiation)
        if deliberation is not None:
            weights = self.deliberated_objective_weights(weights, deliberation)
        strategic_reserve_deficit = 0.0
        if negotiation is not None:
            ledger_recovery = self.ledger_recovery_fraction * self.safety_ledger.reserve_debt_acft
            strategic_reserve_deficit = max(
                0.0,
                negotiation.final_proposal.reserve_floor_acft + ledger_recovery - terminal_storage_total,
            )
        release_total = horizon * sum(first_day_releases.values())
        shortage_after = diversion_after + instream_after
        cost = (
            weights["shortage"] * diversion_after / horizon
            + weights["ecology"] * instream_after / horizon
            + weights["target_deficit"] * terminal_deficit / 1000.0
            + weights["target_excess"] * terminal_excess / 1000.0
            + weights["depletion"] * depletion / 1000.0
            + self.strategic_reserve_weight * weights["target_deficit"] * strategic_reserve_deficit / 1000.0
            + weights["release"] * release_total / horizon
        )
        return {
            "cost": cost,
            "mean_shortage_cfs": shortage_after / horizon,
            "terminal_deficit_acft": terminal_deficit + strategic_reserve_deficit,
            "mean_release_cfs": release_total / horizon,
        }

    def simulate_member(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        forecast: EnsembleForecast,
        candidate: PolicyCandidate,
        member: ForecastMember,
        negotiation: NegotiationResult | None = None,
        deliberation: SkillDeliberationResult | None = None,
    ) -> dict[str, float]:
        storage = dict(env.storage_acft)
        previous_releases = {reservoir_id: 0.0 for reservoir_id in env.reservoir_ids}
        total_cost = 0.0
        total_shortage = 0.0
        total_release = 0.0
        horizon = max(1, forecast.horizon_days)

        for lead, values in enumerate(member.values_by_lead):
            lead_index = min(len(env.forcing_dates) - 1, env.date_index + lead)
            lead_date = env.forcing_dates[lead_index]
            releases = self.policy_release_for_values(
                env=env,
                intent=intent,
                candidate=candidate,
                date=lead_date,
                values=values,
                storage_acft=storage,
                previous_releases_cfs=previous_releases,
                negotiation=negotiation,
                deliberation=deliberation,
            )
            routing = aggregate_route_surrogate(env, values, releases, self.release_influence(env))
            inflows = estimate_reservoir_inflows_from_values(env, values)
            next_storage, spill = next_storage_from_release(env, storage, inflows, releases)
            lead_cost = self.objective_cost(
                env=env,
                intent=intent,
                candidate=candidate,
                date=lead_date,
                storage_acft=storage,
                next_storage_acft=next_storage,
                releases_cfs=releases,
                previous_releases_cfs=previous_releases,
                routing=routing,
                spill_cfs=spill,
            )
            total_cost += (self.discount ** lead) * lead_cost
            total_shortage += routing["total_shortage_after_release_cfs"]
            total_release += sum(releases.values())
            storage = next_storage
            previous_releases = releases

        terminal_deficit = terminal_storage_deficit(env, storage, env.forcing_dates[min(len(env.forcing_dates) - 1, env.date_index + horizon - 1)])
        if negotiation is not None:
            ledger_recovery = self.ledger_recovery_fraction * self.safety_ledger.reserve_debt_acft
            terminal_deficit += max(
                0.0,
                negotiation.final_proposal.reserve_floor_acft + ledger_recovery - sum(storage.values()),
            )
        total_cost += terminal_deficit * self.intent_terminal_weight(self.planning_primary_intent(intent, negotiation, deliberation))
        return {
            "cost": total_cost,
            "mean_shortage_cfs": total_shortage / horizon,
            "terminal_deficit_acft": terminal_deficit,
            "mean_release_cfs": total_release / horizon,
        }

    def policy_release_for_values(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        candidate: PolicyCandidate,
        date: str,
        values: dict[str, float],
        storage_acft: dict[str, float],
        previous_releases_cfs: dict[str, float],
        negotiation: NegotiationResult | None = None,
        deliberation: SkillDeliberationResult | None = None,
    ) -> dict[str, float]:
        inflows = estimate_reservoir_inflows_from_values(env, values)
        pressure = aggregate_pressure(values, env)
        shortage_support = pressure["total_shortage_before_release_cfs"]
        ecology_support = pressure["instream_shortage_before_release_cfs"]
        total_surplus = 0.0
        surplus_by_reservoir: dict[str, float] = {}
        raw_request: dict[str, float] = {}

        for reservoir_id, spec in env.reservoir_specs.items():
            storage = storage_acft.get(reservoir_id, 0.0)
            inflow_acft = inflows.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT
            target_min = env.target_min(date, reservoir_id)
            target_max = env.target_max(date, reservoir_id)
            surplus = max(0.0, storage + inflow_acft - target_min)
            surplus_by_reservoir[reservoir_id] = surplus
            total_surplus += surplus
            target_tracking = max(0.0, storage + inflow_acft - target_max) / CFS_DAY_TO_ACFT
            buffer_release = max(0.0, storage + 1.5 * inflow_acft - target_max) / CFS_DAY_TO_ACFT
            conserve_penalty = 0.0
            planning_intent = self.planning_primary_intent(intent, negotiation, deliberation)
            if planning_intent in {"conserve_storage", "recover_targets"}:
                conserve_penalty = candidate.conservation_weight * target_tracking
            raw_request[reservoir_id] = max(
                0.0,
                candidate.target_tracking_weight * target_tracking
                + candidate.buffer_weight * buffer_release
                - conserve_penalty,
            )

        planning_intent = self.planning_primary_intent(intent, negotiation, deliberation)
        support_budget = self.intent_support_budget(planning_intent, shortage_support, ecology_support)
        support_budget = self.negotiated_support_budget(planning_intent, support_budget, negotiation)
        support_budget *= candidate.support_weight
        if support_budget > 0.0 and total_surplus > 0.0:
            for reservoir_id, surplus in surplus_by_reservoir.items():
                raw_request[reservoir_id] += support_budget * safe_divide(surplus, total_surplus)

        smoothed_request = {}
        for reservoir_id, requested in raw_request.items():
            previous = previous_releases_cfs.get(reservoir_id, requested)
            smoothed_request[reservoir_id] = (
                candidate.smoothness_weight * previous
                + (1.0 - candidate.smoothness_weight) * requested
            )
        if negotiation is not None:
            return project_releases_for_operating_floor(
                env,
                smoothed_request,
                storage_acft,
                inflows,
                date,
                negotiation.final_proposal.hard_safety_floor_acft,
            )
        return project_releases_for_storage(env, smoothed_request, storage_acft, inflows)

    def negotiated_support_budget(
        self,
        primary_intent: str,
        base_budget_cfs: float,
        negotiation: NegotiationResult | None,
    ) -> float:
        if negotiation is None:
            return base_budget_cfs
        negotiated = negotiation.final_proposal.requested_support_cfs
        if negotiated <= 0.0:
            return base_budget_cfs
        if primary_intent in {"support_downstream_demands", "support_ecology"}:
            return max(0.45 * base_budget_cfs, negotiated)
        if primary_intent == "balanced":
            return max(base_budget_cfs, 0.75 * negotiated)
        if primary_intent == "pre_release_buffer":
            return max(base_budget_cfs, 0.35 * negotiated)
        return min(base_budget_cfs, negotiated)

    def negotiated_objective_weights(
        self,
        weights: dict[str, float],
        negotiation: NegotiationResult,
    ) -> dict[str, float]:
        adjusted = dict(weights)
        risk = negotiation.final_proposal.risk_aversion
        if negotiation.final_proposal.primary_intent == "support_downstream_demands":
            adjusted["shortage"] *= 1.0 + 0.20 * risk
        elif negotiation.final_proposal.primary_intent == "support_ecology":
            adjusted["ecology"] *= 1.0 + 0.20 * risk
        elif negotiation.final_proposal.primary_intent == "pre_release_buffer":
            adjusted["target_excess"] *= 1.0 + 0.18 * risk
            adjusted["spill"] *= 1.0 + 0.18 * risk
        elif negotiation.final_proposal.primary_intent in {"conserve_storage", "recover_targets"}:
            adjusted["depletion"] *= 1.0 + 0.20 * risk
            adjusted["target_deficit"] *= 1.0 + 0.20 * risk
        return adjusted

    def deliberated_objective_weights(
        self,
        weights: dict[str, float],
        deliberation: SkillDeliberationResult,
    ) -> dict[str, float]:
        adjusted = dict(weights)
        risk_delta = deliberation.risk_aversion_delta
        if deliberation.dominant_intent == "support_downstream_demands":
            adjusted["shortage"] *= 1.0 + 0.18 * deliberation.support_budget_multiplier
        elif deliberation.dominant_intent == "support_ecology":
            adjusted["ecology"] *= 1.0 + 0.18 * deliberation.support_budget_multiplier
        elif deliberation.dominant_intent == "pre_release_buffer":
            adjusted["target_excess"] *= deliberation.buffer_budget_multiplier
            adjusted["spill"] *= deliberation.buffer_budget_multiplier
        elif deliberation.dominant_intent in {"conserve_storage", "recover_targets"}:
            adjusted["target_deficit"] *= 1.0 + 0.35 * risk_delta
            adjusted["depletion"] *= 1.0 + 0.35 * risk_delta
            adjusted["release"] *= 1.0 + 0.15 * risk_delta
        if deliberation.conflict_count > 0:
            adjusted["ramp"] *= 1.0 + 0.04 * min(5, deliberation.conflict_count)
        return adjusted

    def objective_cost(
        self,
        env: DailyReservoirEnvironment,
        intent: CausalIntent,
        candidate: PolicyCandidate,
        date: str,
        storage_acft: dict[str, float],
        next_storage_acft: dict[str, float],
        releases_cfs: dict[str, float],
        previous_releases_cfs: dict[str, float],
        routing: dict[str, float],
        spill_cfs: dict[str, float],
    ) -> float:
        weights = intent_weights(intent.primary_intent)
        shortage = routing["diversion_shortage_after_release_cfs"]
        ecology = routing["instream_shortage_after_release_cfs"]
        target_deficit = 0.0
        target_excess = 0.0
        storage_depletion = 0.0
        for reservoir_id, spec in env.reservoir_specs.items():
            storage = next_storage_acft[reservoir_id]
            target_min = env.target_min(date, reservoir_id)
            target_max = env.target_max(date, reservoir_id)
            target_deficit += max(0.0, target_min - storage)
            target_excess += max(0.0, storage - target_max)
            storage_depletion += max(0.0, 0.25 * spec.storage_max_acft - storage)
        total_release = sum(releases_cfs.values())
        total_spill = sum(spill_cfs.values())
        ramp = sum(abs(releases_cfs.get(rid, 0.0) - previous_releases_cfs.get(rid, 0.0)) for rid in env.reservoir_ids)
        return (
            weights["shortage"] * shortage
            + weights["ecology"] * ecology
            + weights["target_deficit"] * target_deficit / 1000.0
            + weights["target_excess"] * target_excess / 1000.0
            + weights["depletion"] * storage_depletion / 1000.0
            + weights["release"] * total_release
            + weights["spill"] * total_spill
            + weights["ramp"] * ramp
        )

    def intent_candidates(self, primary_intent: str) -> list[PolicyCandidate]:
        if primary_intent == "support_downstream_demands":
            support = [0.70, 0.95, 1.20]
            target = [0.85, 1.10]
            buffer = [0.0]
        elif primary_intent == "support_ecology":
            support = [0.60, 0.90, 1.20]
            target = [0.70, 1.00]
            buffer = [0.0]
        elif primary_intent == "pre_release_buffer":
            support = [0.20, 0.40]
            target = [0.95, 1.20]
            buffer = [0.55, 0.95]
        elif primary_intent in {"conserve_storage", "recover_targets"}:
            support = [0.0, 0.20]
            target = [0.15, 0.40]
            buffer = [0.0]
        else:
            support = [0.25, 0.45, 0.65]
            target = [0.55, 0.85]
            buffer = [0.0]

        candidates: list[PolicyCandidate] = []
        for support_weight in support:
            for target_weight in target:
                for buffer_weight in buffer:
                    candidate_id = f"{primary_intent}:t{target_weight:.2f}:s{support_weight:.2f}:b{buffer_weight:.2f}"
                    candidates.append(
                        PolicyCandidate(
                            candidate_id=candidate_id,
                            target_tracking_weight=target_weight,
                            support_weight=support_weight,
                            buffer_weight=buffer_weight,
                            conservation_weight=0.65 if primary_intent in {"conserve_storage", "recover_targets"} else 0.0,
                            smoothness_weight=0.18,
                        )
                    )
        return candidates

    def release_influence(self, env: DailyReservoirEnvironment) -> dict[str, float]:
        cache_key = id(env)
        cached = self._influence_cache.get(cache_key)
        if cached is not None:
            return cached
        influence = compute_release_influence(env)
        self._influence_cache[cache_key] = influence
        return influence

    def intent_support_budget(self, primary_intent: str, shortage_support: float, ecology_support: float) -> float:
        if primary_intent == "support_downstream_demands":
            return shortage_support
        if primary_intent == "support_ecology":
            return max(ecology_support, 0.45 * shortage_support)
        if primary_intent == "balanced":
            return 0.40 * shortage_support
        if primary_intent == "pre_release_buffer":
            return 0.20 * shortage_support
        return 0.10 * shortage_support

    def intent_terminal_weight(self, primary_intent: str) -> float:
        if primary_intent in {"conserve_storage", "recover_targets"}:
            return 0.020
        if primary_intent == "pre_release_buffer":
            return 0.004
        return 0.010


def route_with_values(
    env: DailyReservoirEnvironment,
    values: dict[str, float],
    releases_cfs: dict[str, float],
) -> dict[str, float]:
    base_arrival: dict[str, float] = {node_id: 0.0 for node_id in env.topological_order}
    release_arrival: dict[str, float] = {node_id: 0.0 for node_id in env.topological_order}
    stream_values = node_values(values, env.stream_columns)
    diversion_values = node_values(values, env.diversion_columns)
    instream_values = node_values(values, env.instream_columns)

    diversion_shortage_before = 0.0
    diversion_shortage_after = 0.0
    instream_shortage_before = 0.0
    instream_shortage_after = 0.0
    diversion_demand = 0.0
    instream_demand = 0.0

    for node_id in env.topological_order:
        base = max(base_arrival.get(node_id, 0.0), stream_values.get(node_id, 0.0))
        release = release_arrival.get(node_id, 0.0) + max(0.0, releases_cfs.get(node_id, 0.0))
        instream_req = instream_values.get(node_id, 0.0)
        if instream_req > 0:
            instream_demand += instream_req
            instream_shortage_before += max(0.0, instream_req - base)
            instream_shortage_after += max(0.0, instream_req - base - release)
        diversion_req = diversion_values.get(node_id, 0.0)
        if diversion_req > 0:
            diversion_demand += diversion_req
            met_base = min(base, diversion_req)
            base -= met_base
            residual = diversion_req - met_base
            diversion_shortage_before += residual
            met_release = min(release, residual)
            release -= met_release
            diversion_shortage_after += residual - met_release
        for downstream in env.adj.get(node_id, []):
            base_arrival[downstream] = base_arrival.get(downstream, 0.0) + base
            release_arrival[downstream] = release_arrival.get(downstream, 0.0) + release

    outlet_nodes = [row["node_id"] for row in env.nodes if row["is_outlet"] == "True"]
    return {
        "total_stream_base_cfs": sum(stream_values.values()),
        "total_diversion_demand_cfs": diversion_demand,
        "total_instream_demand_cfs": instream_demand,
        "diversion_shortage_before_release_cfs": diversion_shortage_before,
        "diversion_shortage_after_release_cfs": diversion_shortage_after,
        "instream_shortage_before_release_cfs": instream_shortage_before,
        "instream_shortage_after_release_cfs": instream_shortage_after,
        "total_shortage_before_release_cfs": diversion_shortage_before + instream_shortage_before,
        "total_shortage_after_release_cfs": diversion_shortage_after + instream_shortage_after,
        "baseflow_at_outlet_cfs": sum(base_arrival.get(node, 0.0) for node in outlet_nodes),
        "release_at_outlet_cfs": sum(release_arrival.get(node, 0.0) for node in outlet_nodes),
    }


def aggregate_route_surrogate(
    env: DailyReservoirEnvironment,
    values: dict[str, float],
    releases_cfs: dict[str, float],
    influence: dict[str, float],
) -> dict[str, float]:
    pressure = aggregate_pressure(values, env)
    effective_release = sum(max(0.0, releases_cfs.get(reservoir_id, 0.0)) * influence.get(reservoir_id, 0.0) for reservoir_id in env.reservoir_ids)
    instream_relief = min(pressure["instream_shortage_before_release_cfs"], 0.35 * effective_release)
    remaining_release = max(0.0, effective_release - instream_relief)
    diversion_relief = min(pressure["diversion_shortage_before_release_cfs"], remaining_release)
    instream_after = pressure["instream_shortage_before_release_cfs"] - instream_relief
    diversion_after = pressure["diversion_shortage_before_release_cfs"] - diversion_relief
    return {
        **pressure,
        "diversion_shortage_after_release_cfs": diversion_after,
        "instream_shortage_after_release_cfs": instream_after,
        "total_shortage_after_release_cfs": diversion_after + instream_after,
        "baseflow_at_outlet_cfs": pressure["total_stream_base_cfs"],
        "release_at_outlet_cfs": effective_release,
    }


def aggregate_pressure(values: dict[str, float], env: DailyReservoirEnvironment) -> dict[str, float]:
    stream = sum(values.get(column, 0.0) for column in env.stream_columns)
    diversion = sum(values.get(column, 0.0) for column in env.diversion_columns)
    instream = sum(values.get(column, 0.0) for column in env.instream_columns)
    instream_shortage = max(0.0, instream - 0.18 * stream)
    diversion_shortage = max(0.0, diversion + max(0.0, instream - instream_shortage) - stream)
    total_shortage = diversion_shortage + instream_shortage
    return {
        "total_stream_base_cfs": stream,
        "total_diversion_demand_cfs": diversion,
        "total_instream_demand_cfs": instream,
        "diversion_shortage_before_release_cfs": diversion_shortage,
        "instream_shortage_before_release_cfs": instream_shortage,
        "total_shortage_before_release_cfs": total_shortage,
    }


def estimate_reservoir_inflows_from_values(
    env: DailyReservoirEnvironment,
    values: dict[str, float],
) -> dict[str, float]:
    stream = node_values(values, env.stream_columns)
    grouped_capacity = capacity_by_proxy(env)
    inflows = {}
    for reservoir_id, mapping in env.inflow_proxy.items():
        proxy_node = str(mapping["proxy_node_id"])
        spec = env.reservoir_specs[reservoir_id]
        share = safe_divide(spec.storage_max_acft, grouped_capacity.get(proxy_node, 0.0))
        inflows[reservoir_id] = stream.get(proxy_node, 0.0) * share * env.inflow_capture_factor
    return inflows


def capacity_by_proxy(env: DailyReservoirEnvironment) -> dict[str, float]:
    grouped_capacity: dict[str, float] = {}
    for reservoir_id, mapping in env.inflow_proxy.items():
        proxy_node = str(mapping["proxy_node_id"])
        grouped_capacity[proxy_node] = grouped_capacity.get(proxy_node, 0.0) + env.reservoir_specs[reservoir_id].storage_max_acft
    return grouped_capacity


def project_releases_for_storage(
    env: DailyReservoirEnvironment,
    releases_cfs: dict[str, float],
    storage_acft: dict[str, float],
    inflow_cfs: dict[str, float],
) -> dict[str, float]:
    projected = {}
    for reservoir_id, spec in env.reservoir_specs.items():
        requested = max(0.0, releases_cfs.get(reservoir_id, 0.0))
        available_cfs = max(
            0.0,
            storage_acft.get(reservoir_id, 0.0)
            + inflow_cfs.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT
            - spec.storage_min_acft,
        ) / CFS_DAY_TO_ACFT
        projected[reservoir_id] = min(requested, spec.effective_release_max_cfs, available_cfs)
    return projected


def project_releases_for_operating_floor(
    env: DailyReservoirEnvironment,
    releases_cfs: dict[str, float],
    storage_acft: dict[str, float],
    inflow_cfs: dict[str, float],
    date: str,
    basin_reserve_floor_acft: float,
) -> dict[str, float]:
    floors = operating_floor_by_reservoir(env, storage_acft, inflow_cfs, date, basin_reserve_floor_acft)
    projected = {}
    for reservoir_id, spec in env.reservoir_specs.items():
        requested = max(0.0, releases_cfs.get(reservoir_id, 0.0))
        available_cfs = max(
            0.0,
            storage_acft.get(reservoir_id, 0.0)
            + inflow_cfs.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT
            - floors.get(reservoir_id, spec.storage_min_acft),
        ) / CFS_DAY_TO_ACFT
        projected[reservoir_id] = min(requested, spec.effective_release_max_cfs, available_cfs)
    return projected


def operating_floor_by_reservoir(
    env: DailyReservoirEnvironment,
    storage_acft: dict[str, float],
    inflow_cfs: dict[str, float],
    date: str,
    basin_reserve_floor_acft: float,
) -> dict[str, float]:
    target_floor = {reservoir_id: env.target_min(date, reservoir_id) for reservoir_id in env.reservoir_ids}
    total_target = sum(target_floor.values())
    reserve_extra = max(0.0, basin_reserve_floor_acft - total_target)
    releasable_above_target = {}
    total_releasable = 0.0
    for reservoir_id in env.reservoir_ids:
        available = max(
            0.0,
            storage_acft.get(reservoir_id, 0.0)
            + inflow_cfs.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT
            - target_floor[reservoir_id],
        )
        releasable_above_target[reservoir_id] = available
        total_releasable += available
    floors = {}
    for reservoir_id, spec in env.reservoir_specs.items():
        reserve_share = reserve_extra * safe_divide(releasable_above_target.get(reservoir_id, 0.0), total_releasable)
        floors[reservoir_id] = clamp(target_floor[reservoir_id] + reserve_share, spec.storage_min_acft, spec.storage_max_acft)
    return floors


def next_storage_from_release(
    env: DailyReservoirEnvironment,
    storage_acft: dict[str, float],
    inflow_cfs: dict[str, float],
    releases_cfs: dict[str, float],
) -> tuple[dict[str, float], dict[str, float]]:
    next_storage = {}
    spill = {}
    for reservoir_id, spec in env.reservoir_specs.items():
        raw = (
            storage_acft.get(reservoir_id, 0.0)
            + inflow_cfs.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT
            - releases_cfs.get(reservoir_id, 0.0) * CFS_DAY_TO_ACFT
        )
        spill_acft = max(0.0, raw - spec.storage_max_acft)
        next_storage[reservoir_id] = clamp(raw, spec.storage_min_acft, spec.storage_max_acft)
        spill[reservoir_id] = spill_acft / CFS_DAY_TO_ACFT
    return next_storage, spill


def terminal_storage_deficit(
    env: DailyReservoirEnvironment,
    storage_acft: dict[str, float],
    date: str,
) -> float:
    deficit = 0.0
    for reservoir_id in env.reservoir_ids:
        target_min = env.target_min(date, reservoir_id)
        deficit += max(0.0, target_min - storage_acft.get(reservoir_id, 0.0))
    return deficit


def node_values(values: dict[str, float], columns: list[str]) -> dict[str, float]:
    return {column.split("__", 1)[1]: values.get(column, 0.0) for column in columns}


def downstream_reachable(env: DailyReservoirEnvironment, start_node: str) -> set[str]:
    seen: set[str] = set()
    queue = [start_node]
    while queue:
        node = queue.pop(0)
        for downstream in env.adj.get(node, []):
            if downstream not in seen:
                seen.add(downstream)
                queue.append(downstream)
    return seen


def compute_release_influence(env: DailyReservoirEnvironment) -> dict[str, float]:
    objective_nodes = set(env.diversion_node_ids) | set(env.instream_node_ids)
    stream_nodes = set(env.stream_node_ids)
    influence = {}
    for reservoir_id in env.reservoir_ids:
        reachable = downstream_reachable(env, reservoir_id)
        if reachable & objective_nodes:
            influence[reservoir_id] = 1.0
        elif reachable & stream_nodes:
            influence[reservoir_id] = 0.55
        else:
            influence[reservoir_id] = 0.25
    return influence


def tail_mean(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    threshold = percentile(values, q)
    tail = [value for value in values if value >= threshold]
    return sum(tail) / len(tail) if tail else threshold


def intent_weights(primary_intent: str) -> dict[str, float]:
    base = {
        "shortage": 1.00,
        "ecology": 1.20,
        "target_deficit": 0.22,
        "target_excess": 0.08,
        "depletion": 0.30,
        "release": 0.010,
        "spill": 0.20,
        "ramp": 0.006,
    }
    if primary_intent == "support_downstream_demands":
        base["shortage"] = 1.45
        base["release"] = 0.006
    elif primary_intent == "support_ecology":
        base["ecology"] = 1.75
        base["shortage"] = 0.95
    elif primary_intent == "pre_release_buffer":
        base["target_excess"] = 0.20
        base["spill"] = 0.55
        base["release"] = 0.004
    elif primary_intent in {"conserve_storage", "recover_targets"}:
        base["target_deficit"] = 0.45
        base["depletion"] = 0.70
        base["release"] = 0.030
    elif primary_intent == "balanced":
        base["shortage"] = 1.10
        base["ecology"] = 1.10
    return base
